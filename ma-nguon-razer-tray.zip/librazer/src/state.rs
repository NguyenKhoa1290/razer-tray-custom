//! Data model: the device-state the tray reads/writes, the persisted config, and the
//! pure helpers around them. Deliberately free of menu/OS code so it stays easy to
//! read and unit-test (see the `tests` module at the bottom).

use anyhow::Result;
use serde::{Deserialize, Serialize};

use crate::command;
use crate::keyboard::{self, BatteryLevel, Frame, KeyboardColor, KeyboardPreset};
use crate::transport::HidTransport;
use crate::types::{
    BatteryCare, CpuBoost, FanMode, GpuBoost, KeyboardEffect, LightsAlwaysOn, LogoMode,
    MaxFanSpeedMode,
};
use crate::unsupported::{Optional, Unsupported};

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum FanSpeed {
    Auto,
    Manual(u16),
}

/// Manual-fan RPM step for building the UI presets (granularity; model-independent).
pub const FAN_RPM_STEP: u16 = 400;

/// Widest manual-fan bounds across all known Blade models, for callers that must fix a
/// static range *before* the device is detected (e.g. the CLI arg parser). The per-device
/// range lives on the [`crate::descriptor::Descriptor`] (`fan_rpm_range`) and is narrower.
/// Below a chassis's floor the EC does NOT refuse: it stores the value and spins at the
/// floor anyway (measured on 0x029F), so validation has to happen here, in software.
///
/// These are the true extremes of every chassis we know of, and there used to be three
/// disagreeing numbers for the same idea: `command.rs` hard-coded `0..=5500`, this ceiling
/// was 5300, and the per-PID table reaches 5600 (Blade 14 2025). A caller-supplied RPM was
/// therefore validated against a bound that matched no real machine. Both ends now come
/// from the device tables: floor 2000 (Blade 15 2021 Advanced), ceiling 5700 (Blade 15
/// 2018 Base, issue #2). A test in `descriptor.rs` keeps them consistent with the table.
pub const FAN_RPM_MIN_ANY: u16 = 2000;
pub const FAN_RPM_MAX_ANY: u16 = 5700;

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub enum PerfMode {
    Battery,
    Silent,
    Balanced,
    Performance,
    Hyperboost,
    Custom(CpuBoost, GpuBoost),
}

impl PerfMode {
    /// The EC's perf mode, without Custom's boosts: what per-model tables such as
    /// [`crate::unsupported::MANUAL_FLOOR_BY_PERF`] are keyed by.
    pub fn wire(self) -> crate::types::PerfMode {
        match self {
            PerfMode::Battery => crate::types::PerfMode::Battery,
            PerfMode::Silent => crate::types::PerfMode::Silent,
            PerfMode::Balanced => crate::types::PerfMode::Balanced,
            PerfMode::Performance => crate::types::PerfMode::Performance,
            PerfMode::Hyperboost => crate::types::PerfMode::Hyperboost,
            PerfMode::Custom(..) => crate::types::PerfMode::Custom,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct LightsMode {
    pub logo_mode: LogoMode,
    pub keyboard_brightness: u8,
    pub always_on: LightsAlwaysOn,
    /// Keyboard backlight effect. `None` means "unknown / leave the keyboard lighting
    /// untouched" -- so existing configs and anyone who never picks an effect keep today's
    /// behavior (brightness-only, no effect write; no regression). `Some(effect)` is written
    /// on apply.
    ///
    /// This IS readable on PID 0x029F via `0x0f82` (HW-verified 2026-07-25), so unlike
    /// always-on it appears in `read()` and can be reconciled. It is deliberately still
    /// NOT in `enforced_fields_differ`: the effect is cosmetic, and a read that returns
    /// `None` on a model whose firmware lacks the getter would otherwise look like
    /// permanent drift and re-assert on every poll forever.
    #[serde(default)]
    pub keyboard_effect: Option<KeyboardEffect>,
    /// Custom keyboard color. When set it wins over `keyboard_effect`, which is then only
    /// what the keyboard falls back to when the frame is lost (frames are not stored in the
    /// EC; see [`crate::keyboard`]). `apply` does not paint it: the caller renders the frame,
    /// because the battery bar needs the battery level. `None` = no custom color.
    #[serde(default)]
    pub keyboard_color: Option<KeyboardColor>,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct FanRpm {
    pub fan1: u16,
    pub fan2: u16,
}

impl FanRpm {
    /// Both fans stopped. A real state on 0x029F: the firmware's Auto curve shuts the fans
    /// off entirely when the chassis is cool enough (measured 2026-08-15 -- 14 of 15 reads
    /// at 1.5 s spacing returned 0/0 across 22 s). Manual mode cannot produce it.
    pub fn is_stopped(self) -> bool {
        self.fan1 == 0 && self.fan2 == 0
    }

    /// Exactly one zone reads zero while the other is running -- physically impossible, so
    /// the read failed.
    ///
    /// The EC slews at a measured ~23 RPM/s (manual) to ~53 RPM/s (Auto descent), which puts
    /// a 2000 -> 0 spin-down at 40 s minimum. Yet consecutive 30 s-spaced samples on
    /// 2026-08-15 produced `0/1800` then `2000/0` then `0/1800`: round trips that cannot
    /// happen at that slew, in *both* directions (one sample carried a lone 2000 while the
    /// true state was stopped). Roughly 3 in 10 sparse samples carried one bad zone.
    ///
    /// Deliberately narrow. A large-but-nonzero gap is NOT treated as suspect: legitimate
    /// Auto asymmetry of 100-200 RPM is normal on this chassis (2000/1900, 2000/1800), and
    /// no threshold above that has been measured, so inventing one would trade a real bug
    /// for a guessed one.
    pub fn is_lone_zero(self) -> bool {
        (self.fan1 == 0) != (self.fan2 == 0)
    }
}

/// Debounces `0x0d88` fan reads before anything displays them.
///
/// Two rules, each from a measurement rather than a hunch:
///
/// 1. A [`FanRpm::is_lone_zero`] sample is dropped outright and the previous value stands.
///    It cannot be true, so showing it is strictly worse than showing a stale number.
/// 2. A *stopped* reading is published only after two consecutive stopped samples. "The
///    app says zero" is the report this whole filter exists to answer, so that state has
///    to earn its way onto the screen. Running values publish immediately -- during a ramp
///    the number legitimately moves every poll, and holding those back would only make the
///    display stale.
///
/// Nothing here is a moving average: a smoothed RPM would hide exactly the ramps that
/// distinguish a held speed from one the fan is passing through.
#[derive(Debug, Clone, Copy, Default)]
pub struct FanRpmFilter {
    published: Option<FanRpm>,
    /// A stopped sample seen once, waiting for a second one to confirm it.
    stop_pending: bool,
}

impl FanRpmFilter {
    /// Feed one raw read. Returns the value that should now be displayed, or `None` while
    /// no reading has ever been trustworthy (only possible before the first good sample).
    pub fn accept(&mut self, sample: FanRpm) -> Option<FanRpm> {
        if sample.is_lone_zero() {
            // A failed read tells us nothing, including nothing about a pending stop.
            return self.published;
        }
        if sample.is_stopped() {
            if !self.stop_pending {
                self.stop_pending = true;
                return self.published;
            }
        } else {
            self.stop_pending = false;
        }
        self.published = Some(sample);
        self.published
    }

    /// The last value cleared for display, if any.
    pub fn published(self) -> Option<FanRpm> {
        self.published
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct DeviceState {
    pub perf_mode: PerfMode,
    pub lights_mode: LightsMode,
    pub battery_care: BatteryCare,
    pub fan_speed: FanSpeed,
    /// Max Fan Speed Mode: runs both fans flat-out regardless of the Auto/Manual RPM
    /// setting. Custom perf mode ONLY -- the EC rejects the command in other modes -- so
    /// it's always false outside Custom. `#[serde(default)]` keeps configs written before
    /// this field existed loadable (they deserialize to false).
    #[serde(default)]
    pub max_fan: bool,
    /// Display refresh rate for this profile, in Hz. `None` = leave the display alone (the
    /// default, so existing configs change nothing). Not an EC setting: the tray applies it
    /// through the Windows display APIs, and `read` never reports it, so it is kept out of
    /// `enforced_fields_differ`.
    #[serde(default)]
    pub display_refresh_hz: Option<u32>,
}

/// Map a 0..=100 percentage to the device's 0..255 keyboard-brightness scale,
/// rounded. Used by the brightness submenu so its 10% steps span the full
/// hardware range (0->0, 10->26, 50->128, 100->255).
pub fn percent_to_brightness(percent: u8) -> u8 {
    ((percent as u16 * 255 + 50) / 100) as u8
}

/// Inverse of `percent_to_brightness`: map the device's 0..=255 brightness back to a
/// 0..=100 percentage, rounded. Used by the tooltip so it reports the same unit the
/// brightness menu offers rather than the raw register value (0..=255).
pub fn brightness_to_percent(brightness: u8) -> u8 {
    ((brightness as u16 * 100 + 127) / 255) as u8
}

/// Percent steps the keyboard-brightness menu offers (0, 10, ..., 100).
pub const BRIGHTNESS_PERCENT_STEP: u8 = 10;

/// The menu step closest to a raw 0..=255 brightness.
///
/// The hardware Fn keys walk a 16-step ladder that doesn't line up with our 10% marks, so
/// an externally-set brightness usually lands *between* steps. Highlighting the nearest one
/// keeps exactly one checkmark in the menu instead of none. Lives here (not in the tray)
/// because it's pure arithmetic that the host test suite can actually cover -- the tray
/// crate can't be built on a non-Windows/Linux host at all.
pub fn nearest_brightness_percent(brightness: u8) -> u8 {
    (0u8..=100)
        .step_by(BRIGHTNESS_PERCENT_STEP as usize)
        .min_by_key(|p| (percent_to_brightness(*p) as i32 - brightness as i32).abs())
        .unwrap_or(0)
}

/// UTF-16 code units in `s` -- the unit Windows counts, not characters.
pub fn utf16_units(s: &str) -> usize {
    s.chars().map(char::len_utf16).sum()
}

/// Trim `s` to at most `limit` UTF-16 units, never splitting a surrogate pair.
///
/// A blind cut can land between the two halves of an astral character (every emoji), and a
/// lone surrogate renders as a replacement glyph.
pub fn truncate_utf16(s: &str, limit: usize) -> String {
    let mut out = String::with_capacity(s.len());
    let mut units = 0usize;
    for c in s.chars() {
        let w = c.len_utf16();
        if units + w > limit {
            break;
        }
        out.push(c);
        units += w;
    }
    out
}

/// Assemble a tray tooltip that fits `limit` UTF-16 units, shedding its least important
/// fields rather than letting the shell cut the string.
///
/// `lines` is the desired layout: each inner `Vec` is one line of `(priority, text)` parts
/// joined by a space, and lines are joined by `\n`. A *lower* priority number means "keep
/// this harder", so `0` is the field we never drop. While the whole thing is over budget the
/// largest priority number is removed and the layout re-rendered; a line left with no parts
/// disappears entirely, taking its newline with it.
///
/// This exists because appending a field and then hard-truncating is not budgeting: the
/// truncation always eats the *last* thing added, so the newest field is the one that
/// silently never appears. Dropping by declared priority makes the loss deliberate and
/// predictable instead.
///
/// Pure, and deliberately in the library so the host test suite covers it -- the tray crate
/// cannot be built on a non-Windows host at all, so a test placed there would never run.
pub fn fit_tooltip(lines: &[Vec<(u8, String)>], limit: usize) -> String {
    fn render(lines: &[Vec<(u8, String)>]) -> String {
        lines
            .iter()
            .filter(|line| !line.is_empty())
            .map(|line| {
                line.iter()
                    .map(|(_, text)| text.as_str())
                    .collect::<Vec<_>>()
                    .join(" ")
            })
            .collect::<Vec<_>>()
            .join("\n")
    }

    let mut lines: Vec<Vec<(u8, String)>> = lines.to_vec();
    loop {
        let rendered = render(&lines);
        if utf16_units(&rendered) <= limit {
            return rendered;
        }

        // Drop the least important remaining part. Ties go to the later one, so a line's
        // trailing decoration goes before the field it decorates.
        let mut worst: Option<(usize, usize, u8)> = None;
        let mut remaining = 0usize;
        for (li, line) in lines.iter().enumerate() {
            remaining += line.len();
            for (pi, (priority, _)) in line.iter().enumerate() {
                if worst.is_none_or(|(_, _, w)| *priority >= w) {
                    worst = Some((li, pi, *priority));
                }
            }
        }

        match worst {
            // One part left and still too long: nothing to shed, so cut it safely.
            Some((li, pi, _)) if remaining > 1 => {
                lines[li].remove(pi);
            }
            _ => return truncate_utf16(&rendered, limit),
        }
    }
}

/// The next perf mode in the tray's left-click cycle.
///
/// Pure, and deliberately in the library so it is exercised by the host test suite; the
/// tray only wraps it with the surrounding `DeviceState`. Entering Custom seeds the
/// documented boost defaults, matching what picking Custom from the menu does.
pub fn next_perf_mode(current: PerfMode) -> PerfMode {
    match current {
        PerfMode::Battery => PerfMode::Silent,
        PerfMode::Silent => PerfMode::Balanced,
        PerfMode::Balanced => PerfMode::Performance,
        PerfMode::Performance => PerfMode::Hyperboost,
        PerfMode::Hyperboost => PerfMode::Custom(CpuBoost::Boost, GpuBoost::High),
        PerfMode::Custom(..) => PerfMode::Battery,
    }
}

impl DeviceState {
    /// The same intent with the two invariants the EC imposes made explicit, so no path
    /// can hand `apply` a state the device cannot hold:
    ///
    /// - `max_fan` exists only in Custom (the EC rejects it elsewhere, and `read` reports it
    ///   false there). A stray `true` outside Custom never converges: Enforce saw it as drift
    ///   on every poll, and it came back unasked the next time the cycle reached Custom.
    /// - A manual RPM is stored as rpm/100 and floored/clamped by the chassis, so anything
    ///   outside `fan_rpm_range` or off a 100 step is snapped to the nearest value the
    ///   hardware will actually run and report back.
    ///
    /// Pure and idempotent; callers normalize at the boundary (config load, menu pick,
    /// Action overlay) rather than trusting every producer to get it right.
    pub fn normalized(self, fan_rpm_range: (u16, u16)) -> Self {
        let mut out = self;
        if !matches!(out.perf_mode, PerfMode::Custom(..)) {
            out.max_fan = false;
        }
        if let FanSpeed::Manual(rpm) = out.fan_speed {
            let (lo, hi) = fan_rpm_range;
            out.fan_speed = FanSpeed::Manual((rpm.clamp(lo, hi) / 100) * 100);
        }
        out
    }

    /// Read the device's *actual* current state. Used by the Mirror refresh to keep
    /// the tray display honest. This is read-only: callers must treat the result as
    /// something to *display*, never to re-apply (re-applying would fight external
    /// changes such as Fn-key brightness and could overwrite saved AC/battery
    /// profiles). Returns Err on any transient HID failure; callers should swallow
    /// that and keep the last known-good values rather than propagating it.
    pub fn read(device: &impl HidTransport) -> Result<Self> {
        // One read serves both the perf mode and the fan mode: they come back in the
        // same 0x0d82 response. This used to call get_perf_mode() twice -- and since
        // each call reads *both* fan zones, that was 4 HID round-trips where 2 suffice.
        // On the hover path (read + fan RPM) the whole exchange was 15 round-trips.
        let (raw_perf_mode, raw_fan_mode) = command::get_perf_mode(device)?;

        let perf_mode = match raw_perf_mode {
            crate::types::PerfMode::Battery => PerfMode::Battery,
            crate::types::PerfMode::Silent => PerfMode::Silent,
            crate::types::PerfMode::Balanced => PerfMode::Balanced,
            crate::types::PerfMode::Performance => PerfMode::Performance,
            crate::types::PerfMode::Hyperboost => PerfMode::Hyperboost,
            crate::types::PerfMode::Custom => {
                let cpu_boost = command::get_cpu_boost(device)?;
                let gpu_boost = command::get_gpu_boost(device)?;
                PerfMode::Custom(cpu_boost, gpu_boost)
            }
        };

        let fan_speed = match raw_fan_mode {
            FanMode::Auto => FanSpeed::Auto,
            FanMode::Manual => {
                let rpm = command::get_fan_rpm(device, crate::types::FanZone::Zone1)?;
                FanSpeed::Manual(rpm)
            }
        };
        // Placeholders for a setting this laptop lacks are never written (see
        // `write_optional`) and never count as drift (see `enforced_fields_differ_on`).
        let lights_mode = LightsMode {
            logo_mode: read_optional(device, Optional::Logo, LogoMode::Off, || {
                command::get_logo_mode(device)
            })?,
            keyboard_brightness: read_optional(device, Optional::KeyboardBrightness, 0, || {
                command::get_keyboard_brightness(device)
            })?,
            always_on: command::get_lights_always_on(device)?,
            // The effect IS readable on this device (0x0f82) -- see get_keyboard_effect.
            // A read failure is not fatal: the effect is cosmetic and older/other models
            // may genuinely lack the getter, so fall back to "unknown" (None) rather than
            // failing the whole state read and blanking the tray.
            keyboard_effect: command::get_keyboard_effect(device).unwrap_or(None),
            // A frame cannot be read back, and while one shows the effect register still
            // reports the stored effect. Intent is the only record of a custom color.
            keyboard_color: None,
        };

        let battery_care =
            read_optional(device, Optional::BatteryCare, BatteryCare::DISABLE, || {
                command::get_battery_care(device)
            })?;

        // Max fan is a Custom-only toggle; only read it there -- the getter is meaningless
        // outside Custom, and skipping it spares a HID read on every (frequent) poll.
        let max_fan = matches!(perf_mode, PerfMode::Custom(..))
            && matches!(
                read_optional(device, Optional::MaxFan, MaxFanSpeedMode::Disable, || {
                    command::get_max_fan_speed_mode(device)
                })?,
                MaxFanSpeedMode::Enable
            );

        Ok(Self {
            perf_mode,
            lights_mode,
            battery_care,
            fan_speed,
            max_fan,
            display_refresh_hz: None,
        })
    }

    /// Perf mode + fan + logo -- the settings shared by `apply()` (full write) and
    /// `enforce_to()` (the Synapse tug-of-war reassert). Kept in one place so the two
    /// can't drift. Every write is attempted; the first failure (perf, then fan, then logo)
    /// is returned. A fan failure used to be logged and dropped, so a Busy that outlasted
    /// the retries left the tray showing and saving a speed the fan never took.
    ///
    /// The perf/fan/logo writes are *independent* EC commands, so a failure in one is
    /// not a reason to skip the rest: bailing early used to leave the device in the new
    /// perf mode with the fan and logo still on their previous settings. Every write is
    /// now attempted, and the first hard error is returned once the sequence completes.
    fn apply_perf_fan_logo(&self, device: &impl HidTransport) -> Result<()> {
        // Boosts are only meaningful once Custom is set, so that inner chain still stops
        // on error -- but it no longer aborts the fan/logo writes below.
        let perf_result = match self.perf_mode {
            PerfMode::Battery => command::set_perf_mode(device, crate::types::PerfMode::Battery),
            PerfMode::Silent => command::set_perf_mode(device, crate::types::PerfMode::Silent),
            PerfMode::Balanced => command::set_perf_mode(device, crate::types::PerfMode::Balanced),
            PerfMode::Performance => {
                command::set_perf_mode(device, crate::types::PerfMode::Performance)
            }
            PerfMode::Hyperboost => {
                command::set_perf_mode(device, crate::types::PerfMode::Hyperboost)
            }
            // Confirmed: the boosts need Custom, and an EC that acknowledged the switch and
            // ignored it would otherwise surface only as their "must be Custom" error.
            PerfMode::Custom(cpu_boost, gpu_boost) => {
                command::set_perf_mode_confirmed(device, crate::types::PerfMode::Custom)
                    .and_then(|_| command::set_cpu_boost(device, cpu_boost))
                    .and_then(|_| command::set_gpu_boost(device, gpu_boost))
            }
        };
        if let Err(e) = &perf_result {
            log::warn!("perf mode command failed: {:?}", e);
        }

        // Max fan speed is Custom-only (the EC rejects the command otherwise). Match intent
        // while in Custom; leaving Custom clears it in the EC. A failure is returned after the
        // remaining writes are attempted, like the fan write. A laptop without it (issue
        // #10) is left alone like a missing logo.
        let max_fan_result = if device.product_id() != Some(0x0253)
            && matches!(self.perf_mode, PerfMode::Custom(..))
        {
            let mode = if self.max_fan {
                MaxFanSpeedMode::Enable
            } else {
                MaxFanSpeedMode::Disable
            };
            // The perf read is done here, outside `write_optional`: its errors keep their
            // type, so a 0x05 to the perf read inside the setter recorded Max Fan as missing.
            match command::get_perf_mode(device) {
                Ok((crate::types::PerfMode::Custom, _)) => {
                    write_optional(device, Optional::MaxFan, || {
                        command::send_max_fan_speed_mode(device, mode)
                    })
                }
                Ok((other, _)) => Err(anyhow::anyhow!(
                    "Performance mode must be Custom for Max Fan, read {other:?}"
                )),
                Err(e) => Err(e),
            }
        } else {
            Ok(())
        };
        if let Err(e) = &max_fan_result {
            log::warn!("max fan command failed: {:?}", e);
        }

        let fan_result = match self.fan_speed {
            FanSpeed::Auto => command::set_fan_mode(device, crate::types::FanMode::Auto),
            // Validate BEFORE switching the mode: a rejected RPM used to leave the fan in
            // Manual at whatever set point the EC last held (possibly 4800) while the UI
            // showed the rejected value.
            FanSpeed::Manual(rpm)
                if !rpm.is_multiple_of(100)
                    || !(FAN_RPM_MIN_ANY..=FAN_RPM_MAX_ANY).contains(&rpm) =>
            {
                Err(anyhow::anyhow!(
                    "manual fan {rpm} RPM is not representable; fan mode left unchanged"
                ))
            }
            FanSpeed::Manual(rpm) => command::set_fan_mode(device, crate::types::FanMode::Manual)
                .and_then(|_| command::set_fan_rpm(device, rpm, false)),
        };
        if let Err(e) = &fan_result {
            log::warn!("fan command failed: {:?}", e);
        }

        let logo_result = write_optional(device, Optional::Logo, || {
            command::set_logo_mode(device, self.lights_mode.logo_mode)
        });
        if let Err(e) = &logo_result {
            log::warn!("logo command failed: {:?}", e);
        }

        // Most consequential first: perf, then fan, then logo.
        perf_result
            .and(max_fan_result)
            .and(fan_result)
            .and(logo_result)
    }

    /// A reading with the settings in `lacking` taken from `intent`. A reading holds a
    /// placeholder for a setting the laptop lacks (see `read_optional`), and the tray must
    /// not adopt one into a profile or show it as the device's value: a profile saved with
    /// it would apply it on hardware that has the setting.
    pub fn with_lacking_from(mut self, intent: &DeviceState, lacking: Unsupported) -> Self {
        if lacking.contains(Optional::Logo) {
            self.lights_mode.logo_mode = intent.lights_mode.logo_mode;
        }
        if lacking.contains(Optional::KeyboardBrightness) {
            self.lights_mode.keyboard_brightness = intent.lights_mode.keyboard_brightness;
        }
        if lacking.contains(Optional::BatteryCare) {
            self.battery_care = intent.battery_care;
        }
        if lacking.contains(Optional::MaxFan) {
            self.max_fan = intent.max_fan;
        }
        self
    }

    /// Carry ONLY the fields the user actually changed from `base`, leaving the rest of
    /// `base` alone.
    ///
    /// This exists because the tray menu bakes a whole `DeviceState` into every handler,
    /// built from whatever is *currently effective*. While an app Action is overlaying the
    /// saved profile, "currently effective" is the overlay -- so picking one unrelated item
    /// (say keyboard brightness) used to hand `update()` a state carrying the Action's perf
    /// mode and fan too, and `update()` saved the lot. Close the game and you reverted to a
    /// profile that had silently acquired the Action's settings. The README's claim that an
    /// override "never overwrites a saved profile" was false.
    ///
    /// `before` is the effective state the menu was built from; `after` is what the user
    /// picked. Their difference is exactly the user's intent, and only that lands on `base`.
    ///
    /// When no overlay is in effect `base == before`, so this returns `after` unchanged --
    /// the no-Action path keeps its old behavior exactly.
    ///
    /// Only the *saved profile* is narrowed. What the user picked still takes effect on the
    /// device immediately, overriding the Action until it next re-applies; that half is
    /// unchanged and is a separate design question.
    pub fn carry_changes(base: Self, before: Self, after: Self) -> Self {
        let mut out = base;
        if after.perf_mode != before.perf_mode {
            out.perf_mode = after.perf_mode;
        }
        if after.fan_speed != before.fan_speed {
            out.fan_speed = after.fan_speed;
        }
        if after.max_fan != before.max_fan {
            out.max_fan = after.max_fan;
        }
        if after.battery_care != before.battery_care {
            out.battery_care = after.battery_care;
        }
        if after.lights_mode.logo_mode != before.lights_mode.logo_mode {
            out.lights_mode.logo_mode = after.lights_mode.logo_mode;
        }
        if after.lights_mode.keyboard_brightness != before.lights_mode.keyboard_brightness {
            out.lights_mode.keyboard_brightness = after.lights_mode.keyboard_brightness;
        }
        if after.lights_mode.always_on != before.lights_mode.always_on {
            out.lights_mode.always_on = after.lights_mode.always_on;
        }
        if after.lights_mode.keyboard_effect != before.lights_mode.keyboard_effect {
            out.lights_mode.keyboard_effect = after.lights_mode.keyboard_effect;
        }
        if after.lights_mode.keyboard_color != before.lights_mode.keyboard_color {
            out.lights_mode.keyboard_color = after.lights_mode.keyboard_color;
        }
        if after.display_refresh_hz != before.display_refresh_hz {
            out.display_refresh_hz = after.display_refresh_hz;
        }
        out
    }

    pub fn apply(&self, device: &impl HidTransport) -> Result<()> {
        let mut first = Ok(());
        continue_after_rejection(&mut first, self.apply_perf_fan_logo(device))?;
        // NB: always-on is deliberately NOT applied here. It is the Razer "device mode"
        // command (0x0004); Enable == driver mode, which disables the keyboard's native
        // Fn media keys (brightness/volume). The tray keeps the device in Normal mode and
        // implements "keyboard always-on" as a Normal-mode keep-alive instead.
        //
        // Keyboard lighting is applied BEFORE brightness: some effect writes reset the
        // backlight brightness, so re-asserting brightness afterward keeps it authoritative.
        continue_after_rejection(&mut first, self.apply_keyboard_lighting(device))?;
        continue_after_rejection(
            &mut first,
            write_optional(device, Optional::KeyboardBrightness, || {
                command::set_keyboard_brightness(device, self.lights_mode.keyboard_brightness)
            }),
        )?;
        continue_after_rejection(
            &mut first,
            write_optional(device, Optional::BatteryCare, || {
                command::set_battery_care(device, self.battery_care)
            }),
        )?;
        first
    }

    /// Check that the EC is in this state's perf and fan mode, after [`Self::apply`]. See
    /// [`command::confirm_perf_mode`] for why an acknowledged write isn't enough.
    pub fn confirm_modes(&self, device: &impl HidTransport) -> Result<()> {
        let perf = match self.perf_mode {
            PerfMode::Battery => crate::types::PerfMode::Battery,
            PerfMode::Silent => crate::types::PerfMode::Silent,
            PerfMode::Balanced => crate::types::PerfMode::Balanced,
            PerfMode::Performance => crate::types::PerfMode::Performance,
            PerfMode::Hyperboost => crate::types::PerfMode::Hyperboost,
            PerfMode::Custom(..) => crate::types::PerfMode::Custom,
        };
        let fan = match self.fan_speed {
            FanSpeed::Auto => FanMode::Auto,
            FanSpeed::Manual(_) => FanMode::Manual,
        };
        command::confirm_perf_mode(device, perf, fan)
    }

    /// Write the keyboard backlight effect, if one is configured. Driven from stored intent:
    /// `read` does report the effect (0x0f82), but it is deliberately kept out of
    /// `enforced_fields_differ`, because it is cosmetic and a model without the getter would
    /// look like permanent drift. `None` leaves the keyboard
    /// lighting untouched (the default), so this is a no-op for configs/users that never set an
    /// effect. Kept as its own method so callers beyond `apply()` (e.g. a future resume
    /// re-assert, if HW testing shows the EC drops the effect on wake) can re-push it cheaply.
    ///
    /// With a custom color set this writes nothing: the color wins, and the caller paints
    /// it with [`Self::keyboard_frame`].
    pub fn apply_keyboard_lighting(&self, device: &impl HidTransport) -> Result<()> {
        if self.lights_mode.keyboard_color.is_some() {
            return Ok(());
        }
        match self.lights_mode.keyboard_effect {
            Some(effect) => command::set_keyboard_effect(device, effect),
            None => Ok(()),
        }
    }

    /// The custom-color frame this state should show, with the battery bar when `battery`
    /// is given; `None` when no custom color is set.
    pub fn keyboard_frame(&self, battery: Option<BatteryLevel>) -> Option<Frame> {
        self.lights_mode
            .keyboard_color
            .map(|c| keyboard::render(c, self.perf_mode, battery))
    }

    /// Re-assert the "enforced" subset of settings -- perf mode, fan, logo, and
    /// battery care -- WITHOUT touching keyboard brightness. This is what the opt-in
    /// Enforce mode uses to win a tug-of-war with Synapse. Brightness is excluded so it
    /// stays on the adopt path (Fn keys keep working). It's exactly apply() minus the
    /// brightness write. (always-on isn't a device write at all -- it's a Normal-mode
    /// keep-alive in the tray -- so there's nothing here to exclude for it.)
    pub fn enforce_to(&self, device: &impl HidTransport) -> Result<()> {
        let mut first = Ok(());
        continue_after_rejection(&mut first, self.apply_perf_fan_logo(device))?;
        continue_after_rejection(
            &mut first,
            write_optional(device, Optional::BatteryCare, || {
                command::set_battery_care(device, self.battery_care)
            }),
        )?;
        first
    }

    /// Whether the *enforced* fields -- perf mode, fan, logo, battery care -- of `self`
    /// (typically a just-read `observed` state) differ from `intended`. This is exactly
    /// the subset `enforce_to` writes: keyboard brightness is excluded on purpose (it
    /// rides the Fn-key adopt path), and always-on isn't a device write, so drift in
    /// those must NOT trigger a re-assert. The tray's Enforce loop calls this before
    /// re-asserting against Synapse.
    pub fn enforced_fields_differ(&self, intended: &DeviceState) -> bool {
        self.enforced_fields_differ_except(intended, Unsupported::default())
    }

    /// [`Self::enforced_fields_differ`], leaving out the settings `device` has turned out
    /// not to have: their read-back is a placeholder, so comparing it would be drift that
    /// no write can repair.
    pub fn enforced_fields_differ_on(
        &self,
        intended: &DeviceState,
        device: &impl HidTransport,
    ) -> bool {
        self.enforced_fields_differ_except(intended, unsupported_on(device))
    }

    fn enforced_fields_differ_except(&self, intended: &DeviceState, skip: Unsupported) -> bool {
        self.perf_mode != intended.perf_mode
            || self.fan_speed != intended.fan_speed
            || (!skip.contains(Optional::MaxFan) && self.max_fan != intended.max_fan)
            || (!skip.contains(Optional::Logo)
                && self.lights_mode.logo_mode != intended.lights_mode.logo_mode)
            || (!skip.contains(Optional::BatteryCare) && self.battery_care != intended.battery_care)
    }

    /// [`Self::enforced_fields_differ`], for a state just read from `device`, plus what
    /// [`Self::read`] cannot see: in Manual, a zone 2 set point off target (see
    /// [`command::fan_setpoint_zones_differ`]). Costs one extra read in Manual when the
    /// enforced fields match, none otherwise. A failed zone 2 read is not drift: like every
    /// other failed poll, it leaves the last decision standing. `guard` stops the zone 2
    /// check after repairs stop working (see [`Zone2DriftGuard`]).
    pub fn drifted_from(
        &self,
        intended: &DeviceState,
        device: &impl HidTransport,
        guard: &mut Zone2DriftGuard,
    ) -> bool {
        if self.enforced_fields_differ_on(intended, device) {
            return true;
        }
        match self.fan_speed {
            FanSpeed::Manual(rpm) if !guard.given_up => {
                match command::fan_setpoint_zones_differ(device, rpm) {
                    Ok(true) => guard.drift_seen(),
                    Ok(false) => {
                        guard.unrepaired = 0;
                        false
                    }
                    Err(e) => {
                        log::debug!("zone 2 fan set point read failed: {e:?}");
                        false
                    }
                }
            }
            _ => false,
        }
    }

    fn perf_delta(&self, cpu_boost: Option<CpuBoost>, gpu_boost: Option<GpuBoost>) -> Self {
        DeviceState {
            perf_mode: if let PerfMode::Custom(cb, gb) = self.perf_mode {
                PerfMode::Custom(cpu_boost.unwrap_or(cb), gpu_boost.unwrap_or(gb))
            } else {
                PerfMode::Custom(
                    cpu_boost.unwrap_or(CpuBoost::Boost),
                    gpu_boost.unwrap_or(GpuBoost::High),
                )
            },
            ..*self
        }
    }
}

impl Default for DeviceState {
    fn default() -> Self {
        Self {
            perf_mode: PerfMode::Performance,
            lights_mode: LightsMode {
                logo_mode: LogoMode::Off,
                keyboard_brightness: 0,
                always_on: LightsAlwaysOn::Disable,
                // No effect intent by default: a fresh config must not impose lighting
                // the user never asked for.
                keyboard_effect: None,
                keyboard_color: None,
            },
            battery_care: BatteryCare::from_percent(80).unwrap(),
            fan_speed: FanSpeed::Auto,
            max_fan: false,
            display_refresh_hz: None,
        }
    }
}

pub trait DeviceStateDelta<T> {
    fn delta(&self, property: T) -> Self;
}

impl DeviceStateDelta<CpuBoost> for DeviceState {
    fn delta(&self, cpu_boost: CpuBoost) -> Self {
        self.perf_delta(Some(cpu_boost), None)
    }
}

impl DeviceStateDelta<GpuBoost> for DeviceState {
    fn delta(&self, gpu_boost: GpuBoost) -> Self {
        self.perf_delta(None, Some(gpu_boost))
    }
}

/// One "Action" rule: while `process` is running, force `perf_mode`. This is the
/// config-driven automation layer (cf. Legion Toolkit's Actions). Rules are matched in
/// list order; the first running match wins. There's no in-app editor -- rules are
/// hand-added to the config TOML -- so this stays opt-in (an empty list = no behavior).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AppProfile {
    /// Executable name to match, case-insensitive, e.g. "cyberpunk2077.exe".
    ///
    /// Kept as the primary field for backward compatibility: every config written before
    /// [`AppProfile::processes`] existed has exactly this key, and the tray loads config
    /// with `unwrap_or_default()`, so a schema change that failed to parse would silently
    /// throw away the user's saved profiles rather than complain.
    pub process: String,
    /// Additional executables the same rule should match, so one rule can cover a
    /// launcher and its game, or a program that changed its executable name between
    /// versions, without duplicating the whole rule.
    #[serde(default)]
    pub processes: Vec<String>,
    /// Human label for logs and future UI. Falls back to the matched process name.
    #[serde(default)]
    pub name: Option<String>,
    /// Set false to keep a rule in the file but stop applying it. Defaults to true so
    /// every existing rule stays active.
    #[serde(default = "default_true")]
    pub enabled: bool,
    /// Higher wins when several rules match at once. Equal priorities fall back to file
    /// order, so behavior is fully determined by the config rather than by which
    /// process the OS happened to list first.
    #[serde(default)]
    pub priority: i32,
    /// Restrict the rule to a power source: `Some(true)` = only on AC, `Some(false)` =
    /// only on battery, `None` = either. This is the guard that stops a "force
    /// Performance while the game runs" rule from doing that on a train.
    #[serde(default)]
    pub require_ac: Option<bool>,
    /// Perf mode to switch to while that process runs. Omit to leave perf unchanged.
    #[serde(default)]
    pub perf_mode: Option<PerfMode>,
    /// Fan setting to apply while it runs. Omit to leave the fan unchanged.
    #[serde(default)]
    pub fan_speed: Option<FanSpeed>,
    /// Logo lighting to apply while it runs. Omit to leave the logo unchanged.
    #[serde(default)]
    pub logo_mode: Option<LogoMode>,
    /// Keyboard backlight effect to apply while it runs (e.g. Spectrum for a game). Omit to
    /// leave the keyboard lighting unchanged.
    #[serde(default)]
    pub keyboard_effect: Option<KeyboardEffect>,
    /// Custom keyboard color while it runs. Omit to leave it unchanged. A rule that sets
    /// only `keyboard_effect` clears the color, since the color would otherwise hide it.
    #[serde(default)]
    pub keyboard_color: Option<KeyboardColor>,
    /// Charge limit to apply while it runs. Omit to leave it unchanged.
    ///
    /// Useful for the docked-desktop case: cap at 80% while the machine sits plugged in
    /// running a long build, without touching the saved profile.
    #[serde(default)]
    pub battery_care: Option<BatteryCare>,
    /// Max Fan Speed Mode while it runs. Only honored in the Custom perf mode -- the EC
    /// rejects it elsewhere -- so a rule setting this should set `perf_mode` to Custom too.
    #[serde(default)]
    pub max_fan: Option<bool>,
}

/// Hand-written, not derived: `#[derive(Default)]` would make `enabled` false, which is
/// exactly backwards -- a rule constructed with defaults would silently never fire.
impl Default for AppProfile {
    fn default() -> Self {
        Self {
            process: String::new(),
            processes: Vec::new(),
            name: None,
            enabled: true,
            priority: 0,
            require_ac: None,
            perf_mode: None,
            fan_speed: None,
            logo_mode: None,
            keyboard_effect: None,
            keyboard_color: None,
            battery_care: None,
            max_fan: None,
        }
    }
}

impl AppProfile {
    /// Overlay this rule's set fields onto `base`, yielding the transient state to apply
    /// while the app runs. Unset (`None`) fields leave `base` untouched, so a rule can
    /// change just the fan, just the perf mode, the logo, the keyboard effect, or any
    /// combination.
    pub fn overlay(&self, base: &DeviceState) -> DeviceState {
        let mut s = *base;
        if let Some(p) = self.perf_mode {
            s.perf_mode = p;
        }
        if let Some(f) = self.fan_speed {
            s.fan_speed = f;
        }
        if let Some(l) = self.logo_mode {
            s.lights_mode.logo_mode = l;
        }
        if let Some(e) = self.keyboard_effect {
            s.lights_mode.keyboard_effect = Some(e);
            s.lights_mode.keyboard_color = None;
        }
        if let Some(c) = self.keyboard_color {
            s.lights_mode.keyboard_color = Some(c);
        }
        if let Some(b) = self.battery_care {
            s.battery_care = b;
        }
        if let Some(m) = self.max_fan {
            s.max_fan = m;
        }
        s
    }

    /// Every executable name this rule matches.
    pub fn all_processes(&self) -> impl Iterator<Item = &str> {
        std::iter::once(self.process.as_str())
            .chain(self.processes.iter().map(String::as_str))
            .filter(|p| !p.is_empty())
    }

    /// Label for logs: the explicit name if given, else the primary process.
    pub fn label(&self) -> &str {
        match &self.name {
            Some(n) if !n.is_empty() => n.as_str(),
            _ => self.process.as_str(),
        }
    }

    /// Whether this rule may apply given the current power source.
    pub fn allowed_on(&self, ac_power: bool) -> bool {
        match self.require_ac {
            Some(required) => required == ac_power,
            None => true,
        }
    }

    /// Whether any of this rule's executables is in `running` (case-insensitive).
    pub fn matches(&self, running: &[String]) -> bool {
        self.all_processes()
            .any(|p| running.iter().any(|r| r.eq_ignore_ascii_case(p)))
    }
}

fn default_true() -> bool {
    true
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ConfigState {
    // Defaulted so a hand-written file holding only Action rules still loads.
    #[serde(default)]
    pub ac_state: DeviceState,
    #[serde(default = "default_battery_state")]
    pub battery_state: DeviceState,
    // Opt-in "win against Synapse" mode. #[serde(default)] keeps older config
    // files (written before this field existed) loadable -> defaults to false.
    #[serde(default)]
    pub enforce: bool,
    // On wake from sleep, re-assert the intended profile's enforced fields (perf/fan/
    // logo/battery) even when `enforce` is off -- a just-woken EC can drop the perf mode
    // the same way a just-booted one does (see the tray's startup reconcile). Defaults to
    // true; set false to restore the old enforce-only-on-resume behavior.
    #[serde(default = "default_true")]
    pub reassert_on_resume: bool,
    // "Actions": app-triggered profile switches. Empty by default (no behavior).
    #[serde(default)]
    pub app_profiles: Vec<AppProfile>,
    /// Also switch the Windows power mode (the Settings > Power "Power mode" slider) to
    /// match the perf mode: Battery/Silent -> Best power efficiency, Balanced -> Balanced,
    /// Performance/Hyperboost/Custom -> Best performance. Off by default: it changes an OS
    /// setting the user may manage themselves.
    #[serde(default)]
    pub match_windows_power_mode: bool,
    /// The Windows power mode each power source had before matching first changed it,
    /// put back when matching is turned off. Windows keeps one slider per power source.
    #[serde(default)]
    pub windows_power_mode_before: PowerModeBefore,
    /// Global hotkey that cycles the perf mode like a left-click, e.g. `"Ctrl+Alt+P"`.
    /// Modifiers: Ctrl, Alt, Shift, Win; key: A-Z, 0-9 or F1-F24. `None` = no hotkey.
    /// Read at startup.
    #[serde(default)]
    pub cycle_perf_hotkey: Option<String>,
    /// Named colors offered under Keyboard lighting: one color (solid) or six (one per
    /// row, top to bottom). A new config starts with [`keyboard::default_presets`].
    #[serde(default = "keyboard::default_presets")]
    pub keyboard_presets: Vec<KeyboardPreset>,
    /// While a custom color is set, show the battery level on the 1-0 keys.
    #[serde(default)]
    pub keyboard_battery_bar: bool,
    /// Leave keyboard effects and custom colors to another application.
    #[serde(default, skip_serializing_if = "is_false")]
    pub external_keyboard_lighting: bool,
    /// One fan selection shared by the tray's power and application profiles.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub global_fan_speed: Option<FanSpeed>,
    /// `true`: `ac_state` has never been set. The tray does not apply it; the first time it
    /// runs plugged in, it reads the laptop's settings into it instead (and writes nothing).
    /// Only a new config has it, and it is dropped once the profile is set. Changing the
    /// values in `ac_state` by hand also sets the profile (see [`Self::unset`]). Absent in
    /// every config written before it existed, which therefore load exactly as before.
    #[serde(default, skip_serializing_if = "is_false")]
    pub ac_state_unset: bool,
    /// As `ac_state_unset`, for `battery_state` and running on battery.
    #[serde(default, skip_serializing_if = "is_false")]
    pub battery_state_unset: bool,
}

fn is_false(b: &bool) -> bool {
    !*b
}

impl ConfigState {
    /// The config of a new install: today's defaults for every option, and both profiles
    /// unset, so the tray takes them from the laptop instead of imposing the defaults on it.
    pub fn first_run() -> Self {
        Self {
            ac_state_unset: true,
            battery_state_unset: true,
            ..Self::default()
        }
    }

    /// Which profiles are still waiting for their first reading.
    ///
    /// A profile counts as unset only while it still holds the placeholder it was written
    /// with. A hand edit to its values while the flag is still in the file means the user
    /// set it, so the edit is applied rather than replaced by a reading.
    pub fn unset(&self) -> crate::observe::Unset {
        let placeholder = Self::default();
        crate::observe::Unset {
            ac: self.ac_state_unset && self.ac_state == placeholder.ac_state,
            battery: self.battery_state_unset && self.battery_state == placeholder.battery_state,
        }
    }
}

/// The optional settings `device` has turned out not to have; empty for a model that
/// doesn't learn them.
pub fn unsupported_on(device: &impl HidTransport) -> Unsupported {
    device
        .unsupported()
        .map(|log| log.get())
        .unwrap_or_default()
}

/// Read an optional setting. On a model that learns what it lacks (see
/// [`crate::unsupported`]), a "not supported" answer records the setting and returns
/// `placeholder`, and a setting already recorded is not asked again. Any other model, or
/// any other error, returns the read as it is.
fn read_optional<T>(
    device: &impl HidTransport,
    feature: Optional,
    placeholder: T,
    read: impl FnOnce() -> Result<T>,
) -> Result<T> {
    let Some(log) = device.unsupported() else {
        return read();
    };
    if log.get().contains(feature) {
        return Ok(placeholder);
    }
    match read() {
        Err(e) if log.learns() && crate::error::is_not_supported(&e) => {
            note_unsupported(log, feature);
            Ok(placeholder)
        }
        other => other,
    }
}

/// Write an optional setting, under the same rule as [`read_optional`]: skipped once the
/// laptop is known to lack it, and a "not supported" answer records it instead of failing.
fn write_optional(
    device: &impl HidTransport,
    feature: Optional,
    write: impl FnOnce() -> Result<()>,
) -> Result<()> {
    read_optional(device, feature, (), write)
}

fn note_unsupported(log: &crate::unsupported::UnsupportedLog, feature: Optional) {
    if log.mark(feature) {
        log::warn!(
            "This laptop does not support {} (status 0x05); it is left alone from now on",
            feature.name()
        );
    }
}

/// One step of a multi-write apply. A write the EC rejected is kept in `first` and the
/// caller goes on: the writes are independent, and stopping left the brightness and charge
/// limit unwritten on a model whose fan command is rejected every time. Bus trouble still
/// stops at once, since every later write would spend its own retries on a failing bus.
fn continue_after_rejection(first: &mut Result<()>, step: Result<()>) -> Result<()> {
    match step {
        // A mode the EC acknowledged and ignored is retryable, but the bus is fine: the
        // lighting, brightness and charge limit still go out.
        Err(e) if crate::error::is_retryable(&e) && !crate::error::is_perf_not_applied(&e) => {
            Err(e)
        }
        Err(e) => {
            if first.is_ok() {
                *first = Err(e);
            }
            Ok(())
        }
        Ok(()) => Ok(()),
    }
}

/// A Windows power mode per power source, by its Settings name ("Balanced", ...).
#[derive(Serialize, Deserialize, Debug, Clone, Default, PartialEq, Eq)]
pub struct PowerModeBefore {
    pub ac: Option<String>,
    pub battery: Option<String>,
}

impl PowerModeBefore {
    pub fn slot(&mut self, ac_power: bool) -> &mut Option<String> {
        if ac_power {
            &mut self.ac
        } else {
            &mut self.battery
        }
    }
}

fn default_battery_state() -> DeviceState {
    ConfigState::default().battery_state
}

impl Default for ConfigState {
    fn default() -> Self {
        Self {
            ac_state: DeviceState {
                ..Default::default()
            },
            battery_state: DeviceState {
                perf_mode: PerfMode::Battery,
                ..Default::default()
            },
            enforce: false,
            reassert_on_resume: true,
            app_profiles: Vec::new(),
            match_windows_power_mode: false,
            windows_power_mode_before: PowerModeBefore::default(),
            cycle_perf_hotkey: None,
            keyboard_presets: keyboard::default_presets(),
            keyboard_battery_bar: false,
            external_keyboard_lighting: false,
            global_fan_speed: None,
            ac_state_unset: false,
            battery_state_unset: false,
        }
    }
}

/// Index of the app-profile that should be active, or `None` if none applies.
///
/// Selection order: enabled, allowed on the current power source, matching a running
/// executable; then **highest `priority` wins**, and equal priorities fall back to file
/// order. Ordering by priority matters because the previous rule was "first match wins" on
/// file order alone, which meant a user with overlapping rules (a launcher rule and a game
/// rule, say) got whichever they happened to type first -- and reordering a config file is
/// a poor way to express intent.
///
/// Pure, so it is unit-tested without a live process table: the caller passes the running
/// process names (from sysinfo on the real system) and the power source.
pub fn matching_app_profile(
    profiles: &[AppProfile],
    running: &[String],
    ac_power: bool,
) -> Option<usize> {
    profiles
        .iter()
        .enumerate()
        .filter(|(_, p)| p.enabled && p.allowed_on(ac_power) && p.matches(running))
        // max_by_key returns the LAST maximum; negate the index so ties resolve to the
        // earliest rule in the file instead of the latest.
        .max_by_key(|(i, p)| (p.priority, -(*i as i64)))
        .map(|(i, _)| i)
}

pub fn get_fan_rpm(device: &impl HidTransport) -> Result<FanRpm> {
    Ok(FanRpm {
        fan1: command::get_fan_actual_rpm(device, crate::types::FanZone::Zone1)?,
        fan2: command::get_fan_actual_rpm(device, crate::types::FanZone::Zone2)?,
    })
}

/// The profile that should be active for the current power source, or `None` if the
/// active state already matches it (so the caller can skip a redundant re-apply).
/// `current` is the live `device_state`; `ac_state`/`battery_state` are the saved
/// per-source profiles. Encodes the tray event loop's AC<->battery switch rule.
///
/// `active_rule` is the app-profile currently being enforced by "Actions", if any. It
/// MUST be passed, because an Actions override lives only in `device_state` -- by design
/// it never writes `ac_state`/`battery_state`. Without it this comparison sees the
/// override as "drift" from the saved profile and reverts it on the very next tick
/// (~1s), so an app rule would hold for about a second and then silently die. With it,
/// the rule is re-overlaid onto the power-source profile: the AC<->battery switch still
/// happens, but the running app's settings survive it.
pub fn profile_for_power(
    ac_power: bool,
    current: &DeviceState,
    ac_state: &DeviceState,
    battery_state: &DeviceState,
    active_rule: Option<&AppProfile>,
) -> Option<DeviceState> {
    let base = if ac_power { ac_state } else { battery_state };
    // A rule restricted to the other power source must not be re-overlaid here. The
    // process scan that would retire it runs every few seconds, and until then an
    // AC-only Hyperboost rule was being applied on battery right after unplugging.
    let target = match active_rule.filter(|rule| rule.allowed_on(ac_power)) {
        Some(rule) => rule.overlay(base),
        None => *base,
    };
    (*current != target).then_some(target)
}

/// The effective state while an app Action is running, including any picks the user made
/// during it.
///
/// Without this the Action's state was recomputed from the rule on every tick, so a pick
/// of a field the rule overlays (the perf mode, the fan) was reverted about a second
/// later, although the event loop promises "a manual pick mid-session stays put". The
/// session remembers the effective state instead: the rule seeds it, a pick replaces it,
/// and an AC/battery switch moves the picks across to the new power source's overlay.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ActionSession {
    /// Index of the running rule in `ConfigState::app_profiles`.
    pub rule: usize,
    /// What the device should be in while the rule's process runs.
    pub effective: DeviceState,
}

impl ActionSession {
    /// A rule's process just appeared: the session starts as the rule overlaid on the
    /// saved profile for the current power source.
    pub fn start(rule: usize, profile: &AppProfile, base: &DeviceState, range: (u16, u16)) -> Self {
        Self {
            rule,
            effective: profile.overlay(base).normalized(range),
        }
    }

    /// The user picked `picked` while the session ran; it holds until the process exits.
    pub fn pick(&mut self, picked: DeviceState) {
        self.effective = picked;
    }

    /// The power source changed. Re-seed from the new source's saved profile, then carry
    /// over exactly the fields the user changed during the session.
    pub fn power_changed(
        &mut self,
        profile: &AppProfile,
        old_base: &DeviceState,
        new_base: &DeviceState,
        range: (u16, u16),
    ) {
        let old_seed = profile.overlay(old_base).normalized(range);
        let new_seed = profile.overlay(new_base).normalized(range);
        // Normalized again: carrying a Custom-only field (max fan) onto a new source's
        // non-Custom perf mode produced a state the EC cannot hold, which the tray then
        // re-applied every second until the game exited.
        self.effective =
            DeviceState::carry_changes(new_seed, old_seed, self.effective).normalized(range);
    }
}

/// Sample the fans until a reading can be trusted, for one-shot callers (the CLI) that
/// have no running filter of their own.
///
/// About 3 in 10 sparse reads on 0x029F carry one impossible zone, and a stop needs two
/// agreeing reads before it is believed (see [`FanRpmFilter`]), so up to `max_reads` samples
/// are taken ~150 ms apart. Returns the trusted value, or the last raw read with `false`
/// when nothing could be confirmed.
pub fn sample_fan_rpm(device: &impl HidTransport, max_reads: usize) -> Result<(FanRpm, bool)> {
    let mut filter = FanRpmFilter::default();
    let mut last = get_fan_rpm(device)?;
    for i in 0..max_reads.max(1) {
        if i > 0 {
            device.pause(std::time::Duration::from_millis(150));
            last = get_fan_rpm(device)?;
        }
        if let Some(trusted) = filter.accept(last) {
            return Ok((trusted, true));
        }
    }
    Ok((last, false))
}

/// Stops counting a zone 2 fan set point as drift once repairing it stops working.
///
/// Zone 2's set point reads back as written on `0x029F` (2026-10-14: 3000 and 4000 RPM both
/// echoed on both zones), and is unmeasured everywhere else. If a chassis reports it
/// differently from what was written, every check would see drift and every repair would
/// rewrite the whole enforced profile, forever. So after [`ZONE2_MAX_REPAIRS`] detections in a
/// row with no agreeing read between them, the zone 2 check is off until the tray restarts,
/// with one warning in the log. Drift in any other field is unaffected.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct Zone2DriftGuard {
    unrepaired: u8,
    given_up: bool,
}

/// Zone 2 repairs in a row that may fail before [`Zone2DriftGuard`] stops checking.
pub const ZONE2_MAX_REPAIRS: u8 = 3;

impl Zone2DriftGuard {
    /// Record one zone 2 drift detection; returns whether to treat it as drift.
    fn drift_seen(&mut self) -> bool {
        if self.unrepaired >= ZONE2_MAX_REPAIRS {
            self.given_up = true;
            log::warn!(
                "zone 2 fan set point still off target after {ZONE2_MAX_REPAIRS} repairs; \
                 no longer checking zone 2 until the tray restarts"
            );
            return false;
        }
        self.unrepaired += 1;
        true
    }

    pub fn given_up(&self) -> bool {
        self.given_up
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rpm(fan1: u16, fan2: u16) -> FanRpm {
        FanRpm { fan1, fan2 }
    }

    fn dstate(perf: PerfMode, fan: FanSpeed, brightness: u8) -> DeviceState {
        DeviceState {
            perf_mode: perf,
            lights_mode: LightsMode {
                logo_mode: LogoMode::Off,
                keyboard_brightness: brightness,
                always_on: LightsAlwaysOn::Disable,
                keyboard_effect: None,
                keyboard_color: None,
            },
            battery_care: BatteryCare::DISABLE,
            fan_speed: fan,
            max_fan: false,
            display_refresh_hz: None,
        }
    }

    #[test]
    fn a_pick_made_during_an_action_saves_only_what_the_user_picked() {
        // The reported failure, exactly: saved AC profile is Balanced/Auto, a game Action
        // overlays Hyperboost/Manual 4000, then the user changes keyboard brightness. The
        // saved profile must gain the brightness and NOTHING else -- before this fix it
        // also acquired Hyperboost and Manual 4000, so closing the game reverted to a
        // contaminated profile.
        let saved = dstate(PerfMode::Balanced, FanSpeed::Auto, 100);
        let overlaid = dstate(PerfMode::Hyperboost, FanSpeed::Manual(4000), 100);
        let picked = dstate(PerfMode::Hyperboost, FanSpeed::Manual(4000), 200);

        let out = DeviceState::carry_changes(saved, overlaid, picked);

        assert_eq!(out.lights_mode.keyboard_brightness, 200);
        assert_eq!(out.perf_mode, PerfMode::Balanced);
        assert_eq!(out.fan_speed, FanSpeed::Auto);
    }

    #[test]
    fn with_no_action_overlay_the_merge_is_the_old_wholesale_assignment() {
        // base == before is the no-Action path. Narrowing must not change it at all,
        // otherwise this fix would be a regression on the common case.
        let saved = dstate(PerfMode::Balanced, FanSpeed::Auto, 100);
        let picked = dstate(PerfMode::Silent, FanSpeed::Manual(2000), 50);

        assert_eq!(DeviceState::carry_changes(saved, saved, picked), picked);
    }

    #[test]
    fn a_pick_that_changes_the_field_the_action_set_still_reaches_the_saved_profile() {
        // The user explicitly picking the same axis the Action drives is a real intent to
        // change the saved profile, not contamination -- it must not be swallowed.
        let saved = dstate(PerfMode::Balanced, FanSpeed::Auto, 100);
        let overlaid = dstate(PerfMode::Hyperboost, FanSpeed::Manual(4000), 100);
        let picked = dstate(PerfMode::Silent, FanSpeed::Manual(4000), 100);

        let out = DeviceState::carry_changes(saved, overlaid, picked);

        assert_eq!(out.perf_mode, PerfMode::Silent);
        assert_eq!(out.fan_speed, FanSpeed::Auto);
    }

    #[test]
    fn lone_zero_is_flagged_in_either_direction_and_a_real_stop_is_not() {
        assert!(rpm(0, 1800).is_lone_zero());
        assert!(rpm(2000, 0).is_lone_zero());
        assert!(!rpm(0, 0).is_lone_zero());
        assert!(!rpm(2000, 1900).is_lone_zero());
        assert!(rpm(0, 0).is_stopped());
        assert!(!rpm(0, 1800).is_stopped());
    }

    #[test]
    fn legitimate_auto_asymmetry_is_never_treated_as_a_bad_read() {
        // Measured idle pairs on 0x029F. If the filter ever rejected these it would freeze
        // the display during normal operation, which is worse than the bug it fixes.
        let mut f = FanRpmFilter::default();
        for pair in [rpm(2000, 1900), rpm(2000, 1800), rpm(2100, 1900)] {
            assert_eq!(f.accept(pair), Some(pair));
        }
    }

    #[test]
    fn a_lone_zero_read_leaves_the_previous_value_standing() {
        let mut f = FanRpmFilter::default();
        assert_eq!(f.accept(rpm(2000, 1900)), Some(rpm(2000, 1900)));
        // The exact sequence measured at 30 s spacing on 2026-08-15, which is what put a
        // spurious "0" on screen: none of it may reach the display.
        assert_eq!(f.accept(rpm(0, 1800)), Some(rpm(2000, 1900)));
        assert_eq!(f.accept(rpm(2000, 0)), Some(rpm(2000, 1900)));
        assert_eq!(f.accept(rpm(0, 1800)), Some(rpm(2000, 1900)));
    }

    #[test]
    fn a_stop_needs_two_consecutive_reads_to_publish() {
        let mut f = FanRpmFilter::default();
        f.accept(rpm(2000, 1900));
        assert_eq!(
            f.accept(rpm(0, 0)),
            Some(rpm(2000, 1900)),
            "first stopped read is not enough"
        );
        assert_eq!(f.accept(rpm(0, 0)), Some(rpm(0, 0)), "second confirms it");
        assert_eq!(f.accept(rpm(0, 0)), Some(rpm(0, 0)), "and it stays");
    }

    #[test]
    fn a_lone_zero_does_not_confirm_a_pending_stop() {
        // The trap: treating any zero-containing read as corroboration would let one real
        // stopped sample plus one impossible one publish a stop that never happened.
        let mut f = FanRpmFilter::default();
        f.accept(rpm(2000, 1900));
        f.accept(rpm(0, 0));
        assert_eq!(f.accept(rpm(0, 1800)), Some(rpm(2000, 1900)));
        assert_eq!(
            f.accept(rpm(1800, 1800)),
            Some(rpm(1800, 1800)),
            "a running read clears the pending stop and publishes normally"
        );
    }

    #[test]
    fn a_running_read_between_two_stops_resets_the_confirmation() {
        let mut f = FanRpmFilter::default();
        f.accept(rpm(2000, 1900));
        f.accept(rpm(0, 0));
        assert_eq!(f.accept(rpm(1100, 1100)), Some(rpm(1100, 1100)));
        assert_eq!(
            f.accept(rpm(0, 0)),
            Some(rpm(1100, 1100)),
            "the earlier stop must not count toward this one"
        );
        assert_eq!(f.accept(rpm(0, 0)), Some(rpm(0, 0)));
    }

    #[test]
    fn ramp_values_publish_immediately_and_are_not_smoothed() {
        // The Auto spin-down measured on 2026-08-15. Every step must appear as-is: these
        // are speeds the fan passes through, and averaging them away would make a ramp
        // indistinguishable from a held speed -- the exact confusion this hardware causes.
        let mut f = FanRpmFilter::default();
        for v in [2000, 1800, 1600, 1500, 1300, 1100] {
            assert_eq!(f.accept(rpm(v, v)), Some(rpm(v, v)));
        }
    }

    #[test]
    fn nothing_is_published_until_a_trustworthy_read_arrives() {
        let mut f = FanRpmFilter::default();
        assert_eq!(f.accept(rpm(0, 1800)), None);
        assert_eq!(f.published(), None);
        assert_eq!(f.accept(rpm(2000, 1900)), Some(rpm(2000, 1900)));
    }

    /// Helper: one line of parts at ascending priority.
    fn line(parts: &[(u8, &str)]) -> Vec<(u8, String)> {
        parts.iter().map(|(p, t)| (*p, (*t).to_string())).collect()
    }

    #[test]
    fn utf16_units_counts_surrogate_pairs_as_two() {
        // The bug this whole helper exists for: a char count says 1, Windows says 2.
        assert_eq!("🔋".chars().count(), 1);
        assert_eq!(utf16_units("🔋"), 2);
        assert_eq!(utf16_units("ab🔋"), 4);
    }

    #[test]
    fn fit_tooltip_leaves_a_layout_that_already_fits() {
        let layout = vec![line(&[(0, "Balanced")]), line(&[(1, "Fan Auto")])];
        assert_eq!(fit_tooltip(&layout, 63), "Balanced\nFan Auto");
    }

    #[test]
    fn fit_tooltip_drops_the_highest_priority_number_first() {
        // "Logo Static" is the most expendable field, so it goes before the charge limit.
        let layout = vec![
            line(&[(0, "Balanced")]),
            line(&[(4, "🔋 80%"), (8, "Logo Static")]),
        ];
        let out = fit_tooltip(&layout, 20);
        assert!(
            out.contains("🔋 80%"),
            "charge limit lost too early: {out:?}"
        );
        assert!(
            !out.contains("Logo"),
            "logo should have been dropped: {out:?}"
        );
    }

    #[test]
    fn fit_tooltip_removes_the_newline_of_an_emptied_line() {
        // A line whose every part was shed must not leave a blank line behind.
        let layout = vec![line(&[(0, "Balanced")]), line(&[(9, "Logo Static")])];
        let out = fit_tooltip(&layout, 10);
        assert_eq!(out, "Balanced");
    }

    #[test]
    fn fit_tooltip_never_drops_priority_zero() {
        let layout = vec![
            line(&[(0, "Custom (CPU Undervolt, GPU High)")]),
            line(&[(1, "Fan Auto"), (3, "2600/2500")]),
            line(&[(4, "🔋 80%"), (5, "🔆 82%")]),
        ];
        let out = fit_tooltip(&layout, 40);
        assert!(out.starts_with("Custom"), "mode was dropped: {out:?}");
        assert!(utf16_units(&out) <= 40);
    }

    #[test]
    fn fit_tooltip_hard_truncates_a_single_oversized_field() {
        // Nothing left to shed: cut it, but never mid-surrogate-pair.
        let layout = vec![line(&[(0, "🔋🔋🔋🔋🔋")])];
        let out = fit_tooltip(&layout, 5);
        assert_eq!(utf16_units(&out), 4, "an emoji was split: {out:?}");
        assert!(!out.contains('\u{FFFD}'));
    }

    #[test]
    fn truncate_utf16_respects_the_budget_and_pair_boundaries() {
        assert_eq!(truncate_utf16("abcdef", 3), "abc");
        assert_eq!(truncate_utf16("a🔋b", 2), "a");
        assert_eq!(truncate_utf16("a🔋b", 3), "a🔋");
    }

    #[test]
    fn percent_to_brightness_spans_full_range() {
        // The submenu's 10% steps must map onto the device's full 0..=255 scale.
        assert_eq!(percent_to_brightness(0), 0);
        assert_eq!(percent_to_brightness(100), 255);
        assert_eq!(percent_to_brightness(50), 128); // rounds 127.5 up
        assert_eq!(percent_to_brightness(10), 26); // rounds 25.5 up
    }

    #[test]
    fn percent_to_brightness_is_monotonic() {
        let mut prev = 0u8;
        for p in (0u8..=100).step_by(10) {
            let b = percent_to_brightness(p);
            assert!(b >= prev, "brightness must not decrease as percent rises");
            prev = b;
        }
    }

    #[test]
    fn brightness_percent_round_trips_on_menu_steps() {
        // The tooltip converts raw->percent; the menu converts percent->raw. For the
        // 10% menu steps the round trip must land back on the same percent.
        for p in (0u8..=100).step_by(10) {
            assert_eq!(brightness_to_percent(percent_to_brightness(p)), p);
        }
    }

    #[test]
    fn delta_promotes_non_custom_mode_to_custom() {
        // Picking a CPU/GPU boost from a non-Custom mode should switch into Custom,
        // seeding the *other* axis with the documented default.
        let base = DeviceState {
            perf_mode: PerfMode::Balanced,
            ..Default::default()
        };
        match base.delta(CpuBoost::Low).perf_mode {
            PerfMode::Custom(cpu, gpu) => {
                assert_eq!(cpu, CpuBoost::Low);
                assert_eq!(gpu, GpuBoost::High); // default seeded for the untouched axis
            }
            other => panic!("expected Custom, got {other:?}"),
        }
    }

    #[test]
    fn delta_preserves_the_other_axis_within_custom() {
        let custom = DeviceState {
            perf_mode: PerfMode::Custom(CpuBoost::Medium, GpuBoost::Low),
            ..Default::default()
        };
        // Changing GPU keeps the existing CPU boost.
        match custom.delta(GpuBoost::High).perf_mode {
            PerfMode::Custom(cpu, gpu) => {
                assert_eq!(cpu, CpuBoost::Medium);
                assert_eq!(gpu, GpuBoost::High);
            }
            other => panic!("expected Custom, got {other:?}"),
        }
    }

    #[test]
    fn config_default_battery_profile_is_low_power() {
        // The battery profile should default to the Battery perf mode; AC stays at
        // the DeviceState default (Performance).
        let cfg = ConfigState::default();
        assert_eq!(cfg.battery_state.perf_mode, PerfMode::Battery);
        assert_eq!(cfg.ac_state.perf_mode, PerfMode::Performance);
        assert!(!cfg.enforce);
        // Actions defaults: resume re-assert on, no app rules.
        assert!(cfg.reassert_on_resume);
        assert!(cfg.app_profiles.is_empty());
    }

    /// Helper: a rule matching `process`, everything else default.
    fn rule(process: &str) -> AppProfile {
        AppProfile {
            process: process.into(),
            ..Default::default()
        }
    }

    #[test]
    fn matching_app_profile_matches_case_insensitively() {
        let profiles = vec![rule("game.exe"), rule("editor.exe")];

        // No listed process running -> None.
        let running = vec!["explorer.exe".to_string(), "svchost.exe".to_string()];
        assert_eq!(matching_app_profile(&profiles, &running, true), None);

        // Case-insensitive match on the executable name.
        let running = vec!["Game.EXE".to_string()];
        assert_eq!(matching_app_profile(&profiles, &running, true), Some(0));

        // Only the second rule's process is up.
        let running = vec!["editor.exe".to_string()];
        assert_eq!(matching_app_profile(&profiles, &running, true), Some(1));

        // Empty rule set never matches.
        assert_eq!(matching_app_profile(&[], &running, true), None);
    }

    #[test]
    fn equal_priority_falls_back_to_file_order() {
        // Both match at priority 0: the earlier rule wins, as it always did.
        let profiles = vec![rule("game.exe"), rule("editor.exe")];
        let running = vec!["editor.exe".to_string(), "game.exe".to_string()];
        assert_eq!(matching_app_profile(&profiles, &running, true), Some(0));
    }

    #[test]
    fn higher_priority_beats_file_order() {
        // The whole point of priority: intent is expressed in the file, not by which
        // rule the user happened to type first.
        let profiles = vec![
            rule("launcher.exe"),
            AppProfile {
                priority: 10,
                ..rule("game.exe")
            },
        ];
        let running = vec!["launcher.exe".to_string(), "game.exe".to_string()];
        assert_eq!(matching_app_profile(&profiles, &running, true), Some(1));
    }

    #[test]
    fn a_disabled_rule_never_matches() {
        let profiles = vec![AppProfile {
            enabled: false,
            ..rule("game.exe")
        }];
        let running = vec!["game.exe".to_string()];
        assert_eq!(matching_app_profile(&profiles, &running, true), None);
    }

    #[test]
    fn require_ac_gates_on_the_power_source() {
        // The guard that stops "force Hyperboost while the game runs" from doing that on
        // battery.
        let ac_only = vec![AppProfile {
            require_ac: Some(true),
            ..rule("game.exe")
        }];
        let running = vec!["game.exe".to_string()];
        assert_eq!(matching_app_profile(&ac_only, &running, true), Some(0));
        assert_eq!(matching_app_profile(&ac_only, &running, false), None);

        let battery_only = vec![AppProfile {
            require_ac: Some(false),
            ..rule("game.exe")
        }];
        assert_eq!(
            matching_app_profile(&battery_only, &running, false),
            Some(0)
        );
        assert_eq!(matching_app_profile(&battery_only, &running, true), None);

        // Unset: either source.
        let any = vec![rule("game.exe")];
        assert_eq!(matching_app_profile(&any, &running, true), Some(0));
        assert_eq!(matching_app_profile(&any, &running, false), Some(0));
    }

    #[test]
    fn a_rule_can_list_several_executables() {
        let profiles = vec![AppProfile {
            processes: vec!["game_dx12.exe".into(), "game_vulkan.exe".into()],
            ..rule("game.exe")
        }];
        for exe in ["game.exe", "game_dx12.exe", "GAME_VULKAN.EXE"] {
            assert_eq!(
                matching_app_profile(&profiles, &[exe.to_string()], true),
                Some(0),
                "{exe} should match"
            );
        }
        assert_eq!(
            matching_app_profile(&profiles, &["other.exe".to_string()], true),
            None
        );
    }

    /// An empty `process` must not match every running executable. Guards the case where
    /// a rule uses only `processes` and leaves the legacy field blank.
    #[test]
    fn an_empty_process_name_matches_nothing() {
        let profiles = vec![AppProfile {
            process: String::new(),
            processes: vec!["game.exe".into()],
            ..Default::default()
        }];
        assert_eq!(
            matching_app_profile(&profiles, &["anything.exe".to_string()], true),
            None
        );
        assert_eq!(
            matching_app_profile(&profiles, &["game.exe".to_string()], true),
            Some(0)
        );
    }

    /// Load-bearing back-compat: the tray reads config with `unwrap_or_default()`, so a
    /// rule the new schema can't parse would silently discard every saved profile rather
    /// than report an error. A pre-upgrade rule has only `process` and the optional
    /// overlay fields.
    #[test]
    fn a_pre_upgrade_rule_still_deserializes_and_stays_enabled() {
        let toml = r#"
            process = "cyberpunk2077.exe"
            perf_mode = "Hyperboost"
        "#;
        let parsed: AppProfile = toml::from_str(toml).expect("legacy rule must still parse");
        assert_eq!(parsed.process, "cyberpunk2077.exe");
        assert_eq!(parsed.perf_mode, Some(PerfMode::Hyperboost));
        assert!(parsed.enabled, "an existing rule must remain active");
        assert_eq!(parsed.priority, 0);
        assert_eq!(parsed.require_ac, None);
        assert!(parsed.processes.is_empty());
        assert_eq!(parsed.label(), "cyberpunk2077.exe");
    }

    #[test]
    fn app_profile_overlay_applies_only_set_fields() {
        let base = DeviceState {
            perf_mode: PerfMode::Balanced,
            fan_speed: FanSpeed::Auto,
            ..Default::default()
        };
        // A perf-only rule changes perf and leaves fan/logo alone.
        let perf_only = AppProfile {
            process: "game.exe".into(),
            perf_mode: Some(PerfMode::Hyperboost),
            fan_speed: None,
            logo_mode: None,
            keyboard_effect: None,
            keyboard_color: None,
            ..Default::default()
        };
        let out = perf_only.overlay(&base);
        assert_eq!(out.perf_mode, PerfMode::Hyperboost);
        assert_eq!(out.fan_speed, base.fan_speed);
        assert_eq!(out.lights_mode.logo_mode, base.lights_mode.logo_mode);

        // A fan-only rule leaves perf untouched.
        let fan_only = AppProfile {
            process: "zoom.exe".into(),
            perf_mode: None,
            fan_speed: Some(FanSpeed::Manual(3000)),
            logo_mode: None,
            keyboard_effect: None,
            keyboard_color: None,
            ..Default::default()
        };
        let out = fan_only.overlay(&base);
        assert_eq!(out.perf_mode, PerfMode::Balanced);
        assert_eq!(out.fan_speed, FanSpeed::Manual(3000));
    }

    #[test]
    fn app_profile_overlay_carries_keyboard_lighting() {
        // A lighting rule sets the effect and leaves perf/fan/logo alone.
        let base = DeviceState::default();
        let lit = AppProfile {
            process: "game.exe".into(),
            perf_mode: None,
            fan_speed: None,
            logo_mode: None,
            keyboard_effect: Some(KeyboardEffect::Spectrum),
            keyboard_color: None,
            ..Default::default()
        };
        let out = lit.overlay(&base);
        assert_eq!(
            out.lights_mode.keyboard_effect,
            Some(KeyboardEffect::Spectrum)
        );
        assert_eq!(out.perf_mode, base.perf_mode);
        assert_eq!(out.fan_speed, base.fan_speed);
    }

    #[test]
    fn apply_writes_effect_only_when_configured() {
        use crate::transport::MockTransport;

        // Default (keyboard_effect: None) -> apply() must NOT emit the effect command 0x0f02,
        // so existing brightness-only behavior is preserved (no lighting regression).
        let none_mock = MockTransport::echo();
        DeviceState::default().apply(&none_mock).unwrap();
        let cmds: Vec<u16> = none_mock.sent().iter().map(|(c, _)| *c).collect();
        assert!(
            !cmds.contains(&0x0f02),
            "no effect configured -> no 0x0f02 write"
        );

        // With an effect set, apply() emits 0x0f02 AND re-asserts brightness (0x0303) after it,
        // so the effect write can't leave the backlight at the wrong brightness.
        let mut lit = DeviceState::default();
        lit.lights_mode.keyboard_effect = Some(KeyboardEffect::Spectrum);
        lit.lights_mode.keyboard_brightness = 200;
        let lit_mock = MockTransport::echo();
        lit.apply(&lit_mock).unwrap();
        let sent: Vec<u16> = lit_mock.sent().iter().map(|(c, _)| *c).collect();
        let effect_at = sent
            .iter()
            .position(|c| *c == 0x0f02)
            .expect("effect written");
        let bright_at = sent
            .iter()
            .position(|c| *c == 0x0303)
            .expect("brightness written");
        assert!(
            effect_at < bright_at,
            "brightness must be re-asserted after the effect write"
        );
    }

    // ---- device-facing logic, exercised through MockTransport (no hardware) ------

    use crate::packet::Packet;
    use crate::transport::MockTransport;

    /// Canned register response whose args begin with `args` (rest zero).
    fn reply(args: &[u8]) -> Packet {
        let mut p = Packet::new(0, &[]);
        p.set_args(args);
        p
    }

    #[test]
    fn read_assembles_state_from_register_reads() {
        use crate::types::{FanMode, PerfMode as Wire};
        let mock = MockTransport::with_responder(|req| match req.command() {
            0x0d82 => reply(&[0, 0, Wire::Performance as u8, FanMode::Auto as u8]),
            0x0380 => reply(&[1, 4, 0]), // logo power off -> LogoMode::Off
            0x0383 => reply(&[1, 5, 200]), // keyboard brightness (id 5)
            0x0084 => reply(&[LightsAlwaysOn::Disable as u8, 0]),
            // 0x0f82: keyboard effect getter (LED region 5 = backlight), id 3 = Spectrum.
            0x0f82 => reply(&[1, 5, 0x03]),
            0x0792 => reply(&[BatteryCare::from_percent(80).unwrap().wire_byte()]),
            other => panic!("unexpected command {other:#06x}"),
        });
        let expected = DeviceState {
            perf_mode: PerfMode::Performance,
            lights_mode: LightsMode {
                logo_mode: LogoMode::Off,
                keyboard_brightness: 200,
                always_on: LightsAlwaysOn::Disable,
                // Now READ back from the device (0x0f82) rather than assumed unknown.
                keyboard_effect: Some(KeyboardEffect::Spectrum),
                keyboard_color: None,
            },
            battery_care: BatteryCare::from_percent(80).unwrap(),
            fan_speed: FanSpeed::Auto,
            max_fan: false,
            display_refresh_hz: None,
        };
        assert_eq!(DeviceState::read(&mock).unwrap(), expected);
    }

    #[test]
    fn read_custom_mode_pulls_cpu_and_gpu_boosts() {
        use crate::types::{FanMode, PerfMode as Wire};
        let mock = MockTransport::with_responder(|req| match req.command() {
            0x0d82 => reply(&[0, 0, Wire::Custom as u8, FanMode::Auto as u8]),
            // _get_boost echoes the cluster at args[1]; cpu(1)->Boost, gpu(2)->High.
            0x0d87 => {
                let cluster = req.get_args()[1];
                let boost = if cluster == 1 {
                    CpuBoost::Boost as u8
                } else {
                    GpuBoost::High as u8
                };
                reply(&[0, cluster, boost])
            }
            0x0380 => reply(&[1, 4, 0]),
            0x0383 => reply(&[1, 5, 0]),
            0x0084 => reply(&[LightsAlwaysOn::Disable as u8, 0]),
            0x0f82 => reply(&[1, 5, 0x03]),
            0x0792 => reply(&[BatteryCare::from_percent(80).unwrap().wire_byte()]),
            0x078f => reply(&[MaxFanSpeedMode::Disable as u8]), // Custom perf -> read() queries max fan
            other => panic!("unexpected command {other:#06x}"),
        });
        assert_eq!(
            DeviceState::read(&mock).unwrap().perf_mode,
            PerfMode::Custom(CpuBoost::Boost, GpuBoost::High)
        );
    }

    #[test]
    fn apply_writes_brightness_and_battery_but_not_device_mode_or_enforce_brightness() {
        // The documented contract: apply() writes brightness (0x0303) and battery care
        // (0x0712) but must NOT write device mode (0x0004) -- driver mode breaks the Fn
        // keys, so always-on is a Normal-mode keep-alive instead. enforce_to() writes
        // battery but must NOT touch brightness.
        let state = DeviceState::default(); // Performance / Auto / logo Off -> simple write path

        let apply_mock = MockTransport::echo();
        state.apply(&apply_mock).unwrap();
        let applied: Vec<u16> = apply_mock.sent().iter().map(|(c, _)| *c).collect();
        assert!(
            applied.contains(&0x0303),
            "apply writes keyboard brightness"
        );
        assert!(applied.contains(&0x0712), "apply writes battery care");
        assert!(
            !applied.contains(&0x0004),
            "apply must NOT set device mode (driver mode breaks Fn keys)"
        );

        let enforce_mock = MockTransport::echo();
        state.enforce_to(&enforce_mock).unwrap();
        let enforced: Vec<u16> = enforce_mock.sent().iter().map(|(c, _)| *c).collect();
        assert!(
            enforced.contains(&0x0712),
            "enforce_to still asserts battery care"
        );
        assert!(
            !enforced.contains(&0x0303),
            "enforce_to must not touch brightness"
        );
        assert!(
            !enforced.contains(&0x0004),
            "enforce_to must not touch device mode"
        );
    }

    #[test]
    fn enforced_fields_differ_ignores_brightness_and_always_on() {
        let base = DeviceState::default();

        // Identical -> no drift.
        assert!(!base.enforced_fields_differ(&base));

        // Brightness / always-on are NOT enforced fields -> still no drift.
        let mut cosmetic = base;
        cosmetic.lights_mode.keyboard_brightness = 123;
        cosmetic.lights_mode.always_on = LightsAlwaysOn::Enable;
        assert!(!cosmetic.enforced_fields_differ(&base));

        // Enforced fields -> drift.
        let mut other_perf = base;
        other_perf.perf_mode = PerfMode::Silent;
        assert!(other_perf.enforced_fields_differ(&base));

        let mut other_batt = base;
        other_batt.battery_care = BatteryCare::DISABLE;
        assert!(other_batt.enforced_fields_differ(&base));
    }

    #[test]
    fn drifted_from_sees_a_zone_2_set_point_left_behind() {
        // Zone 1 at 3000 as intended, zone 2 still at 4000: a zone-1-only read matched
        // intent, so Enforce never repaired it.
        let mock = MockTransport::with_responder(|req| {
            let zone = req.get_args()[1];
            reply(&[0, zone, if zone == 1 { 30 } else { 40 }])
        });
        let s = dstate(PerfMode::Silent, FanSpeed::Manual(3000), 0);
        assert!(!s.enforced_fields_differ(&s));
        assert!(s.drifted_from(&s, &mock, &mut Zone2DriftGuard::default()));
    }

    #[test]
    fn drifted_from_reads_nothing_more_outside_manual_or_on_known_drift() {
        let mock = MockTransport::echo();
        let auto = dstate(PerfMode::Silent, FanSpeed::Auto, 0);
        assert!(!auto.drifted_from(&auto, &mock, &mut Zone2DriftGuard::default()));
        let manual = dstate(PerfMode::Silent, FanSpeed::Manual(3000), 0);
        assert!(manual.drifted_from(&auto, &mock, &mut Zone2DriftGuard::default()));
        assert_eq!(mock.sent_count(), 0);
    }

    #[test]
    fn zone_2_check_stops_after_repairs_fail_and_resumes_counting_after_agreement() {
        let off = MockTransport::with_responder(|req| {
            let zone = req.get_args()[1];
            reply(&[0, zone, if zone == 1 { 30 } else { 40 }])
        });
        let s = dstate(PerfMode::Silent, FanSpeed::Manual(3000), 0);
        let mut guard = Zone2DriftGuard::default();
        for _ in 0..ZONE2_MAX_REPAIRS {
            assert!(s.drifted_from(&s, &off, &mut guard));
        }
        assert!(
            !s.drifted_from(&s, &off, &mut guard),
            "gives up after the cap"
        );
        assert!(guard.given_up());
        let before = off.sent_count();
        assert!(!s.drifted_from(&s, &off, &mut guard));
        assert_eq!(off.sent_count(), before, "no zone 2 reads once given up");

        // An agreeing read in between resets the count.
        let ok = MockTransport::with_responder(|req| reply(&[0, req.get_args()[1], 30]));
        let mut guard = Zone2DriftGuard::default();
        for _ in 0..ZONE2_MAX_REPAIRS {
            assert!(s.drifted_from(&s, &off, &mut guard));
        }
        assert!(!s.drifted_from(&s, &ok, &mut guard));
        assert!(s.drifted_from(&s, &off, &mut guard));
        assert!(!guard.given_up());
    }

    #[test]
    fn drifted_from_treats_a_failed_zone_2_read_as_no_drift() {
        // The set-point getter demands the zone echoed back; a wrong one is a failed read.
        let mock = MockTransport::with_responder(|_| reply(&[0, 9, 40]));
        let s = dstate(PerfMode::Silent, FanSpeed::Manual(3000), 0);
        assert!(!s.drifted_from(&s, &mock, &mut Zone2DriftGuard::default()));
    }

    #[test]
    fn profile_for_power_switches_only_on_mismatch() {
        let ac = DeviceState::default(); // Performance
        let batt = DeviceState {
            perf_mode: PerfMode::Battery,
            ..Default::default()
        };

        // On AC but currently running the battery profile -> switch to AC.
        assert_eq!(profile_for_power(true, &batt, &ac, &batt, None), Some(ac));
        // On AC and already on the AC profile -> no switch.
        assert_eq!(profile_for_power(true, &ac, &ac, &batt, None), None);
        // On battery but running AC profile -> switch to battery.
        assert_eq!(profile_for_power(false, &ac, &ac, &batt, None), Some(batt));
        // On battery and already on battery profile -> no switch.
        assert_eq!(profile_for_power(false, &batt, &ac, &batt, None), None);
    }

    #[test]
    fn profile_for_power_does_not_revert_an_active_app_override() {
        // Regression: an Actions override lives ONLY in device_state (update_transient
        // never touches ac_state/battery_state). Without knowing the active rule, the
        // AC/battery check saw the override as drift and reverted it on the next ~1s
        // tick -- so an app profile held for about a second and then died.
        let ac = DeviceState::default(); // Performance
        let batt = DeviceState {
            perf_mode: PerfMode::Battery,
            ..Default::default()
        };
        let rule = AppProfile {
            process: "game.exe".into(),
            perf_mode: Some(PerfMode::Hyperboost),
            fan_speed: None,
            logo_mode: None,
            keyboard_effect: None,
            keyboard_color: None,
            ..Default::default()
        };

        // On AC with the rule applied, the live state IS the overlay -> nothing to do.
        let overridden = rule.overlay(&ac);
        assert_eq!(
            profile_for_power(true, &overridden, &ac, &batt, Some(&rule)),
            None,
            "an active app override must not be treated as drift"
        );

        // Same state, but the rule is no longer active (app exited) -> revert to AC.
        assert_eq!(
            profile_for_power(true, &overridden, &ac, &batt, None),
            Some(ac),
            "once the rule is gone the override must be reverted"
        );
    }

    #[test]
    fn profile_for_power_reoverlays_the_rule_across_a_power_switch() {
        // Unplugging while a rule is active must still switch to the battery profile,
        // but the running app's settings have to survive the switch.
        let ac = DeviceState::default(); // Performance
        let batt = DeviceState {
            perf_mode: PerfMode::Battery,
            ..Default::default()
        };
        // A fan-only rule, so we can see the base perf mode change underneath it.
        let rule = AppProfile {
            process: "game.exe".into(),
            perf_mode: None,
            fan_speed: Some(FanSpeed::Manual(3000)),
            logo_mode: None,
            keyboard_effect: None,
            keyboard_color: None,
            ..Default::default()
        };

        let on_ac = rule.overlay(&ac);
        let target = profile_for_power(false, &on_ac, &ac, &batt, Some(&rule))
            .expect("unplugging must still switch profiles");
        // Base switched to the battery profile...
        assert_eq!(target.perf_mode, PerfMode::Battery);
        // ...while the rule's fan setting was re-applied on top.
        assert_eq!(target.fan_speed, FanSpeed::Manual(3000));
    }

    // ---- apply_perf_fan_logo: one failed write must not skip the others -----------

    /// A transport that fails a chosen command and echoes everything else, recording
    /// which commands were attempted.
    fn failing_on(command: u16) -> crate::transport::MockTransport {
        crate::transport::MockTransport::with_responder(move |req| {
            if req.command() == command {
                // A non-echoing reply fails the `starts_with(args)` check in
                // `_send_command`, which is how a rejected write surfaces.
                Packet::new(req.command(), &[0xff, 0xff, 0xff, 0xff])
            } else {
                Packet::new(req.command(), req.get_args())
            }
        })
    }

    #[test]
    fn apply_still_writes_fan_and_logo_when_the_perf_write_fails() {
        let state = DeviceState {
            perf_mode: PerfMode::Balanced,
            fan_speed: FanSpeed::Manual(3000),
            ..DeviceState::default()
        };

        // 0x0d02 is the perf-mode write. Before the fix its failure aborted the whole
        // sequence, leaving the fan and logo on their previous settings.
        let mock = failing_on(0x0d02);
        let err = state.apply_perf_fan_logo(&mock);
        assert!(err.is_err(), "a failed perf write must still be reported");

        let commands: Vec<u16> = mock.sent().into_iter().map(|(c, _)| c).collect();
        // The fan write shares command 0x0d02 with the perf write (set_fan_mode re-sends
        // the perf packet with a new fan mode), so a second 0x0d02 is the fan attempt.
        assert!(
            commands.iter().filter(|&&c| c == 0x0d02).count() >= 2,
            "fan write must still be attempted, got {commands:04x?}"
        );
        assert!(
            commands.contains(&0x0300),
            "logo write must still be attempted, got {commands:04x?}"
        );
    }

    #[test]
    fn a_rejected_write_does_not_stop_brightness_or_the_charge_limit() {
        let state = DeviceState {
            perf_mode: PerfMode::Balanced,
            ..DeviceState::default()
        };
        let mock = failing_on(0x0300);
        assert!(
            state.apply(&mock).is_err(),
            "the logo rejection must be reported"
        );
        let commands: Vec<u16> = mock.sent().into_iter().map(|(c, _)| c).collect();
        assert!(
            commands.contains(&0x0303),
            "brightness skipped: {commands:04x?}"
        );
        assert!(
            commands.contains(&0x0712),
            "charge limit skipped: {commands:04x?}"
        );

        let mock = failing_on(0x0300);
        assert!(state.enforce_to(&mock).is_err());
        assert!(mock.sent().iter().any(|(c, _)| *c == 0x0712));
    }

    #[test]
    fn apply_reports_a_logo_failure_when_perf_succeeded() {
        let state = DeviceState {
            perf_mode: PerfMode::Balanced,
            ..DeviceState::default()
        };
        let mock = failing_on(0x0300);
        assert!(
            state.apply_perf_fan_logo(&mock).is_err(),
            "a failed logo write must not be swallowed"
        );
    }

    #[test]
    fn apply_succeeds_when_every_write_is_accepted() {
        let state = DeviceState {
            perf_mode: PerfMode::Balanced,
            fan_speed: FanSpeed::Manual(3000),
            ..DeviceState::default()
        };
        let mock = crate::transport::MockTransport::echo();
        assert!(state.apply_perf_fan_logo(&mock).is_ok());
    }

    /// Pin the HID cost of a `read()`.
    ///
    /// `read()` runs on the tray's hover and Mirror paths, so its round-trip count is a
    /// user-visible latency budget, not a micro-optimisation. It previously called
    /// `get_perf_mode()` twice -- once for the perf mode, once for the fan mode -- and
    /// because each call reads both fan zones that cost 4 round-trips where 2 do. A
    /// number here is worth more than a comment: if a future edit reintroduces a
    /// duplicate read, this fails loudly instead of quietly doubling the poll cost.
    #[test]
    fn read_does_not_issue_duplicate_perf_mode_queries() {
        use crate::transport::MockTransport;

        // Custom + Manual fan: the most expensive branch (adds boost and setpoint reads).
        let mock = MockTransport::with_responder(|req| {
            let mut p = crate::packet::Packet::new(req.command(), &[]);
            match req.command() {
                0x0d82 => p.set_args(&[
                    0,
                    0,
                    crate::types::PerfMode::Custom as u8,
                    crate::types::FanMode::Manual as u8,
                ]),
                // Answer per cluster: GpuBoost only decodes 0..=2, so echoing the CPU
                // value (Boost = 3) at the GPU would fail the conversion, not the count.
                0x0d87 => {
                    let cluster = req.get_args()[1];
                    let value = if cluster == crate::types::Cluster::Cpu as u8 {
                        CpuBoost::Boost as u8
                    } else {
                        GpuBoost::High as u8
                    };
                    p.set_args(&[0, cluster, value])
                }
                0x0d81 => p.set_args(&[0, req.get_args()[1], 30]),
                0x0380 => p.set_args(&[1, 4, 1]),
                0x0382 => p.set_args(&[1, 4, 2]),
                0x0383 => p.set_args(&[1, 5, 200]),
                0x0084 => p.set_args(&[0, 0]),
                0x0f82 => p.set_args(&[1, 5, 0x03]),
                0x0792 => p.set_args(&[BatteryCare::from_percent(80).unwrap().wire_byte()]),
                0x078f => p.set_args(&[MaxFanSpeedMode::Disable as u8]),
                other => panic!("unexpected command {other:#06x}"),
            }
            p
        });

        DeviceState::read(&mock).expect("the canned device should read cleanly");

        // The perf/fan register (0x0d82) is two round-trips -- one per fan zone -- and
        // must be read exactly once for the whole state, not once per field.
        let perf_reads = mock.sent().iter().filter(|(c, _)| *c == 0x0d82).count();
        assert_eq!(
            perf_reads, 2,
            "0x0d82 should be read once (= 2 zone round-trips); a second call means \
             the perf-mode and fan-mode reads have drifted apart again"
        );

        // Whole-state budget. Bump deliberately if a genuinely new register is added.
        assert_eq!(
            mock.sent_count(),
            12,
            "read() round-trip budget changed. History: 13 originally, 11 after removing \
             the duplicate get_perf_mode, 12 once the keyboard-effect getter (0x0f82) \
             was added. Bump deliberately when a genuinely new register is read."
        );
    }

    // ---- pure tray logic, now testable on any host --------------------------------

    #[test]
    fn perf_mode_cycle_visits_every_mode_and_returns_to_start() {
        // The tray's left-click cycle. A missing arm would strand the user in a subset
        // of modes -- clicking forever without reaching, say, Silent.
        let mut seen = Vec::new();
        let mut mode = PerfMode::Battery;
        for _ in 0..6 {
            seen.push(mode);
            mode = next_perf_mode(mode);
        }
        assert_eq!(mode, PerfMode::Battery, "the cycle must close");
        assert_eq!(seen.len(), 6, "six distinct modes");
        for expected in [
            PerfMode::Battery,
            PerfMode::Silent,
            PerfMode::Balanced,
            PerfMode::Performance,
            PerfMode::Hyperboost,
        ] {
            assert!(seen.contains(&expected), "cycle must reach {expected:?}");
        }
        assert!(
            seen.iter().any(|m| matches!(m, PerfMode::Custom(..))),
            "cycle must reach Custom"
        );
    }

    #[test]
    fn perf_mode_cycle_seeds_custom_with_the_documented_boost_defaults() {
        // Entering Custom via the cycle must match what the menu does, or a left-click
        // and a menu pick would land on different boost levels.
        assert_eq!(
            next_perf_mode(PerfMode::Hyperboost),
            PerfMode::Custom(CpuBoost::Boost, GpuBoost::High)
        );
        // Leaving Custom ignores the boosts it held.
        assert_eq!(
            next_perf_mode(PerfMode::Custom(CpuBoost::Low, GpuBoost::Low)),
            PerfMode::Battery
        );
    }

    #[test]
    fn nearest_brightness_percent_always_lands_on_a_menu_step() {
        // Every possible raw value must map to a real 10% step, so the menu always shows
        // exactly one checkmark -- including the Fn-key ladder values that fall between.
        for raw in 0u8..=255 {
            let p = nearest_brightness_percent(raw);
            assert_eq!(p % BRIGHTNESS_PERCENT_STEP, 0, "raw {raw} -> non-step {p}");
            assert!(p <= 100);
        }
    }

    #[test]
    fn nearest_brightness_percent_is_exact_on_the_steps_and_rounds_between() {
        // Exact on our own steps.
        for p in (0u8..=100).step_by(BRIGHTNESS_PERCENT_STEP as usize) {
            assert_eq!(nearest_brightness_percent(percent_to_brightness(p)), p);
        }
        assert_eq!(nearest_brightness_percent(0), 0);
        assert_eq!(nearest_brightness_percent(255), 100);
        // 130 sits just above 50% (128) -> nearest is still 50.
        assert_eq!(nearest_brightness_percent(130), 50);
        // 210 is the value the maintainer's config holds; it lies between 80% (204) and 90% (230).
        assert_eq!(nearest_brightness_percent(210), 80);
    }

    const RANGE: (u16, u16) = (2000, 5000);

    #[test]
    fn normalizing_clears_max_fan_outside_custom_only() {
        let mut battery = dstate(PerfMode::Battery, FanSpeed::Auto, 0);
        battery.max_fan = true;
        assert!(!battery.normalized(RANGE).max_fan);

        let mut custom = dstate(
            PerfMode::Custom(CpuBoost::Boost, GpuBoost::High),
            FanSpeed::Auto,
            0,
        );
        custom.max_fan = true;
        assert!(custom.normalized(RANGE).max_fan);
    }

    #[test]
    fn normalizing_snaps_a_manual_rpm_to_what_the_hardware_holds() {
        let at = |rpm| dstate(PerfMode::Silent, FanSpeed::Manual(rpm), 0).normalized(RANGE);
        assert_eq!(at(800).fan_speed, FanSpeed::Manual(2000), "floor");
        assert_eq!(at(9000).fan_speed, FanSpeed::Manual(5000), "ceiling");
        assert_eq!(
            at(2050).fan_speed,
            FanSpeed::Manual(2000),
            "wire is rpm/100"
        );
        assert_eq!(
            at(3200).fan_speed,
            FanSpeed::Manual(3200),
            "valid is untouched"
        );
        let auto = dstate(PerfMode::Silent, FanSpeed::Auto, 0);
        assert_eq!(auto.normalized(RANGE), auto);
    }

    #[test]
    fn normalizing_is_idempotent() {
        let mut s = dstate(PerfMode::Balanced, FanSpeed::Manual(2150), 10);
        s.max_fan = true;
        let once = s.normalized(RANGE);
        assert_eq!(once.normalized(RANGE), once);
    }

    #[test]
    fn an_unrepresentable_manual_rpm_never_switches_the_fan_to_manual() {
        let mock = crate::transport::MockTransport::echo();
        let s = dstate(PerfMode::Silent, FanSpeed::Manual(2050), 0);
        let err = s.apply(&mock).unwrap_err();
        assert!(err.to_string().contains("not representable"), "{err}");
        for (cmd, args) in mock.sent() {
            assert_ne!(cmd, 0x0d01, "no set point may be written");
            if cmd == 0x0d02 {
                assert_eq!(args[3], FanMode::Auto as u8, "mode must not go Manual");
            }
        }
    }

    #[test]
    fn a_failed_fan_write_is_reported_not_swallowed() {
        // 0x0d01 answers without echoing its args, which the command layer rejects.
        let mock = crate::transport::MockTransport::with_responder(|req| {
            if req.command() == 0x0d01 {
                crate::packet::Packet::new(req.command(), &[])
            } else {
                crate::packet::Packet::new(req.command(), req.get_args())
            }
        });
        let s = dstate(PerfMode::Silent, FanSpeed::Manual(3000), 0);
        assert!(s.apply(&mock).is_err());
    }

    #[test]
    fn an_ac_only_rule_is_not_overlaid_on_battery() {
        let ac = dstate(PerfMode::Balanced, FanSpeed::Auto, 0);
        let batt = dstate(PerfMode::Battery, FanSpeed::Auto, 0);
        let rule = AppProfile {
            process: "game.exe".into(),
            require_ac: Some(true),
            perf_mode: Some(PerfMode::Hyperboost),
            ..Default::default()
        };
        let running_on_ac = rule.overlay(&ac);
        // Just unplugged: the device is still in the rule's state.
        let target = profile_for_power(false, &running_on_ac, &ac, &batt, Some(&rule));
        assert_eq!(target, Some(batt));
    }

    #[test]
    fn a_pick_during_an_action_holds_until_the_process_exits() {
        let ac = dstate(PerfMode::Balanced, FanSpeed::Auto, 0);
        let rule = AppProfile {
            process: "game.exe".into(),
            perf_mode: Some(PerfMode::Hyperboost),
            ..Default::default()
        };
        let mut session = ActionSession::start(0, &rule, &ac, RANGE);
        assert_eq!(session.effective.perf_mode, PerfMode::Hyperboost);
        let picked = DeviceState {
            perf_mode: PerfMode::Silent,
            ..session.effective
        };
        session.pick(picked);
        assert_eq!(session.effective.perf_mode, PerfMode::Silent);
    }

    #[test]
    fn a_power_switch_during_an_action_keeps_the_users_picks() {
        let ac = dstate(PerfMode::Balanced, FanSpeed::Auto, 50);
        let batt = dstate(PerfMode::Battery, FanSpeed::Auto, 0);
        let rule = AppProfile {
            process: "game.exe".into(),
            fan_speed: Some(FanSpeed::Manual(4000)),
            ..Default::default()
        };
        let mut session = ActionSession::start(0, &rule, &ac, RANGE);
        // The user turns the fan down during the game.
        session.pick(DeviceState {
            fan_speed: FanSpeed::Manual(3000),
            ..session.effective
        });
        session.power_changed(&rule, &ac, &batt, RANGE);
        // The battery profile's perf mode and brightness, the user's fan pick.
        assert_eq!(session.effective.perf_mode, PerfMode::Battery);
        assert_eq!(session.effective.lights_mode.keyboard_brightness, 0);
        assert_eq!(session.effective.fan_speed, FanSpeed::Manual(3000));
    }

    #[test]
    fn a_power_switch_never_leaves_max_fan_on_outside_custom() {
        // The reviewer's reproduction: AC saved in Custom, max fan turned on during an
        // Action, then unplugged onto a Battery profile.
        let ac = dstate(
            PerfMode::Custom(CpuBoost::Boost, GpuBoost::High),
            FanSpeed::Auto,
            0,
        );
        let batt = dstate(PerfMode::Battery, FanSpeed::Auto, 0);
        let rule = AppProfile {
            process: "game.exe".into(),
            fan_speed: Some(FanSpeed::Manual(4000)),
            ..Default::default()
        };
        let mut session = ActionSession::start(0, &rule, &ac, RANGE);
        session.pick(DeviceState {
            max_fan: true,
            ..session.effective
        });
        session.power_changed(&rule, &ac, &batt, RANGE);
        assert_eq!(session.effective.perf_mode, PerfMode::Battery);
        assert!(!session.effective.max_fan);
        assert_eq!(session.effective, session.effective.normalized(RANGE));
    }

    #[test]
    fn a_config_with_only_action_rules_loads() {
        let cfg: ConfigState = toml::from_str(
            r#"
            [[app_profiles]]
            process = "game.exe"
            perf_mode = "Performance"
            "#,
        )
        .expect("profiles default");
        assert_eq!(cfg.battery_state.perf_mode, PerfMode::Battery);
        assert_eq!(cfg.app_profiles.len(), 1);
    }

    #[test]
    fn the_one_shot_fan_sampler_skips_a_lone_zero_read() {
        use std::cell::Cell;
        let n = Cell::new(0u32);
        // Zone reads alternate 1,2,1,2...; the first zone-2 read is a bogus 0.
        let mock = crate::transport::MockTransport::with_responder(move |req| {
            let i = n.get();
            n.set(i + 1);
            let zone = req.get_args()[1];
            let val = if i == 1 { 0 } else { 30 };
            crate::packet::Packet::new(req.command(), &[0, zone, val])
        });
        let (fans, trusted) = sample_fan_rpm(&mock, 3).unwrap();
        assert!(trusted);
        assert_eq!(fans, rpm(3000, 3000));
    }

    #[test]
    fn the_one_shot_fan_sampler_needs_two_stopped_reads_to_believe_a_stop() {
        let mock = crate::transport::MockTransport::with_responder(|req| {
            crate::packet::Packet::new(req.command(), &[0, req.get_args()[1], 0])
        });
        let (fans, trusted) = sample_fan_rpm(&mock, 1).unwrap();
        assert!(!trusted, "one stopped read is not enough");
        assert!(fans.is_stopped());
        let (_, trusted) = sample_fan_rpm(&mock, 2).unwrap();
        assert!(trusted);
    }

    fn red() -> KeyboardColor {
        KeyboardColor::solid(crate::keyboard::Rgb::new(0xff, 0, 0))
    }

    #[test]
    fn a_custom_color_suppresses_the_effect_write() {
        use crate::transport::MockTransport;
        let mut s = DeviceState::default();
        s.lights_mode.keyboard_effect = Some(KeyboardEffect::Spectrum);
        s.lights_mode.keyboard_color = Some(red());
        let mock = MockTransport::echo();
        s.apply(&mock).unwrap();
        let cmds: Vec<u16> = mock.sent().iter().map(|(c, _)| *c).collect();
        assert!(
            !cmds.contains(&0x0f02),
            "the effect would replace the color"
        );
        assert!(
            !cmds.contains(&0x030b),
            "apply leaves painting to the caller"
        );
        assert!(s.keyboard_frame(None).is_some());
        assert!(DeviceState::default().keyboard_frame(None).is_none());
    }

    #[test]
    fn a_color_pick_is_carried_into_the_saved_profile() {
        let before = DeviceState::default();
        let mut after = before;
        after.lights_mode.keyboard_color = Some(red());
        let out = DeviceState::carry_changes(before, before, after);
        assert_eq!(out.lights_mode.keyboard_color, Some(red()));
    }

    #[test]
    fn an_action_effect_clears_the_color_and_an_action_color_sets_it() {
        let mut base = DeviceState::default();
        base.lights_mode.keyboard_color = Some(red());
        let effect_rule = AppProfile {
            keyboard_effect: Some(KeyboardEffect::Wave),
            ..Default::default()
        };
        let out = effect_rule.overlay(&base);
        assert_eq!(out.lights_mode.keyboard_effect, Some(KeyboardEffect::Wave));
        assert_eq!(out.lights_mode.keyboard_color, None);

        let color_rule = AppProfile {
            keyboard_color: Some(KeyboardColor::FollowPerfMode),
            ..Default::default()
        };
        assert_eq!(
            color_rule.overlay(&base).lights_mode.keyboard_color,
            Some(KeyboardColor::FollowPerfMode)
        );
        // A rule that says nothing about lighting leaves the color alone.
        assert_eq!(
            AppProfile::default()
                .overlay(&base)
                .lights_mode
                .keyboard_color,
            Some(red())
        );
    }

    #[test]
    fn an_old_config_gets_the_default_presets_and_no_color() {
        let cfg: ConfigState = toml::from_str("enforce = true\n").unwrap();
        assert_eq!(cfg.keyboard_presets, crate::keyboard::default_presets());
        assert!(!cfg.keyboard_battery_bar);
        assert_eq!(cfg.ac_state.lights_mode.keyboard_color, None);
    }

    #[test]
    fn a_color_survives_a_config_round_trip() {
        let mut cfg = ConfigState::default();
        cfg.ac_state.lights_mode.keyboard_color = Some(red());
        cfg.battery_state.lights_mode.keyboard_color = Some(KeyboardColor::FollowPerfMode);
        cfg.keyboard_battery_bar = true;
        let text = toml::to_string(&cfg).unwrap();
        assert_eq!(toml::from_str::<ConfigState>(&text).unwrap(), cfg);
    }

    #[test]
    fn the_power_mode_to_put_back_is_kept_per_power_source() {
        let mut cfg = ConfigState::default();
        *cfg.windows_power_mode_before.slot(true) = Some("Balanced".into());
        assert_eq!(cfg.windows_power_mode_before.battery, None);
        let text = toml::to_string(&cfg).unwrap();
        assert_eq!(toml::from_str::<ConfigState>(&text).unwrap(), cfg);
        // Configs from before this field start with nothing to put back.
        let old: ConfigState = toml::from_str("match_windows_power_mode = true\n").unwrap();
        assert_eq!(old.windows_power_mode_before, PowerModeBefore::default());
    }

    /// Written by 0.9.5 (`toml::to_string_pretty`), before the unset flags existed.
    const CONFIG_0_9_5: &str = r##"enforce = true
reassert_on_resume = true
match_windows_power_mode = false
keyboard_battery_bar = false

[ac_state]
battery_care = 80
max_fan = true
display_refresh_hz = 240

[ac_state.perf_mode]
Custom = [
    "Boost",
    "High",
]

[ac_state.lights_mode]
logo_mode = "Off"
keyboard_brightness = 0
always_on = "Disable"

[ac_state.fan_speed]
Manual = 3500

[battery_state]
perf_mode = "Battery"
battery_care = 80
fan_speed = "Auto"
max_fan = false

[battery_state.lights_mode]
logo_mode = "Off"
keyboard_brightness = 0
always_on = "Disable"

[[app_profiles]]
process = "game.exe"
processes = []
enabled = true
priority = 0
perf_mode = "Performance"

[windows_power_mode_before]

[[keyboard_presets]]
name = "White"
colors = ["#ffffff"]
"##;

    #[test]
    fn a_config_from_before_the_unset_flags_loads_and_saves_unchanged() {
        let mut expected = ConfigState::default();
        expected.ac_state.perf_mode = PerfMode::Custom(CpuBoost::Boost, GpuBoost::High);
        expected.ac_state.max_fan = true;
        expected.ac_state.fan_speed = FanSpeed::Manual(3500);
        expected.ac_state.display_refresh_hz = Some(240);
        expected.battery_state.battery_care = BatteryCare::from_percent(80).unwrap();
        expected.enforce = true;
        expected.keyboard_presets.truncate(1);
        expected.app_profiles.push(AppProfile {
            process: "game.exe".into(),
            perf_mode: Some(PerfMode::Performance),
            ..AppProfile::default()
        });

        let cfg: ConfigState = toml::from_str(CONFIG_0_9_5).unwrap();
        assert_eq!(cfg, expected);
        assert!(!cfg.ac_state_unset && !cfg.battery_state_unset);
        assert_eq!(cfg.unset(), crate::observe::Unset::default(), "both set");
        // Saved again, it is byte for byte what 0.9.5 wrote: no new keys appear.
        assert_eq!(toml::to_string_pretty(&cfg).unwrap(), CONFIG_0_9_5);
        // A minimal hand-written file is as set as before too.
        let minimal: ConfigState = toml::from_str("enforce = true\n").unwrap();
        assert_eq!(minimal.unset(), crate::observe::Unset::default());
    }

    #[test]
    fn a_new_config_keeps_its_profiles_unset_across_a_save() {
        let cfg = ConfigState::first_run();
        assert_eq!(
            cfg.unset(),
            crate::observe::Unset {
                ac: true,
                battery: true
            }
        );
        let text = toml::to_string_pretty(&cfg).unwrap();
        assert!(text.contains("ac_state_unset = true"), "{text}");
        assert!(text.contains("battery_state_unset = true"), "{text}");
        let back: ConfigState = toml::from_str(&text).unwrap();
        assert_eq!(back, cfg);
        assert_eq!(back.unset(), cfg.unset());
        // Everything but the flags is today's default.
        assert_eq!(
            ConfigState {
                ac_state_unset: false,
                battery_state_unset: false,
                ..back
            },
            ConfigState::default()
        );
    }

    #[test]
    fn a_hand_edit_to_an_unset_profile_sets_it() {
        let text = toml::to_string_pretty(&ConfigState::first_run())
            .unwrap()
            .replace(r#"perf_mode = "Battery""#, r#"perf_mode = "Silent""#);
        let cfg: ConfigState = toml::from_str(&text).unwrap();
        assert!(cfg.battery_state_unset, "the flag is still in the file");
        assert_eq!(
            cfg.unset(),
            crate::observe::Unset {
                ac: true,
                battery: false
            },
            "but the edited battery profile is applied, not replaced by a reading"
        );
    }

    // ---- a laptop that lacks an optional setting (issue #2) ----

    /// A Balanced/Auto laptop whose EC answers `lacking` commands with "not supported"
    /// and echoes every write. Logo, brightness and battery reads return real values.
    fn laptop_lacking(lacking: &'static [u16]) -> crate::transport::MockTransport {
        use crate::packet::{Packet, ResponseError};
        crate::transport::MockTransport::with_fallible_responder(move |req| {
            if lacking.contains(&req.command()) {
                return Err(anyhow::Error::new(ResponseError::NotSupported));
            }
            let mut p = Packet::new(req.command(), &[]);
            match req.command() {
                0x0d82 => p.set_args(&[
                    0,
                    req.get_args()[1],
                    crate::types::PerfMode::Balanced as u8,
                    crate::types::FanMode::Auto as u8,
                ]),
                0x0382 => p.set_args(&[1, 4, 2]),
                0x0383 => p.set_args(&[1, 5, 200]),
                0x0084 => p.set_args(&[0, 0]),
                0x0f82 => p.set_args(&[1, 5, 0x00]),
                0x0792 => p.set_args(&[BatteryCare::from_percent(80).unwrap().wire_byte()]),
                _ => return Ok(Packet::new(req.command(), req.get_args())),
            }
            Ok(p)
        })
    }

    fn sent_command(mock: &crate::transport::MockTransport, command: u16) -> bool {
        mock.sent().iter().any(|(c, _)| *c == command)
    }

    #[test]
    fn a_supported_model_still_fails_a_read_the_ec_rejects() {
        let mock = laptop_lacking(&[0x0792]);
        let err = DeviceState::read(&mock).unwrap_err();
        assert!(crate::error::is_not_supported(&err));
    }

    #[test]
    fn a_learning_model_reads_around_a_missing_setting_and_stops_asking() {
        let mock = laptop_lacking(&[0x0792]).learning();
        let state = DeviceState::read(&mock).expect("battery care is optional");
        assert_eq!(state.battery_care, BatteryCare::DISABLE);
        assert_eq!(
            state.lights_mode.keyboard_brightness, 200,
            "the rest is read"
        );
        assert!(unsupported_on(&mock).contains(Optional::BatteryCare));

        let asked = mock.sent().iter().filter(|(c, _)| *c == 0x0792).count();
        DeviceState::read(&mock).unwrap();
        let asked_again = mock.sent().iter().filter(|(c, _)| *c == 0x0792).count();
        assert_eq!(asked, asked_again, "a recorded setting is not asked again");
    }

    #[test]
    fn a_learning_model_skips_writes_it_lacks_and_the_rest_still_land() {
        let mock = laptop_lacking(&[0x0383, 0x0303]).learning();
        let state = DeviceState::default();
        state
            .apply(&mock)
            .expect("a missing brightness is not an error");
        assert!(unsupported_on(&mock).contains(Optional::KeyboardBrightness));
        assert!(
            sent_command(&mock, 0x0712),
            "battery care was still written"
        );

        let before = mock.sent_count();
        state.apply(&mock).unwrap();
        let brightness_writes = mock.sent()[before..]
            .iter()
            .filter(|(c, _)| *c == 0x0303)
            .count();
        assert_eq!(
            brightness_writes, 0,
            "a recorded setting is not written again"
        );
    }

    #[test]
    fn a_learning_model_still_reports_other_errors() {
        use crate::packet::{Packet, ResponseError};
        let mock = crate::transport::MockTransport::with_fallible_responder(|req| {
            if req.command() == 0x0712 {
                return Err(anyhow::Error::new(ResponseError::Failure));
            }
            Ok(Packet::new(req.command(), req.get_args()))
        })
        .learning();
        let err = DeviceState::default().enforce_to(&mock).unwrap_err();
        assert!(!crate::error::is_not_supported(&err));
        assert!(unsupported_on(&mock).is_empty());
    }

    #[test]
    fn a_missing_setting_is_not_drift() {
        let mock = laptop_lacking(&[0x0792, 0x0380, 0x0382]).learning();
        let observed = DeviceState::read(&mock).unwrap();
        let mut intended = observed;
        intended.battery_care = BatteryCare::from_percent(60).unwrap();
        intended.lights_mode.logo_mode = LogoMode::Static;

        assert!(
            observed.enforced_fields_differ(&intended),
            "plain compare sees it"
        );
        assert!(!observed.enforced_fields_differ_on(&intended, &mock));
        assert!(!observed.drifted_from(&intended, &mock, &mut Zone2DriftGuard::default()));

        intended.perf_mode = PerfMode::Silent;
        assert!(
            observed.enforced_fields_differ_on(&intended, &mock),
            "perf still counts"
        );
    }

    // ---- Max Fan on an EC that rejects it (issue #10, Blade 17 2022, PID 0x028b) ----

    /// A Custom/Auto laptop whose EC answers Max Fan (0x070f) with "not supported" and
    /// echoes every other write. Issue #10 saw Enable rejected; whether Disable is too is
    /// still open, so this EC rejects both.
    fn custom_laptop_without_max_fan() -> crate::transport::MockTransport {
        use crate::packet::{Packet, ResponseError};
        crate::transport::MockTransport::with_fallible_responder(|req| {
            let mut p = Packet::new(req.command(), &[]);
            match req.command() {
                0x070f => return Err(anyhow::Error::new(ResponseError::NotSupported)),
                0x0d82 => p.set_args(&[
                    0,
                    req.get_args()[1],
                    crate::types::PerfMode::Custom as u8,
                    crate::types::FanMode::Auto as u8,
                ]),
                _ => return Ok(Packet::new(req.command(), req.get_args())),
            }
            Ok(p)
        })
    }

    fn custom_intent() -> DeviceState {
        DeviceState {
            perf_mode: PerfMode::Custom(CpuBoost::Medium, GpuBoost::High),
            ..DeviceState::default()
        }
    }

    fn max_fan_disables(mock: &crate::transport::MockTransport) -> usize {
        mock.sent()
            .iter()
            .filter(|(c, a)| *c == 0x070f && a[0] == MaxFanSpeedMode::Disable as u8)
            .count()
    }

    #[test]
    fn a_catalogued_model_fails_every_custom_apply_when_max_fan_is_rejected() {
        let mock = custom_laptop_without_max_fan();
        let state = custom_intent();
        assert!(!state.max_fan, "Max Fan off still sends Disable in Custom");

        for _ in 0..2 {
            let err = state.apply(&mock).unwrap_err();
            assert!(crate::error::is_not_supported(&err), "{err:?}");
            let err = state.enforce_to(&mock).unwrap_err();
            assert!(crate::error::is_not_supported(&err), "{err:?}");
        }
        assert_eq!(max_fan_disables(&mock), 4, "asked again every time");
        assert!(unsupported_on(&mock).is_empty(), "nothing is learned");
        assert!(sent_command(&mock, 0x0712), "the later writes still land");

        let before = mock.sent_count();
        let balanced = DeviceState {
            perf_mode: PerfMode::Balanced,
            ..state
        };
        balanced
            .apply(&mock)
            .expect("Max Fan is never sent outside Custom");
        assert!(!mock.sent()[before..].iter().any(|(c, _)| *c == 0x070f));
    }

    /// The generic profile doesn't learn Max Fan either: it is not an `Optional` yet
    /// (feat/max-fan-lacking makes it one). Until that lands, cataloguing 0x028b changes
    /// nothing here; after it does, a catalogued 0x028b keeps failing while a generic one
    /// learns.
    #[test]
    fn a_placeholder_never_replaces_the_intent() {
        let mock = laptop_lacking(&[0x0792, 0x0383]).learning();
        let reading = DeviceState::read(&mock).unwrap();
        let mut intent = reading;
        intent.battery_care = BatteryCare::from_percent(70).unwrap();
        intent.lights_mode.keyboard_brightness = 128;
        intent.lights_mode.logo_mode = LogoMode::Breathing;

        let seen = reading.with_lacking_from(&intent, unsupported_on(&mock));
        assert_eq!(seen.battery_care, intent.battery_care);
        assert_eq!(seen.lights_mode.keyboard_brightness, 128);
        assert_eq!(
            seen.lights_mode.logo_mode, reading.lights_mode.logo_mode,
            "logo was read"
        );
    }

    #[test]
    fn every_perf_mode_maps_to_the_ec_mode_it_writes() {
        use crate::transport::MockTransport;
        let modes = [
            PerfMode::Battery,
            PerfMode::Silent,
            PerfMode::Balanced,
            PerfMode::Performance,
            PerfMode::Hyperboost,
            PerfMode::Custom(CpuBoost::Low, GpuBoost::Low),
            PerfMode::Custom(CpuBoost::Boost, GpuBoost::High),
        ];
        for mode in modes {
            // The first 0x0d02 `apply` sends carries the perf mode's wire value.
            let mock = MockTransport::echo();
            let _ = DeviceState {
                perf_mode: mode,
                ..DeviceState::default()
            }
            .apply(&mock);
            let wrote = mock
                .sent()
                .into_iter()
                .find(|(command, _)| *command == 0x0d02)
                .map(|(_, args)| args[2]);
            assert_eq!(wrote, Some(mode.wire() as u8), "{mode:?}");
        }
    }

    #[test]
    fn confirm_modes_maps_every_perf_mode_and_the_fan_mode() {
        for (perf, ec) in [
            (PerfMode::Battery, crate::types::PerfMode::Battery),
            (PerfMode::Silent, crate::types::PerfMode::Silent),
            (PerfMode::Balanced, crate::types::PerfMode::Balanced),
            (PerfMode::Performance, crate::types::PerfMode::Performance),
            (PerfMode::Hyperboost, crate::types::PerfMode::Hyperboost),
            (
                PerfMode::Custom(CpuBoost::Low, GpuBoost::Low),
                crate::types::PerfMode::Custom,
            ),
        ] {
            let mock = crate::transport::MockTransport::with_responder(move |req| {
                let mut p = crate::packet::Packet::new(req.command(), &[]);
                p.set_args(&[0, req.get_args()[1], ec as u8, FanMode::Manual as u8]);
                p
            });
            let state = DeviceState {
                perf_mode: perf,
                fan_speed: FanSpeed::Manual(3000),
                ..DeviceState::default()
            };
            state.confirm_modes(&mock).unwrap();
            let auto = DeviceState {
                fan_speed: FanSpeed::Auto,
                ..state
            };
            assert!(
                auto.confirm_modes(&mock).is_err(),
                "fan mode is checked too"
            );
        }
    }

    #[test]
    fn an_ignored_switch_to_custom_is_reported_as_not_applied() {
        // The EC stays Balanced/Auto whatever is written, and acknowledges every write.
        let mock = crate::transport::MockTransport::with_responder(|req| {
            let mut p = crate::packet::Packet::new(req.command(), req.get_args());
            if req.command() == 0x0d82 {
                p.set_args(&[
                    0,
                    req.get_args()[1],
                    crate::types::PerfMode::Balanced as u8,
                    FanMode::Auto as u8,
                ]);
            }
            p
        });
        let state = DeviceState {
            perf_mode: PerfMode::Custom(CpuBoost::Boost, GpuBoost::High),
            ..DeviceState::default()
        };
        let err = state.apply(&mock).unwrap_err();
        assert!(crate::error::is_perf_not_applied(&err), "{err:?}");
        assert!(
            !mock.sent().iter().any(|(c, _)| *c == 0x0d07),
            "no boost is written into a mode the EC never entered"
        );
        for (command, what) in [(0x0303, "brightness"), (0x0712, "charge limit")] {
            assert!(
                mock.sent().iter().any(|(c, _)| *c == command),
                "{what} is still written"
            );
        }
    }

    // ---- a laptop without Max Fan (issue #10) ----

    /// A Custom/Auto laptop whose EC answers the requests `rejects` picks with "not
    /// supported" and echoes every other write. Max Fan reads back off.
    fn custom_laptop_rejecting(
        rejects: fn(&crate::packet::Packet) -> bool,
    ) -> crate::transport::MockTransport {
        use crate::packet::{Packet, ResponseError};
        crate::transport::MockTransport::with_fallible_responder(move |req| {
            if rejects(req) {
                return Err(anyhow::Error::new(ResponseError::NotSupported));
            }
            let mut p = Packet::new(req.command(), &[]);
            match req.command() {
                0x0d82 => p.set_args(&[
                    0,
                    req.get_args()[1],
                    crate::types::PerfMode::Custom as u8,
                    crate::types::FanMode::Auto as u8,
                ]),
                0x0d87 => p.set_args(&[0, req.get_args()[1], 1]),
                0x078f => p.set_args(&[MaxFanSpeedMode::Disable as u8]),
                0x0382 => p.set_args(&[1, 4, 2]),
                0x0383 => p.set_args(&[1, 5, 200]),
                0x0084 => p.set_args(&[0, 0]),
                0x0f82 => p.set_args(&[1, 5, 0x00]),
                0x0792 => p.set_args(&[BatteryCare::from_percent(80).unwrap().wire_byte()]),
                _ => return Ok(Packet::new(req.command(), req.get_args())),
            }
            Ok(p)
        })
    }

    /// #10's Blade 17 2022: Max Fan "on" is rejected, the getter answers.
    fn rejects_max_fan_on(req: &crate::packet::Packet) -> bool {
        req.command() == 0x070f && req.get_args()[0] == MaxFanSpeedMode::Enable as u8
    }

    fn custom_with_max_fan(max_fan: bool) -> DeviceState {
        DeviceState {
            perf_mode: PerfMode::Custom(CpuBoost::Medium, GpuBoost::Medium),
            max_fan,
            ..DeviceState::default()
        }
    }

    #[test]
    fn a_supported_model_still_fails_a_max_fan_write_the_ec_rejects() {
        let mock = custom_laptop_rejecting(rejects_max_fan_on);
        let err = custom_with_max_fan(true).apply(&mock).unwrap_err();
        assert!(crate::error::is_not_supported(&err));
    }

    #[test]
    fn max_fan_off_is_accepted_until_someone_picks_on() {
        let mock = custom_laptop_rejecting(rejects_max_fan_on).learning();
        custom_with_max_fan(false).apply(&mock).unwrap();
        assert!(sent_command(&mock, 0x070f), "off was written");
        assert!(unsupported_on(&mock).is_empty());

        custom_with_max_fan(true)
            .apply(&mock)
            .expect("a missing Max Fan is not an error");
        assert!(unsupported_on(&mock).contains(Optional::MaxFan));
    }

    #[test]
    fn a_learning_model_without_max_fan_writes_the_rest_and_stops_asking() {
        let mock = custom_laptop_rejecting(rejects_max_fan_on).learning();
        let state = custom_with_max_fan(true);
        state.apply(&mock).unwrap();
        let sent = mock.sent();
        let at = sent.iter().position(|(c, _)| *c == 0x070f).unwrap();
        for (command, what) in [
            (0x0d02, "fan mode"),
            (0x0300, "logo"),
            (0x0303, "brightness"),
            (0x0712, "charge limit"),
        ] {
            assert!(
                sent[at..].iter().any(|(c, _)| *c == command),
                "{what} was still written after the rejection"
            );
        }

        let before = mock.sent_count();
        state.apply(&mock).unwrap();
        assert!(!DeviceState::read(&mock).unwrap().max_fan);
        assert!(
            !mock.sent()[before..]
                .iter()
                .any(|(c, _)| *c == 0x070f || *c == 0x078f),
            "a recorded setting is not written or read again"
        );
    }

    #[test]
    fn a_rejected_max_fan_read_is_learned_too() {
        let mock = custom_laptop_rejecting(|req| req.command() == 0x078f).learning();
        let state = DeviceState::read(&mock).expect("Max Fan is optional");
        assert!(!state.max_fan);
        assert!(unsupported_on(&mock).contains(Optional::MaxFan));
    }

    #[test]
    fn a_failed_perf_read_before_max_fan_is_not_blamed_on_max_fan() {
        // `set_max_fan_speed_mode` reads the perf mode first; that read failing must not
        // record Max Fan as missing.
        let mock = custom_laptop_rejecting(|req| req.command() == 0x0d82).learning();
        assert!(custom_with_max_fan(true).apply(&mock).is_err());
        assert!(!unsupported_on(&mock).contains(Optional::MaxFan));
        assert!(!sent_command(&mock, 0x070f));
    }

    #[test]
    fn a_missing_max_fan_is_not_drift_and_never_replaces_the_intent() {
        let mock = custom_laptop_rejecting(rejects_max_fan_on).learning();
        let mut intended = DeviceState::read(&mock).unwrap();
        intended.max_fan = true;
        intended.enforce_to(&mock).unwrap();

        let observed = DeviceState::read(&mock).unwrap();
        assert!(!observed.max_fan);
        assert!(
            observed.enforced_fields_differ(&intended),
            "plain compare sees it"
        );
        assert!(!observed.enforced_fields_differ_on(&intended, &mock));
        let seen = observed.with_lacking_from(&intended, unsupported_on(&mock));
        assert!(seen.max_fan, "the profile keeps its own value");
    }
}
