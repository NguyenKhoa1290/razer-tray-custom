//! The seam between the command protocol and the physical HID device.
//!
//! `command::*` talk to the laptop purely by exchanging [`Packet`]s, so they only
//! need *something that can send a packet and hand back the response* -- not the
//! concrete hidapi-backed [`crate::device::Device`]. `HidTransport` is that
//! something. The real implementation is `Device` (Windows/Linux only); a
//! `#[cfg(test)] MockTransport` records the packets it's asked to send and replays
//! canned responses, which lets the command + tray logic be exercised on any host
//! (e.g. a macOS dev box) with no hardware attached.

use crate::packet::Packet;
use crate::unsupported::UnsupportedLog;
use anyhow::Result;

/// Send a request packet and return the device's matched response packet.
///
/// Implementors own the wire details (retries, report-id framing, response
/// matching); callers above this trait deal only in `Packet`s.
///
/// This trait is implementable from *outside* the crate -- that is the point of a
/// seam, and it is what lets a downstream consumer supply its own transport (a
/// simulator, a remote proxy, a replay harness). That requires [`Packet`] to be
/// nameable externally, so `librazer::packet` is a public module; see the doc
/// comment on `mod packet` in lib.rs. The `external_impl_compiles` test below
/// pins the property so a future `pub` -> private change fails the build here
/// rather than silently in someone else's crate.
pub trait HidTransport {
    fn send(&self, packet: Packet) -> Result<Packet>;

    /// USB product identifier when known, for model-specific protocol variants.
    fn product_id(&self) -> Option<u16> {
        None
    }

    /// Like [`HidTransport::send`], but a command the EC answers with `Failure` is not
    /// re-sent. Used for caller-supplied raw commands, whose idempotence is unknown.
    /// Transports without a retry loop of their own can keep the default.
    fn send_once(&self, packet: Packet) -> Result<Packet> {
        self.send(packet)
    }

    /// The optional settings this device has turned out not to have, when it is a model
    /// that learns them (see [`crate::unsupported`]). `None`, the default, keeps every
    /// "not supported" answer an error.
    /// Wait between exchanges, e.g. before re-reading a value that may still be settling.
    /// The real device sleeps; the simulator advances its own clock instead, so logic that
    /// depends on time runs in tests without real delays.
    fn pause(&self, duration: std::time::Duration) {
        std::thread::sleep(duration);
    }

    fn unsupported(&self) -> Option<&UnsupportedLog> {
        None
    }
}

/// Test-only `HidTransport` that records every request and replies via a
/// caller-supplied responder. It never touches hardware, so it lets the `command`
/// layer (and any logic layered on it) be exercised on any host.
///
/// The command layer validates responses by inspecting `get_args()` only -- packet
/// *matching* (transaction id, status) lives in `Device::send`, below this seam --
/// so a response just needs the right arg bytes; `Packet::new`'s status is ignored.
#[cfg(test)]
type Responder = Box<dyn Fn(&Packet) -> Result<Packet>>;

#[cfg(test)]
pub struct MockTransport {
    sent: std::cell::RefCell<Vec<(u16, Vec<u8>)>>,
    responder: Responder,
    unsupported: Option<UnsupportedLog>,
    pid: Option<u16>,
}

#[cfg(test)]
impl MockTransport {
    /// Echoing transport: each response repeats the request's args, mimicking the
    /// firmware's success ack. Satisfies the `starts_with(args)` checks the set_*
    /// paths use, so it's the right mock for write-path tests.
    pub fn echo() -> Self {
        Self::with_responder(|req| Packet::new(req.command(), req.get_args()))
    }

    /// Transport whose response is computed from each request -- use for read-path
    /// (get_*) tests that must return specific register values.
    pub fn with_responder(f: impl Fn(&Packet) -> Packet + 'static) -> Self {
        Self::with_fallible_responder(move |req| Ok(f(req)))
    }

    /// Like [`Self::with_responder`], but a request can fail the way `Device::send` does,
    /// e.g. with a `ResponseError::NotSupported` for a command the EC lacks.
    pub fn with_fallible_responder(f: impl Fn(&Packet) -> Result<Packet> + 'static) -> Self {
        Self {
            sent: std::cell::RefCell::new(Vec::new()),
            responder: Box::new(f),
            unsupported: None,
            pid: None,
        }
    }

    /// Behave like a model that learns what it lacks (the generic profile).
    pub fn learning(mut self) -> Self {
        self.unsupported = Some(UnsupportedLog::default());
        self
    }

    pub fn with_pid(mut self, pid: u16) -> Self {
        self.pid = Some(pid);
        self
    }

    /// (command, args) of every packet sent so far, in order.
    pub fn sent(&self) -> Vec<(u16, Vec<u8>)> {
        self.sent.borrow().clone()
    }

    /// Number of packets sent so far.
    pub fn sent_count(&self) -> usize {
        self.sent.borrow().len()
    }
}

#[cfg(test)]
impl HidTransport for MockTransport {
    fn product_id(&self) -> Option<u16> {
        self.pid
    }
    fn send(&self, packet: Packet) -> Result<Packet> {
        let response = (self.responder)(&packet);
        let args = packet.get_args()[..packet.data_len()].to_vec();
        self.sent.borrow_mut().push((packet.command(), args));
        response
    }

    /// Mock time doesn't pass: tests that read twice shouldn't sleep.
    fn pause(&self, _duration: std::time::Duration) {}

    fn unsupported(&self) -> Option<&UnsupportedLog> {
        self.unsupported.as_ref()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn echo_repeats_request_args_and_command() {
        let mock = MockTransport::echo();
        let resp = mock.send(Packet::new(0x0d02, &[1, 2, 3])).unwrap();
        assert_eq!(resp.command(), 0x0d02);
        assert!(resp.get_args().starts_with(&[1, 2, 3]));
    }

    #[test]
    fn records_sent_packets_in_order() {
        let mock = MockTransport::echo();
        mock.send(Packet::new(0x0001, &[9])).unwrap();
        mock.send(Packet::new(0x0002, &[8, 7])).unwrap();
        let sent = mock.sent();
        assert_eq!(sent.len(), 2);
        assert_eq!(mock.sent_count(), 2);
        assert_eq!(sent[0].0, 0x0001);
        assert_eq!(&sent[1].1[..2], &[8, 7]);
    }

    #[test]
    fn responder_can_return_canned_values() {
        // Stand in for a get_* register read: respond with a fixed arg byte.
        let mock = MockTransport::with_responder(|req| {
            let mut p = Packet::new(req.command(), &[]);
            p.set_args(&[0, 0, 0x42]);
            p
        });
        let resp = mock.send(Packet::new(0x0d87, &[0, 0, 0])).unwrap();
        assert_eq!(resp.get_args()[2], 0x42);
    }
}
