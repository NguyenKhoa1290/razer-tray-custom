use crate::feature;

// model_number_prefix shall conform to https://mysupport.razer.com/app/answers/detail/a_id/5481
#[derive(Debug, Clone)]
pub struct Descriptor {
    pub model_number_prefix: &'static str,
    pub name: &'static str,
    pub pid: u16,
    pub features: &'static [&'static str],
    pub init_cmds: &'static [u16],
    /// Usable **manual**-fan RPM bounds (min, max) for this chassis; the UI/CLI build their
    /// presets from this. Manual-only by construction: the firmware's Auto curve is not
    /// expressible here, because Auto's bottom is *off* and manual has no off (see below).
    ///
    /// Below min the EC accepts the write, keeps it in the read-back register, and silently
    /// spins at min anyway; above max it clamps. So a set point outside these bounds is not
    /// an error the hardware reports -- it is a number the UI would show while the fan
    /// ignores it.
    ///
    /// PROVENANCE, which differs per row and matters: `0x029F` is **measured on hardware**
    /// (2026-08-15, raw `0x0d01` sweep, floor confirmed at 2000 -- the details are on
    /// [`SUPPORTED`]). Every other row is transcribed from
    /// Vader89/razer-laptop-control-16-2023's per-model `laptops.json`, which lists 2200 for
    /// the 2023+ Blades -- including the one chassis we have now measured at 2000. Treat the
    /// un-measured floors as upper bounds on the truth, not as facts.
    pub fan_rpm_range: (u16, u16),
}

/// Why `0x029F`'s floor is 2000 and what a future prober should expect, recorded here
/// because the number looks arbitrary and was wrong for a year.
///
/// Measured 2026-08-15 on a Razer Blade 16 (2023), BIOS 2.05, by writing raw `0x0d01`
/// directly (razer-cli's own parser rejects sub-2000 before the EC ever sees it):
///
/// - Set points 1800 / 1500 / 1200 / 1000 / 800 / 400 / 100 / 0 **all** settle at exactly
///   2000 RPM on both zones, held 40 s each, across CPU load 0-17%. 2000 and 3000 are
///   honored exactly. So: honored at >= 2000, silently clamped below.
/// - It is a floor, not the EC substituting its own thermal demand: Auto idle is
///   *asymmetric* (2000/1900), the manual floor is always *symmetric* (2000/2000).
/// - A set point of 0 does **not** hand control back to the firmware curve on this
///   chassis -- the mode register still reads Manual and the fan holds 2000. Other
///   projects treat 0 as "clear the manual flag"; do not port that here.
/// - The EC slews manual targets at a measured ~23 RPM/s and the tach is quantized to
///   100 RPM, so a set must not be verified by reading back sooner than dRPM/23 seconds.
/// - The ceiling clamps the same way. Measured 2026-10-15, Balanced, idle: set points
///   5300 / 5500 / 5700 all settle at 5000/4900 RPM while `0x0d81` reads back the value
///   written. So: honored up to 5000, silently clamped above.
/// - Razer documents no minimum for any model, and every other open-source project picks
///   a different unjustified one (3500 "for ALL laptops", 3100, per-model 2200). There is
///   no authority to defer to here; only measurement.
pub const SUPPORTED: &[Descriptor] = &[
    Descriptor {
        model_number_prefix: "RZ09-0483T",
        name: "Razer Blade 16 (2023) Black",
        pid: 0x029f,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
            // Not "fn-lock": 0x0206/0x0286 [0, 0|1] round-trips here, but neither value
            // changes the F-row (F1-F12 primary, media on Fn; key-tested 2026-09-23).
        ],
        init_cmds: &[],
        fan_rpm_range: (2000, 5000), // MEASURED (floor 2026-08-15, ceiling 2026-10-15)
    },
    Descriptor {
        model_number_prefix: "RZ09-0482X",
        name: "Razer Blade 14 (2023) Mercury",
        pid: 0x029d,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[],
        fan_rpm_range: (2200, 5000),
    },
    Descriptor {
        model_number_prefix: "RZ09-0483U",
        name: "Razer Blade 16 (2023)",
        pid: 0x029f,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[],
        fan_rpm_range: (2000, 5000), // MEASURED (floor 2026-08-15, ceiling 2026-10-15)
    },
    Descriptor {
        model_number_prefix: "RZ09-0510S",
        name: "Razer Blade 16 (2024)",
        pid: 0x02b7,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[],
        fan_rpm_range: (2200, 5000),
    },
    Descriptor {
        model_number_prefix: "RZ09-05289",
        name: "Razer Blade 16 (2025) RTX 5090",
        pid: 0x02c6,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[0x0081, 0x0086, 0x0f90, 0x0086, 0x0f10, 0x0087],
        fan_rpm_range: (2200, 5000),
    },
    Descriptor {
        model_number_prefix: "RZ09-05288",
        name: "Razer Blade 16 (2025) 5080",
        pid: 0x02c6,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[0x0081, 0x0086, 0x0f90, 0x0086, 0x0f10, 0x0087],
        fan_rpm_range: (2200, 5000),
    },
    Descriptor {
        model_number_prefix: "RZ09-05286",
        name: "Razer Blade 16 (2025) 5070",
        pid: 0x02c6,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[0x0081, 0x0086, 0x0f90, 0x0086, 0x0f10, 0x0087],
        fan_rpm_range: (2200, 5000),
    },
    Descriptor {
        model_number_prefix: "RZ09-0421N",
        name: "Razer Blade 15 (2022)",
        pid: 0x028a,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[],
        fan_rpm_range: (3500, 5000),
    },
    // Reported on hardware by a user (issue #10, 2026-10-19; enumerate RZ09-0423P, Windows 11):
    // perf modes and CPU/GPU boost sets verified by readback (GPU High -> Low), Auto/Manual fan
    // mode sets accepted, keyboard brightness/effects, logo and charge limit read back. Manual
    // RPM is NOT honored exactly: set points 3500/4000/4500/5000 read back 4000/3900/4300/4300
    // actual (max observed 4300), so the range below is still the transcribed one, not a
    // measurement. `fan max enable` answers NotSupported (0x05) on this EC. Stem prefix:
    // the reported SKU is RZ09-0423P and other trailing variants are the same chassis.
    Descriptor {
        model_number_prefix: "RZ09-0423",
        name: "Razer Blade 17 (2022)",
        pid: 0x028b,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[],
        fan_rpm_range: (3500, 5000),
    },
    // Reported on hardware by a user (issue #1, 2026-09-30; SKU RZ09-0484UEH4-R3U1, Windows
    // 25H2): perf modes, Auto fan, Max Fan, keyboard brightness and effects, logo, charge
    // limit and the Fn keys all work. Manual RPM does NOT: every set point held the fans at
    // ~3200/3300, so the range below is still the transcribed one, not a measurement.
    Descriptor {
        model_number_prefix: "RZ09-0484U",
        name: "Razer Blade 18 (2023)",
        pid: 0x02a0,
        features: &[
            "battery-care",
            "fan",
            "kbd-backlight",
            "kbd-lighting",
            "lid-logo",
            "lights-always-on",
            "perf",
        ],
        init_cmds: &[],
        fan_rpm_range: (2200, 5000),
    },
];

const _VALIDATE_FEATURES: () = {
    crate::const_for! { device in SUPPORTED => {
        feature::validate_features(device.features);
    }}
};

/// Per-PID fan envelopes for Blade chassis we have no `SUPPORTED` entry for.
///
/// WHY A SECOND TABLE. `SUPPORTED` is keyed by BIOS **model-number prefix** (`RZ09-…`),
/// which is the precise identifier but is only knowable by reading it off a real
/// machine. The community device tables -- razer-laptop-control's `laptops.json` and
/// the Revived fork's 50-model extension -- are keyed by **USB PID**, which we always
/// have from enumeration. So for a machine we cannot inspect, the PID is the only key
/// we can actually match on. This table is that data, and it exists solely to give the
/// generic fallback a *correct fan range* instead of a conservative guess.
///
/// STATUS: TRANSCRIBED, NOT TESTED. Every row here comes from those reference tables;
/// none has been verified on hardware by this project, which owns exactly one Blade
/// (PID 0x029F). A row being present means "the fan bounds are better than a guess",
/// not "this model is supported". Catalogued models in `SUPPORTED` always win.
///
/// Note the outliers, which are why a flat default is wrong: the Blade Pro 17 tops out
/// at 4300, the Blade 14 2025 reaches 5600, and pre-2023 chassis floor at 3500 rather
/// than 2200 -- a 2200 preset on those is simply a dead menu entry.
///
/// SUSPECT ON THE LOW SIDE, 2026-08-15: these tables list 2200 for every 2023+ Blade,
/// and the one such chassis we have measured (`0x029F`, in `SUPPORTED`) turned out to
/// floor at **2000**, not 2200. So the 2023+ floors below are very likely 200 RPM too
/// high as well. They are left as transcribed on purpose -- guessing a second chassis
/// from a measurement of the first is how the wrong 2200 got here in the first place.
/// Lower a row only when someone probes that model with a raw `0x0d01` sweep.
pub const FAN_RANGE_BY_PID: &[(u16, (u16, u16))] = &[
    // Pre-2023: higher floor, most cap at 5000.
    (0x0205, (3500, 5000)), // Blade Stealth 2015
    (0x020f, (3500, 5000)), // Blade QHD
    (0x0210, (3500, 5000)), // Blade Pro 2017 v2
    (0x0220, (3500, 5000)), // Blade Stealth Late 2016
    (0x0224, (3500, 5000)), // Blade 15 2016
    (0x0225, (3500, 5000)), // Blade Pro 2017
    (0x022d, (3500, 5000)), // Blade Stealth 2017
    (0x022f, (3500, 5000)), // Blade Pro 2018 FHD
    (0x0232, (3500, 5000)), // Blade Stealth Late 2017
    (0x0233, (3500, 5000)), // Blade 15 2018 Advanced
    (0x0234, (3500, 5300)), // Blade Pro 2019
    (0x0239, (3500, 5300)), // Blade Stealth 2019
    (0x023a, (3500, 5300)), // Blade 15 2019 Advanced
    (0x023b, (3500, 5700)), // Blade 15 2018 Base -- 5700 heard over 5000 (issue #2, 2026-10-15)
    (0x0240, (3500, 5000)), // Blade 15 2018 Mercury
    (0x0245, (3500, 5300)), // Blade 15 2019 Mercury
    (0x0246, (3500, 5000)), // Blade 15 2019 Base
    (0x024a, (3500, 5000)), // Blade Stealth 2019 GTX
    (0x024b, (3500, 5300)), // Blade 15 Late 2019 Advanced
    (0x024c, (3500, 5300)), // Blade Pro Late 2019
    (0x024d, (3500, 5300)), // Blade 15 Studio Edition 2019
    (0x0252, (3500, 5000)), // Blade Stealth 2020
    (0x0253, (3500, 5300)), // Blade 15 2020 Advanced
    (0x0255, (3500, 5000)), // Blade 15 2020 Base
    (0x0256, (3500, 5300)), // Blade Pro 2020
    (0x0259, (3500, 5000)), // Blade Stealth Late 2020
    (0x0268, (3500, 5000)), // Blade 15 Late 2020 Base
    (0x026a, (3500, 5000)), // Razer Book 13 2020
    (0x026d, (3500, 5000)), // Blade 15 Late 2021 Advanced
    (0x026e, (2300, 4300)), // Blade Pro 17 Early 2021 -- low ceiling
    (0x026f, (3500, 5000)), // Blade 15 2021 Base
    (0x0270, (3500, 5000)), // Blade 14 2021
    (0x0276, (2000, 5400)), // Blade 15 2021 Advanced -- widest range
    (0x0279, (2300, 4300)), // Blade Pro 17 Mid 2021 -- low ceiling
    (0x027a, (3500, 5000)), // Blade 15 Late 2021 Base
    (0x028c, (3500, 5000)), // Blade 14 2022
    // 2023+: transcribed floor of 2200. Unverified, and known too high for 0x029F.
    (0x029e, (2200, 5000)), // Blade 15 2023
    (0x02b6, (2200, 5000)), // Blade 14 2024
    (0x02b8, (2200, 5000)), // Blade 18 2024
    (0x02c5, (2200, 5600)), // Blade 14 2025 -- highest ceiling
    (0x02c7, (2200, 5000)), // Blade 18 2025
    (0x02e0, (2200, 5000)), // Blade 16 2026 -- PID via jdsgnrinfo/blade-control; range is the 2023+ default, not transcribed
    (0x02e1, (2200, 5000)), // Blade 18 2026
];

/// Fan bounds for `pid` from [`FAN_RANGE_BY_PID`], if that chassis is listed.
pub fn fan_range_for_pid(pid: u16) -> Option<(u16, u16)> {
    FAN_RANGE_BY_PID
        .iter()
        .find(|(p, _)| *p == pid)
        .map(|(_, range)| *range)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The "widest range across all chassis" constants must actually match the data.
    ///
    /// These used to be three disagreeing numbers for one idea (`command.rs` bounded RPM
    /// at 5500, `FAN_RPM_MAX_ANY` said 5300, this table reaches 5600), so a CLI-supplied
    /// RPM was validated against a limit no real machine had. Deriving the check from the
    /// tables means adding a chassis with a wider envelope fails here instead of silently
    /// making the constants wrong.
    #[test]
    fn fan_rpm_any_constants_bound_every_known_chassis() {
        let ranges = FAN_RANGE_BY_PID
            .iter()
            .map(|(_, r)| *r)
            .chain(SUPPORTED.iter().map(|d| d.fan_rpm_range));

        for (min, max) in ranges {
            assert!(
                min >= crate::state::FAN_RPM_MIN_ANY,
                "FAN_RPM_MIN_ANY ({}) is above a real chassis floor ({min})",
                crate::state::FAN_RPM_MIN_ANY
            );
            assert!(
                max <= crate::state::FAN_RPM_MAX_ANY,
                "FAN_RPM_MAX_ANY ({}) is below a real chassis ceiling ({max})",
                crate::state::FAN_RPM_MAX_ANY
            );
        }
    }

    #[test]
    fn fan_rpm_any_constants_are_tight() {
        // Not merely valid but exact: some chassis must actually sit at each bound,
        // otherwise the "widest known range" claim is padding.
        let all: Vec<(u16, u16)> = FAN_RANGE_BY_PID
            .iter()
            .map(|(_, r)| *r)
            .chain(SUPPORTED.iter().map(|d| d.fan_rpm_range))
            .collect();
        assert_eq!(
            all.iter().map(|(min, _)| *min).min().unwrap(),
            crate::state::FAN_RPM_MIN_ANY
        );
        assert_eq!(
            all.iter().map(|(_, max)| *max).max().unwrap(),
            crate::state::FAN_RPM_MAX_ANY
        );
    }

    #[test]
    fn fan_range_lookup_finds_table_entries_and_misses_unknowns() {
        assert_eq!(fan_range_for_pid(0x026e), Some((2300, 4300)));
        assert_eq!(fan_range_for_pid(0x02c5), Some((2200, 5600)));
        // A PID in SUPPORTED is deliberately absent from the fallback table.
        assert_eq!(fan_range_for_pid(0x029f), None);
        assert_eq!(fan_range_for_pid(0x02a0), None);
        assert_eq!(fan_range_for_pid(0x028b), None);
        assert_eq!(fan_range_for_pid(0xFFFF), None);
    }
}
