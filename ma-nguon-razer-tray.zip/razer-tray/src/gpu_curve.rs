//! NVIDIA V/F editor. NVAPI table layouts follow the working local loader and
//! buswedg/nvapi-cmd. These private interfaces are guarded by exact GPU/layout checks.
mod editor;
mod nvapi;

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

pub const GPU: &str = "NVIDIA GeForce RTX 2080 Super with Max-Q Design";
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Point {
    pub uv: u32,
    pub khz: u32,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Profile {
    pub version: u32,
    pub gpu: String,
    pub bus: u32,
    pub points: Vec<Point>,
}

/// Build each draft from the zero-offset curve, never from a previously shifted draft.
fn undervolt_curve(base: &Profile, selected: usize, target_khz: u32) -> Result<(Profile, i32)> {
    let anchor = base
        .points
        .get(selected)
        .context("Chưa chọn điểm điện áp")?;
    anyhow::ensure!(
        (150_000..=3_000_000).contains(&target_khz) && target_khz.is_multiple_of(15_000),
        "Xung cần trong phạm vi 150–3000 MHz, theo bước 15 MHz"
    );
    let delta = i64::from(target_khz) - i64::from(anchor.khz);
    let mut profile = base.clone();
    for (i, point) in profile.points.iter_mut().enumerate() {
        let khz = if i < selected {
            (i64::from(point.khz) + delta).min(i64::from(target_khz))
        } else {
            i64::from(target_khz)
        };
        anyhow::ensure!(
            (150_000..=3_000_000).contains(&khz),
            "Điểm {:.5} V sẽ ngoài phạm vi 150–3000 MHz",
            point.uv as f64 / 1e6
        );
        point.khz = khz as u32;
    }
    Ok((profile, delta as i32))
}
#[derive(Serialize, Deserialize)]
struct Request {
    mode: String,
    profile: Option<Profile>,
}
#[derive(Serialize, Deserialize)]
struct Reply {
    success: bool,
    message: String,
}

#[derive(Default, Serialize, Deserialize)]
struct StartupOptions {
    #[serde(default)]
    apply_saved_curve: bool,
}

fn startup_options() -> Result<StartupOptions> {
    if !path("startup.toml")?.exists() {
        return Ok(StartupOptions::default());
    }
    load("startup.toml")
}

pub fn startup_enabled() -> bool {
    startup_options().is_ok_and(|options| options.apply_saved_curve)
}

pub fn set_startup_enabled(enable: bool) -> Result<String> {
    let message = apply_elevated(
        if enable {
            "enable-curve-startup"
        } else {
            "disable-curve-startup"
        },
        None,
    )?;
    crate::platform::refresh_autostart();
    Ok(message)
}

fn configure_curve_startup(enable: bool) -> Result<String> {
    let previous = startup_options()?;
    if enable {
        let profile: Profile =
            load("saved.toml").context("Hãy lưu curve trước khi bật tự áp dụng")?;
        let snapshot = nvapi::Api::new()?.snapshot()?;
        let _ = snapshot.startup_profile(&profile)?;
    }
    save(
        "startup.toml",
        &StartupOptions {
            apply_saved_curve: enable,
        },
    )?;
    if enable {
        if let Err(error) = crate::platform::set_autostart(true) {
            save("startup.toml", &previous)?;
            return Err(error);
        }
    }
    Ok(if enable {
        "Đã bật tự áp dụng curve đã lưu khi đăng nhập Windows. Razer Tray dùng một mục khởi động duy nhất."
    } else {
        "Đã tắt tự áp dụng curve. Razer Tray vẫn có thể khởi động cùng Windows."
    }.into())
}

/// Only the registered login action has --startup. Opening the editor, inspecting
/// NVAPI or starting the tray manually must never silently change GPU settings.
pub fn restore_at_login() {
    if !std::env::args().any(|arg| arg == "--startup") {
        return;
    }
    let options = match startup_options() {
        Ok(options) => options,
        Err(error) => {
            log::warn!("GPU startup settings unreadable; not applying: {error:#}");
            return;
        }
    };
    if !options.apply_saved_curve {
        return;
    }
    std::thread::spawn(|| {
        let _ = save(
            "startup-result.toml",
            &Reply {
                success: false,
                message: "Đang chờ driver để áp dụng curve đã lưu.".into(),
            },
        );
        let outcome = (|| -> Result<Option<(usize, u32)>> {
            anyhow::ensure!(
                unsafe { windows::Win32::UI::Shell::IsUserAnAdmin().as_bool() },
                "Mục khởi động chưa có quyền quản trị; bật lại tùy chọn tự áp dụng để đăng ký lại"
            );
            std::thread::sleep(std::time::Duration::from_secs(3));
            let mut ready = None;
            let mut last_error = None;
            // Retry readiness only. A failed hardware write is never retried blindly.
            for attempt in 0..6 {
                match nvapi::Api::new().and_then(|api| {
                    api.snapshot()?;
                    Ok(api)
                }) {
                    Ok(api) => {
                        ready = Some(api);
                        break;
                    }
                    Err(error) => last_error = Some(error),
                }
                if attempt < 5 {
                    std::thread::sleep(std::time::Duration::from_secs(2));
                }
            }
            let api = ready.ok_or_else(|| {
                last_error.unwrap_or_else(|| anyhow::anyhow!("Driver NVIDIA chưa sẵn sàng"))
            })?;
            // Recheck after waiting: switching the option off cancels a pending apply.
            if !startup_options()?.apply_saved_curve {
                return Ok(None);
            }
            let profile: Profile = load("saved.toml")?;
            let _write_guard = gpu_write_guard()?;
            let adjustment = api.apply_saved_at_startup(&profile)?;
            Ok(Some(adjustment))
        })();
        let reply = Reply {
            success: matches!(outcome, Ok(Some(_))),
            message: match outcome {
                Ok(Some((0, _))) => "Đã áp dụng curve đã lưu và đọc lại xác nhận từ driver khi khởi động Razer Tray.".into(),
                Ok(Some((count, reduction))) => format!("Đã tự áp dụng và xác nhận từ driver. Đã giới hạn {count} điểm ở tối đa +150 MHz so với gốc hiện tại (hạ nhiều nhất {:.0} MHz). Tệp curve đã lưu được giữ nguyên.", reduction as f64 / 1000.0),
                Ok(None) => "Đã hủy tự áp dụng vì tùy chọn đã được tắt.".into(),
                Err(error) => format!("Không tự áp dụng được curve: {error:#}"),
            },
        };
        if reply.success {
            log::info!("GPU startup: {}", reply.message);
        } else {
            log::warn!("GPU startup: {}", reply.message);
        }
        if let Err(error) = save("startup-result.toml", &reply) {
            log::warn!("Could not save GPU startup result: {error:#}");
        }
    });
}

fn gpu_write_guard() -> Result<single_instance::SingleInstance> {
    let guard = single_instance::SingleInstance::new("razer-gpu-curve-write")?;
    anyhow::ensure!(
        guard.is_single(),
        "Đang có thao tác ghi curve khác; hãy thử lại sau"
    );
    Ok(guard)
}

pub fn path(name: &str) -> Result<PathBuf> {
    let dir = PathBuf::from(std::env::var_os("LOCALAPPDATA").context("LOCALAPPDATA missing")?)
        .join("razer-tray")
        .join("gpu-curve");
    std::fs::create_dir_all(&dir)?;
    Ok(dir.join(name))
}
pub fn save<T: Serialize>(name: &str, data: &T) -> Result<()> {
    let dest = path(name)?;
    let temp = dest.with_extension("tmp");
    std::fs::write(&temp, toml::to_string_pretty(data)?)?;
    // rename replaces files atomically on Windows with std's MoveFileEx implementation.
    std::fs::rename(temp, dest)?;
    Ok(())
}
pub fn load<T: serde::de::DeserializeOwned>(name: &str) -> Result<T> {
    Ok(toml::from_str(&std::fs::read_to_string(path(name)?)?)?)
}

pub fn open() {
    editor::open();
}

/// Must run before the tray single-instance guard, since apply is a short-lived
/// elevated worker. Manual startup never applies a curve; --startup opts into login restore.
pub fn command_line() -> Option<Result<()>> {
    let arg = std::env::args().nth(1)?;
    match arg.as_str() {
        "--gpu-curve-editor" => Some(editor::run()),
        "--gpu-curve-enable-startup" => Some(set_startup_enabled(true).map(|_| ())),
        "--gpu-curve-disable-startup" => Some(set_startup_enabled(false).map(|_| ())),
        "--gpu-curve-inspect" => Some((|| {
            let api = nvapi::Api::new()?;
            save("inspect.toml", &api.snapshot()?.profile())
        })()),
        "--gpu-curve-apply" => Some((|| {
            let outcome = (|| -> Result<String> {
                anyhow::ensure!(
                    unsafe { windows::Win32::UI::Shell::IsUserAnAdmin().as_bool() },
                    "Cần quyền quản trị để áp dụng curve"
                );
                let request: Request = load("request.toml")?;
                match request.mode.as_str() {
                    "enable-curve-startup" => return configure_curve_startup(true),
                    "disable-curve-startup" => return configure_curve_startup(false),
                    "enable-autostart" | "disable-autostart" => {
                        crate::platform::set_autostart(request.mode == "enable-autostart")?;
                        return Ok("Đã cập nhật khởi động cùng Windows.".into());
                    }
                    "apply" | "restore" | "reset" | "verify" => {
                        let _write_guard = gpu_write_guard()?;
                        let api = nvapi::Api::new()?;
                        match request.mode.as_str() {
                            "apply" => api.apply(request.profile.context("Missing curve")?)?,
                            "restore" => api.restore()?,
                            "reset" => api.reset()?,
                            _ => api.verify_roundtrip()?,
                        }
                    }
                    _ => anyhow::bail!("Unknown GPU request"),
                }
                Ok("Đã áp dụng và đọc lại xác nhận từ driver.".into())
            })();
            let reply = Reply {
                success: outcome.is_ok(),
                message: match &outcome {
                    Ok(message) => message.clone(),
                    Err(e) => format!("{e:#}"),
                },
            };
            save("result.toml", &reply)?;
            outcome.map(|_| ())
        })()),
        _ => None,
    }
}

pub(crate) fn apply_elevated(mode: &str, profile: Option<Profile>) -> Result<String> {
    use windows::core::{w, PCWSTR};
    use windows::Win32::Foundation::CloseHandle;
    use windows::Win32::System::Threading::{GetExitCodeProcess, WaitForSingleObject, INFINITE};
    use windows::Win32::UI::Shell::{ShellExecuteExW, SEE_MASK_NOCLOSEPROCESS, SHELLEXECUTEINFOW};
    use windows::Win32::UI::WindowsAndMessaging::SW_HIDE;
    save(
        "request.toml",
        &Request {
            mode: mode.into(),
            profile,
        },
    )?;
    let exe: Vec<u16> = std::env::current_exe()?
        .as_os_str()
        .to_string_lossy()
        .encode_utf16()
        .chain(Some(0))
        .collect();
    let mut info = SHELLEXECUTEINFOW {
        cbSize: std::mem::size_of::<SHELLEXECUTEINFOW>() as u32,
        fMask: SEE_MASK_NOCLOSEPROCESS,
        lpVerb: w!("runas"),
        lpFile: PCWSTR(exe.as_ptr()),
        lpParameters: w!("--gpu-curve-apply"),
        nShow: SW_HIDE.0,
        ..Default::default()
    };
    unsafe {
        ShellExecuteExW(&mut info).context("Không thể mở yêu cầu quyền quản trị")?;
        WaitForSingleObject(info.hProcess, INFINITE);
        let mut code = 1;
        let result = GetExitCodeProcess(info.hProcess, &mut code);
        let _ = CloseHandle(info.hProcess);
        result?;
        let reply: Reply = load("result.toml")?;
        anyhow::ensure!(code == 0 && reply.success, "{}", reply.message);
        Ok(reply.message)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn base() -> Profile {
        Profile {
            version: 1,
            gpu: GPU.into(),
            bus: 1,
            points: (0..128)
                .map(|i| Point {
                    uv: 450_000 + i * 6_250,
                    khz: 405_000 + i * 15_000,
                })
                .collect(),
        }
    }

    #[test]
    fn undervolt_shifts_left_from_base_and_flattens_the_entire_right_side() {
        let base = base();
        let target = base.points[40].khz + 90_000;
        let (curve, delta) = undervolt_curve(&base, 40, target).unwrap();
        assert_eq!(delta, 90_000);
        for (i, point) in curve.points.iter().enumerate() {
            assert_eq!(point.uv, base.points[i].uv);
            assert_eq!(
                point.khz,
                if i < 40 {
                    base.points[i].khz + 90_000
                } else {
                    target
                }
            );
        }
        assert!(curve.points.last().unwrap().uv > 1_000_000);
        nvapi::validate(&curve, &base).unwrap();

        // Repeating the operation or changing the target must not accumulate offsets.
        let repeated = undervolt_curve(&base, 40, target).unwrap().0;
        assert!(repeated
            .points
            .iter()
            .zip(&curve.points)
            .all(|(a, b)| a.khz == b.khz));
        let changed = undervolt_curve(&base, 40, target + 30_000).unwrap().0;
        assert_eq!(changed.points[0].khz, base.points[0].khz + 120_000);
    }

    #[test]
    fn invalid_undervolt_targets_do_not_change_the_base() {
        let base = base();
        assert!(undervolt_curve(&base, 128, 1_350_000).is_err());
        assert!(undervolt_curve(&base, 40, 1_350_001).is_err());
        assert!(undervolt_curve(&base, 40, 150_000).is_err());
        assert!(undervolt_curve(&base, 0, 3_015_000).is_err());
        assert_eq!(base.points[0].khz, 405_000);
    }
}
