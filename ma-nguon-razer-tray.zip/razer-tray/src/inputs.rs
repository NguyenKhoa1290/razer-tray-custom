//! Menu controls matching the existing InputShortcuts hotkeys.
use anyhow::{Context, Result};
use tray_icon::menu::CheckMenuItem;
use windows::Win32::UI::Input::KeyboardAndMouse::{
    GetAsyncKeyState, SendInput, INPUT, INPUT_0, INPUT_KEYBOARD, KEYBDINPUT, KEYEVENTF_KEYUP,
    VIRTUAL_KEY,
};
use winreg::{enums::HKEY_CURRENT_USER, RegKey};

const CONSENT: &str =
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore";
const TOUCHPAD: &str = r"SOFTWARE\Microsoft\Windows\CurrentVersion\PrecisionTouchPad\Status";

#[derive(Clone, Copy)]
pub enum Control {
    Microphone,
    Camera,
    Touchpad,
}

impl Control {
    pub const ALL: [Self; 3] = [Self::Microphone, Self::Camera, Self::Touchpad];
    pub fn id(self) -> &'static str {
        match self {
            Self::Microphone => "input:microphone",
            Self::Camera => "input:camera",
            Self::Touchpad => "input:touchpad",
        }
    }
    pub fn from_id(id: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|c| c.id() == id)
    }
    fn capability(self) -> &'static str {
        match self {
            Self::Microphone => "microphone",
            Self::Camera => "webcam",
            Self::Touchpad => unreachable!(),
        }
    }
    fn name(self) -> &'static str {
        match self {
            Self::Microphone => "Quyền micro",
            Self::Camera => "Quyền camera",
            Self::Touchpad => "Touchpad",
        }
    }
    fn hotkey(self) -> &'static str {
        match self {
            Self::Microphone => "Win + F4",
            Self::Camera => "Win + F5",
            Self::Touchpad => "Win + F6",
        }
    }

    pub fn enabled(self) -> Result<bool> {
        let user = RegKey::predef(HKEY_CURRENT_USER);
        match self {
            Self::Touchpad => Ok(user.open_subkey(TOUCHPAD)?.get_value::<u32, _>("Enabled")? != 0),
            _ => {
                let path = format!(r"{}\{}", CONSENT, self.capability());
                let value: String = user.open_subkey(path)?.get_value("Value")?;
                Ok(!value.eq_ignore_ascii_case("Deny"))
            }
        }
    }

    pub fn toggle(self) -> Result<()> {
        match self {
            Self::Touchpad => {
                // Preserve modifiers physically held by the user, as in InputShortcuts.cs.
                let mut keys = Vec::new();
                unsafe {
                    if GetAsyncKeyState(0x11) >= 0 {
                        keys.push(0x11);
                    }
                    if GetAsyncKeyState(0x5b) >= 0 && GetAsyncKeyState(0x5c) >= 0 {
                        keys.push(0x5b);
                    }
                }
                keys.push(0x87); // Windows touchpad toggle: Ctrl + Win + F24.
                                 // F6 must be released in the injected stream before the Windows
                                 // Ctrl+Win+F24 chord, even when the physical hotkey is still held.
                let mut events = Vec::new();
                if unsafe { GetAsyncKeyState(0x75) } < 0 {
                    events.push(key_event(0x75, true));
                }
                events.extend(
                    keys.iter()
                        .map(|&key| key_event(key, false))
                        .chain(keys.iter().rev().map(|&key| key_event(key, true))),
                );
                let sent = unsafe { SendInput(&events, std::mem::size_of::<INPUT>() as i32) };
                anyhow::ensure!(
                    sent as usize == events.len(),
                    "Không gửi được lệnh bật/tắt touchpad"
                );
                Ok(())
            }
            _ => {
                let on = self
                    .enabled()
                    .context("Không đọc được trạng thái quyền thiết bị")?;
                let path = format!(r"{}\{}", CONSENT, self.capability());
                let (key, _) = RegKey::predef(HKEY_CURRENT_USER).create_subkey(path)?;
                key.set_value("Value", &if on { "Deny" } else { "Allow" })?;
                Ok(())
            }
        }
    }
}

fn key_event(key: u16, up: bool) -> INPUT {
    INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 {
            ki: KEYBDINPUT {
                wVk: VIRTUAL_KEY(key),
                dwFlags: if up {
                    KEYEVENTF_KEYUP
                } else {
                    Default::default()
                },
                ..Default::default()
            },
        },
    }
}

pub fn menu_items() -> [CheckMenuItem; 3] {
    Control::ALL.map(|c| CheckMenuItem::with_id(c.id(), c.name(), true, false, None))
}

pub fn refresh(items: &[CheckMenuItem; 3]) {
    for (control, item) in Control::ALL.into_iter().zip(items) {
        let on = control.enabled().ok();
        let label = format!(
            "{}: {} ({})",
            control.name(),
            match on {
                Some(true) => "Bật",
                Some(false) => "Tắt",
                None => "Không rõ",
            },
            control.hotkey()
        );
        if item.text() != label {
            item.set_text(label);
        }
        item.set_checked(on == Some(true));
        item.set_enabled(on.is_some());
    }
}
