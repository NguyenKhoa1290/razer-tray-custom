use super::{apply_elevated, load, nvapi::Api, save, Profile};
use anyhow::{Context, Result};
use std::sync::atomic::{AtomicBool, Ordering};
use windows::{
    core::{w, PCWSTR},
    Win32::{
        Foundation::{COLORREF, HINSTANCE, HWND, LPARAM, LRESULT, RECT, WPARAM},
        Graphics::Gdi::*,
        System::LibraryLoader::GetModuleHandleW,
        UI::{
            HiDpi::{
                AdjustWindowRectExForDpi, GetDpiForWindow, SetThreadDpiAwarenessContext,
                DPI_AWARENESS_CONTEXT, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2,
            },
            Input::KeyboardAndMouse::{ReleaseCapture, SetCapture},
            WindowsAndMessaging::*,
        },
    },
};

static OPEN: AtomicBool = AtomicBool::new(false);
const CLASS: PCWSTR = w!("KhoaRazerGpuCurveEditor");
const X0: i32 = 70;
const X1: i32 = 950;
const Y0: i32 = 100;
const Y1: i32 = 430;
const VOLT: i32 = 101;
const FREQ: i32 = 102;
const SET: i32 = 103;
const FLAT: i32 = 104;
const READ: i32 = 105;
const LOAD: i32 = 106;
const SAVE: i32 = 107;
const APPLY: i32 = 108;
const RESTORE: i32 = 109;
const RESET: i32 = 110;
const UNDERVOLT: i32 = 111;
const AUTO: i32 = 112;
const WIDTH: i32 = 1000;
const HEIGHT: i32 = 720;
const STYLE: WINDOW_STYLE = WINDOW_STYLE(WS_OVERLAPPEDWINDOW.0 | WS_CLIPCHILDREN.0);

struct DpiGuard(DPI_AWARENESS_CONTEXT);
impl Drop for DpiGuard {
    fn drop(&mut self) {
        unsafe {
            SetThreadDpiAwarenessContext(self.0);
        }
    }
}
struct ControlLayout {
    hwnd: HWND,
    x: i32,
    y: i32,
    width: i32,
    height: i32,
}

unsafe fn ui_font(height: i32) -> HFONT {
    CreateFontW(
        -height.max(1),
        0,
        0,
        0,
        400,
        0,
        0,
        0,
        DEFAULT_CHARSET.0 as u32,
        0,
        0,
        CLEARTYPE_QUALITY.0 as u32,
        0,
        w!("Segoe UI"),
    )
}

unsafe fn fit_window(hwnd: HWND) {
    let dpi = GetDpiForWindow(hwnd).max(96);
    let mut monitor = MONITORINFO {
        cbSize: std::mem::size_of::<MONITORINFO>() as u32,
        ..Default::default()
    };
    if !GetMonitorInfoW(
        MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST),
        &mut monitor,
    )
    .as_bool()
    {
        return;
    }
    let work = monitor.rcWork;
    let mut frame = RECT::default();
    if AdjustWindowRectExForDpi(&mut frame, STYLE, false, WINDOW_EX_STYLE(0), dpi).is_err() {
        return;
    }
    let scale = (dpi as f64 / 96.0)
        .min(((work.right - work.left - 32) - (frame.right - frame.left)) as f64 / WIDTH as f64)
        .min(((work.bottom - work.top - 32) - (frame.bottom - frame.top)) as f64 / HEIGHT as f64)
        .max(0.5);
    let width = (WIDTH as f64 * scale).round() as i32 + frame.right - frame.left;
    let height = (HEIGHT as f64 * scale).round() as i32 + frame.bottom - frame.top;
    let _ = SetWindowPos(
        hwnd,
        None,
        work.left + (work.right - work.left - width) / 2,
        work.top + (work.bottom - work.top - height) / 2,
        width,
        height,
        SWP_NOZORDER | SWP_NOACTIVATE,
    );
}

pub fn open() {
    if OPEN.swap(true, Ordering::SeqCst) {
        unsafe {
            let h = FindWindowW(CLASS, None);
            if h.0 != 0 {
                let _ = ShowWindow(h, SW_RESTORE);
                let _ = SetForegroundWindow(h);
            }
        }
        return;
    }
    std::thread::spawn(|| {
        if let Err(e) = run() {
            log::warn!("GPU curve editor: {e:#}");
            unsafe {
                let text = wide(&format!("Không mở được trình chỉnh curve: {e:#}"));
                MessageBoxW(
                    None,
                    PCWSTR(text.as_ptr()),
                    w!("Curve GPU"),
                    MB_OK | MB_ICONERROR,
                );
            }
        }
        OPEN.store(false, Ordering::SeqCst);
    });
}

struct Editor {
    api: Api,
    profile: Profile,
    selected: usize,
    visible: Vec<usize>,
    dragging: bool,
    voltage: HWND,
    frequency: HWND,
    status: HWND,
    auto_start: HWND,
    hwnd: HWND,
    controls: Vec<ControlLayout>,
    control_font: HFONT,
    graph_font: HFONT,
    font_height: i32,
}
impl Drop for Editor {
    fn drop(&mut self) {
        unsafe {
            let _ = DeleteObject(self.control_font);
            let _ = DeleteObject(self.graph_font);
        }
    }
}
fn wide(text: &str) -> Vec<u16> {
    text.encode_utf16().chain(Some(0)).collect()
}
fn set_text(h: HWND, text: &str) {
    let text = wide(text);
    unsafe {
        let _ = SetWindowTextW(h, PCWSTR(text.as_ptr()));
    }
}
fn text(h: HWND) -> String {
    let mut buffer = [0u16; 128];
    let count = unsafe { GetWindowTextW(h, &mut buffer) };
    String::from_utf16_lossy(&buffer[..count.max(0) as usize])
}
unsafe fn control(
    parent: HWND,
    class: PCWSTR,
    label: &str,
    style: WINDOW_STYLE,
    x: i32,
    y: i32,
    width: i32,
    height: i32,
    id: i32,
) -> HWND {
    let editor = &mut *(GetWindowLongPtrW(parent, GWLP_USERDATA) as *mut Editor);
    let (sx, sy) = editor.scale();
    let label = wide(label);
    let h = CreateWindowExW(
        WINDOW_EX_STYLE(0),
        class,
        PCWSTR(label.as_ptr()),
        WS_CHILD | WS_VISIBLE | style,
        (x as f64 * sx).round() as i32,
        (y as f64 * sy).round() as i32,
        (width as f64 * sx).round() as i32,
        (height as f64 * sy).round() as i32,
        parent,
        HMENU(id as isize),
        None,
        None,
    );
    SendMessageW(
        h,
        WM_SETFONT,
        WPARAM(editor.control_font.0 as usize),
        LPARAM(1),
    );
    editor.controls.push(ControlLayout {
        hwnd: h,
        x,
        y,
        width,
        height,
    });
    h
}

pub(super) fn run() -> Result<()> {
    let instance_guard = single_instance::SingleInstance::new("razer-gpu-curve-editor")?;
    anyhow::ensure!(
        instance_guard.is_single(),
        "Trình chỉnh curve đang mở ở cửa sổ khác"
    );
    unsafe {
        // Tao changes process DPI mode in the tray path. Use an explicit mode on
        // this window's thread so menu, login startup and CLI behave identically.
        let previous = SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        anyhow::ensure!(
            previous.0 != 0,
            "Không đặt được chế độ DPI cho cửa sổ curve"
        );
        let _dpi_guard = DpiGuard(previous);
        let api = Api::new()?;
        let profile = api.snapshot()?.profile();
        let visible: Vec<_> = profile
            .points
            .iter()
            .enumerate()
            .filter(|(_, p)| (300_000..=1_000_000).contains(&p.uv))
            .map(|(i, _)| i)
            .collect();
        anyhow::ensure!(
            !visible.is_empty(),
            "Không có điểm điện áp trong vùng 0,3–1,0 V"
        );
        let selected = visible
            .iter()
            .copied()
            .min_by_key(|&i| profile.points[i].uv.abs_diff(675000))
            .unwrap();
        let mut state = Box::new(Editor {
            api,
            profile,
            selected,
            visible,
            dragging: false,
            voltage: HWND(0),
            frequency: HWND(0),
            status: HWND(0),
            auto_start: HWND(0),
            hwnd: HWND(0),
            controls: Vec::new(),
            control_font: ui_font(16),
            graph_font: ui_font(16),
            font_height: 16,
        });
        let instance: HINSTANCE = GetModuleHandleW(None)?.into();
        let class = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: instance,
            lpszClassName: CLASS,
            hCursor: LoadCursorW(None, IDC_ARROW)?,
            hbrBackground: HBRUSH((COLOR_WINDOW.0 + 1) as isize),
            ..Default::default()
        };
        RegisterClassW(&class);
        let hwnd = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            CLASS,
            w!("Curve GPU NVIDIA — Razer Tray"),
            STYLE,
            120,
            100,
            1020,
            770,
            None,
            None,
            instance,
            Some((&mut *state as *mut Editor).cast()),
        );
        anyhow::ensure!(hwnd.0 != 0, "Không tạo được cửa sổ curve");
        state.hwnd = hwnd;
        fit_window(hwnd);
        state.layout();
        control(
            hwnd,
            w!("STATIC"),
            "RTX 2080 Super Max-Q • Chỉnh đường cong điện áp / xung nhân GPU",
            WINDOW_STYLE(0),
            20,
            15,
            960,
            25,
            0,
        );
        control(hwnd,w!("STATIC"),"Bấm/kéo điểm để chỉnh MHz. Vùng xám: driver không hỗ trợ. Chỉ ghi GPU khi bấm Áp dụng.",WINDOW_STYLE(0),20,48,970,30,0);
        control(
            hwnd,
            w!("STATIC"),
            "Điện áp (V)",
            WINDOW_STYLE(0),
            70,
            468,
            160,
            22,
            0,
        );
        control(
            hwnd,
            w!("STATIC"),
            "Xung (MHz)",
            WINDOW_STYLE(0),
            260,
            468,
            150,
            22,
            0,
        );
        state.voltage = control(
            hwnd,
            w!("COMBOBOX"),
            "",
            WINDOW_STYLE(3) | WS_VSCROLL | WS_TABSTOP,
            70,
            493,
            170,
            250,
            VOLT,
        );
        state.frequency = control(
            hwnd,
            w!("EDIT"),
            "",
            WS_BORDER | WS_TABSTOP | WINDOW_STYLE(0x2000),
            260,
            493,
            130,
            26,
            FREQ,
        );
        for (label, id, x, width) in [
            ("Đổi điểm", SET, 410, 130),
            ("Làm phẳng từ điểm này", FLAT, 555, 255),
            ("Undervolt", UNDERVOLT, 825, 135),
        ] {
            control(hwnd, w!("BUTTON"), label, WS_TABSTOP, x, 490, width, 32, id);
        }
        for (label, id, x, width) in [
            ("Đọc lại từ GPU", READ, 35, 170),
            ("Mở curve đã lưu", LOAD, 220, 175),
            ("Lưu curve", SAVE, 410, 150),
            ("Áp dụng (quyền quản trị)", APPLY, 575, 360),
        ] {
            control(hwnd, w!("BUTTON"), label, WS_TABSTOP, x, 543, width, 36, id);
        }
        for (label, id, x, width) in [
            ("Khôi phục trước lần áp dụng", RESTORE, 35, 300),
            ("Đưa offset về mặc định", RESET, 350, 280),
        ] {
            control(hwnd, w!("BUTTON"), label, WS_TABSTOP, x, 591, width, 34, id);
        }
        state.auto_start = control(
            hwnd,
            w!("BUTTON"),
            "Tự áp dụng curve đã lưu khi đăng nhập Windows",
            WS_TABSTOP | WINDOW_STYLE(3),
            35,
            632,
            925,
            24,
            AUTO,
        );
        state.refresh_auto_start();
        state.status = control(hwnd, w!("STATIC"), "", WINDOW_STYLE(0), 35, 664, 925, 44, 0);
        state.populate();
        state.layout();
        state.status("Đang hiển thị curve thực tế. Bản nháp chưa được áp dụng. Các điểm trên 1,0 V vẫn được giữ trong tệp.");
        let _ = ShowWindow(hwnd, SW_SHOW);
        let _ = SetForegroundWindow(hwnd);
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).0 > 0 {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        Ok(())
    }
}

impl Editor {
    unsafe fn refresh_auto_start(&self) {
        SendMessageW(
            self.auto_start,
            BM_SETCHECK,
            WPARAM(usize::from(super::startup_enabled())),
            LPARAM(0),
        );
    }
    unsafe fn scale(&self) -> (f64, f64) {
        let mut rect = RECT::default();
        let _ = GetClientRect(self.hwnd, &mut rect);
        (
            (rect.right.max(1) as f64) / WIDTH as f64,
            (rect.bottom.max(1) as f64) / HEIGHT as f64,
        )
    }
    unsafe fn layout(&mut self) {
        let (sx, sy) = self.scale();
        let height = (16.0 * sx.min(sy)).round().max(1.0) as i32;
        let old = if height != self.font_height {
            let next = ui_font(height);
            if next.0 != 0 {
                self.font_height = height;
                let old = self.control_font;
                self.control_font = next;
                Some(old)
            } else {
                None
            }
        } else {
            None
        };
        for item in &self.controls {
            let _ = MoveWindow(
                item.hwnd,
                (item.x as f64 * sx).round() as i32,
                (item.y as f64 * sy).round() as i32,
                (item.width as f64 * sx).round().max(1.0) as i32,
                (item.height as f64 * sy).round().max(1.0) as i32,
                true,
            );
            SendMessageW(
                item.hwnd,
                WM_SETFONT,
                WPARAM(self.control_font.0 as usize),
                LPARAM(1),
            );
        }
        if let Some(old) = old {
            let _ = DeleteObject(old);
        }
        let _ = InvalidateRect(self.hwnd, None, true);
    }
    fn status(&self, message: &str) {
        set_text(self.status, message);
    }
    unsafe fn populate(&mut self) {
        SendMessageW(self.voltage, CB_RESETCONTENT, WPARAM(0), LPARAM(0));
        for &i in &self.visible {
            let label = wide(&format!("{:.5}", self.profile.points[i].uv as f64 / 1e6));
            SendMessageW(
                self.voltage,
                CB_ADDSTRING,
                WPARAM(0),
                LPARAM(label.as_ptr() as isize),
            );
        }
        self.selection();
    }
    unsafe fn selection(&self) {
        if let Some(i) = self.visible.iter().position(|&i| i == self.selected) {
            SendMessageW(self.voltage, CB_SETCURSEL, WPARAM(i), LPARAM(0));
        }
        set_text(
            self.frequency,
            &format!("{}", self.profile.points[self.selected].khz / 1000),
        );
        let _ = InvalidateRect(self.hwnd, None, false);
    }
    fn target_khz(&self) -> Result<u32> {
        let mhz: u32 = text(self.frequency)
            .trim()
            .parse()
            .context("Nhập xung MHz nguyên hợp lệ")?;
        anyhow::ensure!(
            (150..=3000).contains(&mhz),
            "Xung cần trong phạm vi 150–3000 MHz"
        );
        anyhow::ensure!(
            mhz.is_multiple_of(15),
            "Xung cần theo bước 15 MHz của GPU, ví dụ 1350, 1365"
        );
        Ok(mhz * 1000)
    }
    fn set_point(&mut self) -> Result<()> {
        self.profile.points[self.selected].khz = self.target_khz()?;
        Ok(())
    }
    fn action(&mut self, id: i32) -> Result<()> {
        unsafe {
            match id {
                VOLT => {
                    let n = SendMessageW(self.voltage, CB_GETCURSEL, WPARAM(0), LPARAM(0)).0;
                    if n >= 0 && (n as usize) < self.visible.len() {
                        self.selected = self.visible[n as usize];
                        self.selection();
                    }
                    return Ok(());
                }
                SET => {
                    self.set_point()?;
                    self.status("Đã đổi điểm trong bản nháp. Bấm Áp dụng khi chỉnh xong.");
                }
                FLAT => {
                    self.set_point()?;
                    let target = self.profile.points[self.selected].khz;
                    for (i, p) in self.profile.points.iter_mut().enumerate() {
                        if i >= self.selected {
                            p.khz = target
                        } else {
                            p.khz = p.khz.min(target)
                        }
                    }
                    self.status("Đã làm phẳng từ điện áp chọn đến hết curve, kể cả các điểm trên 1,0 V. Chưa ghi GPU.");
                }
                UNDERVOLT => {
                    let target = self.target_khz()?;
                    let snapshot = self.api.snapshot()?;
                    let current = snapshot.profile();
                    anyhow::ensure!(
                        self.profile.points.len() == current.points.len()
                            && self
                                .profile
                                .points
                                .iter()
                                .zip(&current.points)
                                .all(|(a, b)| a.uv == b.uv),
                        "Các điểm điện áp không còn khớp driver; hãy đọc lại từ GPU"
                    );
                    let (profile, delta) = snapshot.undervolt_profile(self.selected, target)?;
                    self.profile = profile;
                    self.status(&format!(
                        "Đã tạo bản nháp Undervolt: bên trái {:+.0} MHz so với gốc (offset 0); từ {:.5} V trở đi giữ {} MHz. Bấm lại không cộng dồn. Chưa ghi GPU.",
                        delta as f64 / 1000.0,
                        self.profile.points[self.selected].uv as f64 / 1e6,
                        target / 1000
                    ));
                }
                READ => {
                    self.profile = self.api.snapshot()?.profile();
                    self.status(
                        "Đã đọc lại curve từ GPU; các thay đổi chưa áp dụng trong bản nháp đã bỏ.",
                    );
                }
                LOAD => {
                    let profile: Profile = load("saved.toml")?;
                    let current = self.api.snapshot()?.profile();
                    super::nvapi::validate(&profile, &current)?;
                    self.profile = profile;
                    self.status("Đã mở curve đã lưu. Chưa áp dụng lên GPU.");
                }
                SAVE => {
                    self.set_point()?;
                    super::nvapi::validate(&self.profile, &self.api.snapshot()?.profile())?;
                    save("saved.toml", &self.profile)?;
                    self.status(if super::startup_enabled() {
                        "Đã lưu curve. Curve này sẽ được tự áp dụng khi đăng nhập Windows."
                    } else {
                        "Đã lưu curve. Tự áp dụng khi đăng nhập Windows đang tắt."
                    });
                }
                APPLY => {
                    self.set_point()?;
                    super::nvapi::validate(&self.profile, &self.api.snapshot()?.profile())?;
                    let message = apply_elevated("apply", Some(self.profile.clone()))?;
                    if super::startup_enabled() {
                        save("saved.toml", &self.profile).context("Đã áp dụng curve nhưng chưa cập nhật được bản lưu cho lần khởi động sau")?;
                    }
                    self.profile = self.api.snapshot()?.profile();
                    self.status(&message);
                }
                AUTO => {
                    let enable =
                        SendMessageW(self.auto_start, BM_GETCHECK, WPARAM(0), LPARAM(0)).0 == 1;
                    let result = super::set_startup_enabled(enable);
                    self.refresh_auto_start();
                    self.status(&result?);
                }
                RESTORE | RESET => {
                    let message =
                        apply_elevated(if id == RESTORE { "restore" } else { "reset" }, None)?;
                    self.profile = self.api.snapshot()?.profile();
                    self.status(&message);
                }
                _ => return Ok(()),
            }
            self.selection();
            Ok(())
        }
    }
    unsafe fn mouse(&mut self, x: i32, y: i32, start: bool) {
        if start {
            if !(X0..=X1).contains(&x) || !(Y0..=Y1).contains(&y) {
                return;
            }
            let uv = 300000 + ((x - X0) as u32 * 700000 / (X1 - X0) as u32);
            let minimum = self.profile.points[self.visible[0]].uv;
            if uv < minimum {
                self.status("Vùng này không có điểm điện áp trong driver; không thể đặt 0,3 V trên card này.");
                return;
            }
            self.selected = self
                .visible
                .iter()
                .copied()
                .min_by_key(|&i| self.profile.points[i].uv.abs_diff(uv))
                .unwrap();
            self.dragging = true;
            SetCapture(self.hwnd);
            self.selection();
        }
        if self.dragging {
            let mhz = ((Y1 - y.clamp(Y0, Y1)) * 3000 / (Y1 - Y0)).clamp(150, 3000) as u32;
            self.profile.points[self.selected].khz = ((mhz + 7) / 15) * 15000;
            self.status("Đang sửa bản nháp. Kiểm tra điểm đã chọn rồi bấm Áp dụng khi sẵn sàng.");
            self.selection();
        }
    }
    unsafe fn paint(&self) {
        let mut ps = PAINTSTRUCT::default();
        let dc = BeginPaint(self.hwnd, &mut ps);
        let saved = SaveDC(dc);
        let (sx, sy) = self.scale();
        SetMapMode(dc, MM_ANISOTROPIC);
        let _ = SetWindowExtEx(dc, WIDTH, HEIGHT, None);
        let _ = SetViewportExtEx(
            dc,
            (sx * WIDTH as f64).round().max(1.0) as i32,
            (sy * HEIGHT as f64).round().max(1.0) as i32,
            None,
        );
        let graph = RECT {
            left: X0,
            top: Y0,
            right: X1 + 1,
            bottom: Y1 + 1,
        };
        // Point markers extend beyond the plot edge; erase those pixels too.
        FillRect(
            dc,
            &RECT {
                left: X0 - 4,
                top: Y0 - 4,
                right: X1 + 8,
                bottom: Y1 + 8,
            },
            HBRUSH(GetStockObject(WHITE_BRUSH).0),
        );
        let grey = CreateSolidBrush(COLORREF(0xeeeeee));
        let minimum = self.profile.points[self.visible[0]].uv;
        FillRect(
            dc,
            &RECT {
                right: px(minimum),
                ..graph
            },
            grey,
        );
        let _ = DeleteObject(grey);
        let font = SelectObject(dc, self.graph_font);
        SetBkMode(dc, TRANSPARENT);
        let grid = CreatePen(PS_SOLID, 1, COLORREF(0xdddddd));
        let old = SelectObject(dc, grid);
        for mv in (300..=1000).step_by(100) {
            let x = px(mv * 1000);
            let _ = MoveToEx(dc, x, Y0, None);
            let _ = LineTo(dc, x, Y1);
            draw_text(dc, x - 18, Y1 + 10, &format!("{:.1} V", mv as f64 / 1000.0));
        }
        for mhz in (0..=3000).step_by(500) {
            let y = py(mhz * 1000);
            let _ = MoveToEx(dc, X0, y, None);
            let _ = LineTo(dc, X1, y);
            draw_text(dc, 15, y - 7, &format!("{mhz}"));
        }
        draw_text(dc, 15, 78, "MHz");
        SelectObject(dc, old);
        let _ = DeleteObject(grid);
        let line = CreatePen(PS_SOLID, 2, COLORREF(0x007a20));
        let old = SelectObject(dc, line);
        let mut first = true;
        for &i in &self.visible {
            let p = &self.profile.points[i];
            let x = px(p.uv);
            let y = py(p.khz);
            if first {
                let _ = MoveToEx(dc, x, y, None);
                first = false;
            } else {
                let _ = LineTo(dc, x, y);
            }
            let _ = Ellipse(dc, x - 2, y - 2, x + 3, y + 3);
        }
        SelectObject(dc, old);
        let _ = DeleteObject(line);
        let selected = &self.profile.points[self.selected];
        let pen = CreatePen(PS_SOLID, 3, COLORREF(0x0080ff));
        let old = SelectObject(dc, pen);
        let x = px(selected.uv);
        let y = py(selected.khz);
        let _ = Ellipse(dc, x - 6, y - 6, x + 7, y + 7);
        SelectObject(dc, old);
        let _ = DeleteObject(pen);
        // The changing label is outside the graph's cleared rectangle. Erase its
        // whole area before drawing transparent text, including shorter values.
        FillRect(
            dc,
            &RECT {
                left: 645,
                top: 72,
                right: 1000,
                bottom: Y0,
            },
            GetSysColorBrush(COLOR_WINDOW),
        );
        draw_text(
            dc,
            650,
            76,
            &format!(
                "Chọn: {:.5} V / {} MHz",
                selected.uv as f64 / 1e6,
                selected.khz / 1000
            ),
        );
        SelectObject(dc, font);
        let _ = RestoreDC(dc, saved);
        let _ = EndPaint(self.hwnd, &ps);
    }
}
fn px(uv: u32) -> i32 {
    X0 + ((uv.saturating_sub(300000) as u64) * (X1 - X0) as u64 / 700000) as i32
}
fn py(khz: u32) -> i32 {
    Y1 - ((khz.min(3000000) as u64) * (Y1 - Y0) as u64 / 3000000) as i32
}
unsafe fn draw_text(dc: HDC, x: i32, y: i32, text: &str) {
    let chars: Vec<u16> = text.encode_utf16().collect();
    let _ = TextOutW(dc, x, y, &chars);
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    if msg == WM_NCCREATE {
        let create = &*(lp.0 as *const CREATESTRUCTW);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, create.lpCreateParams as isize);
    }
    if msg == WM_CLOSE {
        let _ = DestroyWindow(hwnd);
        return LRESULT(0);
    }
    if msg == WM_DESTROY {
        PostQuitMessage(0);
        return LRESULT(0);
    }
    let ptr = GetWindowLongPtrW(hwnd, GWLP_USERDATA) as *mut Editor;
    if !ptr.is_null() {
        match msg {
            WM_SIZE => {
                if wp.0 != SIZE_MINIMIZED as usize {
                    let editor = &mut *ptr;
                    editor.hwnd = hwnd;
                    editor.layout();
                }
                return LRESULT(0);
            }
            WM_DPICHANGED => {
                let suggested = &*(lp.0 as *const RECT);
                let _ = SetWindowPos(
                    hwnd,
                    None,
                    suggested.left,
                    suggested.top,
                    suggested.right - suggested.left,
                    suggested.bottom - suggested.top,
                    SWP_NOZORDER | SWP_NOACTIVATE,
                );
                fit_window(hwnd);
                return LRESULT(0);
            }
            WM_GETMINMAXINFO => {
                let info = &mut *(lp.0 as *mut MINMAXINFO);
                info.ptMinTrackSize.x = 640;
                info.ptMinTrackSize.y = 500;
                return LRESULT(0);
            }
            WM_PAINT => {
                (&*ptr).paint();
                return LRESULT(0);
            }
            WM_COMMAND => {
                let id = (wp.0 & 0xffff) as i32;
                let notification = (wp.0 >> 16) as u32;
                if (id == VOLT && notification == CBN_SELCHANGE)
                    || ((SET..=AUTO).contains(&id) && notification == BN_CLICKED)
                {
                    let editor = &mut *ptr;
                    if let Err(e) = editor.action(id) {
                        editor.status(&format!("Không thực hiện được: {e:#}"));
                        log::warn!("GPU editor action: {e:#}");
                    }
                    return LRESULT(0);
                }
            }
            WM_LBUTTONDOWN | WM_MOUSEMOVE => {
                if msg == WM_LBUTTONDOWN || (&*ptr).dragging {
                    let (sx, sy) = (&*ptr).scale();
                    (&mut *ptr).mouse(
                        (((lp.0 as u16) as i16 as f64) / sx).round() as i32,
                        ((((lp.0 >> 16) as u16) as i16 as f64) / sy).round() as i32,
                        msg == WM_LBUTTONDOWN,
                    );
                }
                return LRESULT(0);
            }
            WM_LBUTTONUP => {
                (&mut *ptr).dragging = false;
                let _ = ReleaseCapture();
                return LRESULT(0);
            }
            WM_CAPTURECHANGED => {
                (&mut *ptr).dragging = false;
                return LRESULT(0);
            }
            _ => {}
        }
    }
    DefWindowProcW(hwnd, msg, wp, lp)
}
