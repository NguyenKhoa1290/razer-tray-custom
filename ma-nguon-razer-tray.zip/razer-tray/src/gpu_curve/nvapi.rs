use super::{load, save, Point, Profile, GPU};
use anyhow::{bail, ensure, Context, Result};
use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeSet,
    ffi::c_void,
    mem::{size_of, zeroed},
    ptr::null_mut,
};
use windows::{
    core::{s, w},
    Win32::{
        Foundation::{FreeLibrary, HMODULE},
        System::LibraryLoader::{GetProcAddress, LoadLibraryExW, LOAD_LIBRARY_SEARCH_SYSTEM32},
    },
};

#[repr(C)]
#[derive(Clone, Copy)]
struct MaskPoint {
    kind: u32,
    enabled: u8,
    reserved: [u8; 19],
}
#[repr(C)]
#[derive(Clone, Copy)]
struct Mask {
    version: u32,
    mask: [u8; 32],
    reserved: [u8; 32],
    points: [MaskPoint; 255],
}
#[repr(C)]
#[derive(Clone, Copy)]
struct VFPoint {
    kind: u32,
    khz: u32,
    uv: u32,
    reserved: [u8; 16],
}
#[repr(C)]
#[derive(Clone, Copy)]
struct Curve {
    version: u32,
    mask: [u8; 32],
    reserved: [u8; 32],
    points: [VFPoint; 255],
}
#[repr(C)]
#[derive(Clone, Copy)]
struct ControlPoint {
    kind: u32,
    reserved: [u8; 16],
    offset: i32,
    reserved2: [u8; 12],
}
#[repr(C)]
#[derive(Clone, Copy)]
struct Control {
    version: u32,
    mask: [u8; 32],
    reserved: [u8; 32],
    points: [ControlPoint; 255],
}
const _: () = {
    assert!(size_of::<Mask>() == 6188);
    assert!(size_of::<Curve>() == 7208);
    assert!(size_of::<Control>() == 9248);
};

type Query = unsafe extern "C" fn(u32) -> *const c_void;
type Call = unsafe extern "C" fn(*mut c_void, *mut c_void) -> i32;
pub struct Api {
    dll: HMODULE,
    query: Query,
    gpu: *mut c_void,
    initialized: bool,
}
pub struct Snapshot {
    curve: Curve,
    table: Control,
    indices: Vec<usize>,
}
#[derive(Serialize, Deserialize)]
struct Backup {
    gpu: String,
    bus: u32,
    points: Vec<Offset>,
}
#[derive(Serialize, Deserialize)]
struct Offset {
    uv: u32,
    offset: i32,
}

impl Snapshot {
    pub fn profile(&self) -> Profile {
        Profile {
            version: 1,
            gpu: GPU.into(),
            bus: 1,
            points: self
                .indices
                .iter()
                .map(|&i| Point {
                    uv: self.curve.points[i].uv,
                    khz: self.curve.points[i].khz,
                })
                .collect(),
        }
    }
    fn base_profile(&self) -> Result<Profile> {
        let mut profile = self.profile();
        for (point, &i) in profile.points.iter_mut().zip(&self.indices) {
            let base = i64::from(self.curve.points[i].khz) - i64::from(self.table.points[i].offset);
            ensure!(
                (150_000..=3_000_000).contains(&base),
                "Xung gốc của driver ngoài phạm vi hỗ trợ"
            );
            point.khz = base as u32;
        }
        Ok(profile)
    }
    pub fn undervolt_profile(&self, selected: usize, target_khz: u32) -> Result<(Profile, i32)> {
        let (profile, delta) = super::undervolt_curve(&self.base_profile()?, selected, target_khz)?;
        validate(&profile, &self.profile())?;
        let _ = plan(&profile, self)?;
        Ok((profile, delta))
    }
    pub fn validate_profile(&self, profile: &Profile) -> Result<()> {
        validate(profile, &self.profile())?;
        let _ = plan(profile, self)?;
        Ok(())
    }
    /// Startup may lower saved targets to respect +150 MHz against today's base.
    /// Never raise any target or replace the user's saved file.
    pub fn startup_profile(&self, saved: &Profile) -> Result<(Profile, usize, u32)> {
        validate(saved, &self.profile())?;
        let base = self.base_profile()?;
        let mut limited = saved.clone();
        for (point, base) in limited.points.iter_mut().zip(&base.points) {
            point.khz = point.khz.min(base.khz + 150_000);
        }
        // A driver base can contain a dip. Lower preceding points as needed so
        // limiting a later point never produces an invalid descending curve.
        for i in (0..limited.points.len() - 1).rev() {
            limited.points[i].khz = limited.points[i].khz.min(limited.points[i + 1].khz);
        }
        self.validate_profile(&limited)?;
        let reductions: Vec<_> = saved
            .points
            .iter()
            .zip(&limited.points)
            .map(|(before, after)| before.khz - after.khz)
            .filter(|&value| value > 0)
            .collect();
        let count = reductions.len();
        let maximum = reductions.into_iter().max().unwrap_or(0);
        Ok((limited, count, maximum))
    }
    fn offsets(&self) -> Vec<i32> {
        self.indices
            .iter()
            .map(|&i| self.table.points[i].offset)
            .collect()
    }
}

impl Api {
    pub fn new() -> Result<Self> {
        unsafe {
            let dll = LoadLibraryExW(w!("nvapi64.dll"), None, LOAD_LIBRARY_SEARCH_SYSTEM32)?;
            let address = match GetProcAddress(dll, s!("nvapi_QueryInterface")) {
                Some(p) => p,
                None => {
                    let _ = FreeLibrary(dll);
                    bail!("Driver NVIDIA thiếu nvapi_QueryInterface")
                }
            };
            let mut api = Self {
                dll,
                query: std::mem::transmute::<unsafe extern "system" fn() -> isize, Query>(address),
                gpu: null_mut(),
                initialized: false,
            };
            let init: unsafe extern "C" fn() -> i32 = std::mem::transmute(api.address(0x0150E828)?);
            api.check(init())?;
            api.initialized = true;
            let enumerate: unsafe extern "C" fn(*mut *mut c_void, *mut u32) -> i32 =
                std::mem::transmute(api.address(0xE5AC921F)?);
            let mut handles = [null_mut(); 64];
            let mut count = 0;
            api.check(enumerate(handles.as_mut_ptr(), &mut count))?;
            ensure!(count <= 64, "Driver returned too many GPUs");
            let mut found = Vec::new();
            for &gpu in &handles[..count as usize] {
                let mut name = [0u8; 64];
                api.call(0xCEEE8E9F, gpu, name.as_mut_ptr().cast())?;
                let mut bus = 0u32;
                api.call(0x1BE0B8E5, gpu, (&mut bus as *mut u32).cast())?;
                let name = String::from_utf8_lossy(
                    &name[..name.iter().position(|&v| v == 0).unwrap_or(64)],
                );
                if name == GPU && bus == 1 {
                    found.push(gpu);
                }
            }
            ensure!(
                found.len() == 1,
                "Chỉ hỗ trợ đúng RTX 2080 Super Max-Q trên PCI bus 1 của máy này"
            );
            api.gpu = found[0];
            // Reject a global core offset from another utility: it changes our baseline.
            let mut data = [0u32; 1829];
            data[0] = 7316 | (1 << 16);
            api.call(0x6FF81213, api.gpu, data.as_mut_ptr().cast())?;
            ensure!(data[5] == 0 && data[7] == 0, "Driver P0 layout không khớp");
            ensure!(
                data[10] as i32 == 0,
                "Có global core offset từ công cụ khác; hãy đưa offset đó về 0 trước"
            );
            Ok(api)
        }
    }
    unsafe fn address(&self, id: u32) -> Result<*const c_void> {
        let p = (self.query)(id);
        ensure!(
            !p.is_null(),
            "NVAPI interface {id:08X} không có trong driver"
        );
        Ok(p)
    }
    unsafe fn call(&self, id: u32, gpu: *mut c_void, data: *mut c_void) -> Result<()> {
        let f: Call = std::mem::transmute(self.address(id)?);
        self.check(f(gpu, data))
    }
    fn check(&self, code: i32) -> Result<()> {
        if code == 0 {
            return Ok(());
        }
        unsafe {
            let mut text = [0u8; 128];
            if let Ok(p) = self.address(0x6C2D048C) {
                let f: unsafe extern "C" fn(i32, *mut u8) -> i32 = std::mem::transmute(p);
                f(code, text.as_mut_ptr());
            }
            bail!(
                "NVAPI {code}: {}",
                String::from_utf8_lossy(&text[..text.iter().position(|&v| v == 0).unwrap_or(128)])
            )
        }
    }
    pub fn snapshot(&self) -> Result<Snapshot> {
        unsafe {
            let mut mask: Mask = zeroed();
            mask.version = size_of::<Mask>() as u32 | (1 << 16);
            self.call(0x507B4B59, self.gpu, (&mut mask as *mut Mask).cast())?;
            let mut curve: Curve = zeroed();
            curve.version = size_of::<Curve>() as u32 | (1 << 16);
            curve.mask = mask.mask;
            self.call(0x21537AD4, self.gpu, (&mut curve as *mut Curve).cast())?;
            let mut table: Control = zeroed();
            table.version = size_of::<Control>() as u32 | (1 << 16);
            table.mask = mask.mask;
            self.call(0x23F1B133, self.gpu, (&mut table as *mut Control).cast())?;
            let mut indices: Vec<_> = (0..255)
                .filter(|&i| mask.points[i].enabled != 0 && curve.points[i].kind == 0)
                .collect();
            indices.sort_by_key(|&i| curve.points[i].uv);
            ensure!(
                indices.len() == 128
                    && indices
                        .iter()
                        .map(|&i| curve.points[i].uv)
                        .collect::<BTreeSet<_>>()
                        .len()
                        == 128,
                "Bố cục curve của driver đã thay đổi; không ghi GPU"
            );
            ensure!(
                indices
                    .iter()
                    .all(|&i| (300_000..=1_500_000).contains(&curve.points[i].uv)
                        && curve.points[i].khz <= 3_000_000),
                "Dữ liệu curve không hợp lệ"
            );
            Ok(Snapshot {
                curve,
                table,
                indices,
            })
        }
    }
    fn write(&self, snap: &Snapshot, offsets: &[i32]) -> Result<()> {
        unsafe {
            ensure!(offsets.len() == snap.indices.len(), "Offset count mismatch");
            let setter: Call = std::mem::transmute(self.address(0x0733E009)?);
            let mut table = snap.table;
            table.mask = [0; 32];
            for (&i, &offset) in snap.indices.iter().zip(offsets) {
                table.mask[i / 8] |= 1 << (i % 8);
                table.points[i].offset = offset;
            }
            let code = setter(self.gpu, (&mut table as *mut Control).cast());
            if code == -1 {
                // New drivers may require one request per point.
                for (&i, &offset) in snap.indices.iter().zip(offsets) {
                    let mut single = snap.table;
                    single.mask = [0; 32];
                    single.mask[i / 8] = 1 << (i % 8);
                    single.points[i].offset = offset;
                    self.check(setter(self.gpu, (&mut single as *mut Control).cast()))?;
                }
            } else {
                self.check(code)?;
            }
            Ok(())
        }
    }
    pub fn apply(&self, profile: Profile) -> Result<()> {
        let original = self.snapshot()?;
        self.apply_from_snapshot(profile, original)
    }
    pub fn apply_saved_at_startup(&self, saved: &Profile) -> Result<(usize, u32)> {
        let original = self.snapshot()?;
        let (profile, count, reduction) = original.startup_profile(saved)?;
        self.apply_from_snapshot(profile, original)?;
        Ok((count, reduction))
    }
    fn apply_from_snapshot(&self, profile: Profile, original: Snapshot) -> Result<()> {
        validate(&profile, &original.profile())?;
        let _ = plan(&profile, &original)?; // Reject every out-of-envelope point before any write.
        let previous = original.offsets();
        save(
            "before-last.toml",
            &Backup {
                gpu: GPU.into(),
                bus: 1,
                points: original
                    .indices
                    .iter()
                    .zip(&previous)
                    .map(|(&i, &offset)| Offset {
                        uv: original.curve.points[i].uv,
                        offset,
                    })
                    .collect(),
            },
        )?;
        let result = (|| {
            let mut snap = original.clone_snapshot();
            for _ in 0..3 {
                let offsets = plan(&profile, &snap)?;
                self.write(&snap, &offsets)?;
                let verified = self.snapshot()?;
                ensure!(
                    verified.offsets() == offsets,
                    "Driver không giữ nguyên bảng offset vừa ghi"
                );
                let close = verified
                    .indices
                    .iter()
                    .zip(&profile.points)
                    .all(|(&i, p)| verified.curve.points[i].khz.abs_diff(p.khz) <= 1000);
                if close {
                    return Ok(());
                }
                snap = verified;
            }
            bail!("Driver không giữ được curve yêu cầu sau 3 lần đọc lại")
        })();
        if let Err(error) = result {
            self.rollback(&original, &previous)
                .context(format!("{error:#}; khôi phục curve cũ cũng lỗi"))?;
            bail!("{error:#}. Đã khôi phục curve trước khi áp dụng.")
        }
        Ok(())
    }
    fn rollback(&self, original: &Snapshot, offsets: &[i32]) -> Result<()> {
        self.write(original, offsets)?;
        ensure!(self.snapshot()?.offsets() == offsets, "Rollback mismatch");
        Ok(())
    }
    pub fn restore(&self) -> Result<()> {
        let backup: Backup = load("before-last.toml")?;
        let snap = self.snapshot()?;
        ensure!(
            backup.gpu == GPU && backup.bus == 1 && backup.points.len() == 128,
            "Backup không đúng GPU"
        );
        let offsets: Vec<_> = snap
            .indices
            .iter()
            .zip(&backup.points)
            .map(|(&i, p)| {
                ensure!(
                    snap.curve.points[i].uv == p.uv && (-1_000_000..=150_000).contains(&p.offset),
                    "Backup không khớp driver"
                );
                Ok(p.offset)
            })
            .collect::<Result<_>>()?;
        let previous = snap.offsets();
        if let Err(e) = self.rollback(&snap, &offsets) {
            self.rollback(&snap, &previous)?;
            return Err(e);
        }
        Ok(())
    }
    pub fn reset(&self) -> Result<()> {
        let snap = self.snapshot()?;
        self.apply(snap.base_profile()?)
    }

    /// Hardware integration check: re-send the exact current offsets, never a new tune.
    pub fn verify_roundtrip(&self) -> Result<()> {
        let snap = self.snapshot()?;
        let offsets = snap.offsets();
        self.rollback(&snap, &offsets)
    }
}
impl Snapshot {
    fn clone_snapshot(&self) -> Self {
        Self {
            curve: self.curve,
            table: self.table,
            indices: self.indices.clone(),
        }
    }
}
impl Drop for Api {
    fn drop(&mut self) {
        unsafe {
            if self.initialized {
                if let Ok(p) = self.address(0xD22BDD7E) {
                    let f: unsafe extern "C" fn() -> i32 = std::mem::transmute(p);
                    f();
                }
            }
            let _ = FreeLibrary(self.dll);
        }
    }
}

pub(super) fn validate(profile: &Profile, current: &Profile) -> Result<()> {
    ensure!(
        profile.version == 1 && profile.gpu == GPU && profile.bus == 1,
        "Curve không đúng GPU của máy"
    );
    ensure!(
        profile.points.len() == 128 && current.points.len() == 128,
        "Curve cần đủ 128 điểm driver"
    );
    let mut prev = 0;
    for (p, c) in profile.points.iter().zip(&current.points) {
        ensure!(
            p.uv == c.uv && p.uv > prev,
            "Các điểm điện áp không khớp driver"
        );
        prev = p.uv;
        ensure!(
            (150_000..=3_000_000).contains(&p.khz),
            "Xung ngoài phạm vi 150–3000 MHz"
        );
    }
    ensure!(
        profile.points.windows(2).all(|w| w[0].khz <= w[1].khz),
        "Curve phải không giảm khi điện áp tăng; hãy chỉnh lại hoặc làm phẳng"
    );
    Ok(())
}
fn plan(profile: &Profile, snapshot: &Snapshot) -> Result<Vec<i32>> {
    profile
        .points
        .iter()
        .zip(&snapshot.indices)
        .map(|(p, &i)| {
            let base = i64::from(snapshot.curve.points[i].khz)
                - i64::from(snapshot.table.points[i].offset);
            let offset = i64::from(p.khz) - base;
            ensure!(
                (-1_000_000..=150_000).contains(&offset),
                "Điểm {:.4} V cần offset {:.0} MHz, ngoài giới hạn −1000 đến +150 MHz",
                p.uv as f64 / 1e6,
                offset as f64 / 1000.0
            );
            Ok(offset as i32)
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn arbitrary_voltage_or_downward_curve_never_reaches_driver() {
        let base = Profile {
            version: 1,
            gpu: GPU.into(),
            bus: 1,
            points: (0..128)
                .map(|i| Point {
                    uv: 450000 + i * 6250,
                    khz: 405000 + i * 15000,
                })
                .collect(),
        };
        assert!(validate(&base, &base).is_ok());
        let mut bad = base.clone();
        bad.points[0].uv = 300000;
        assert!(validate(&bad, &base).is_err());
        let mut bad = base.clone();
        bad.points[20].khz = 150000;
        assert!(validate(&bad, &base).is_err());
    }

    #[test]
    fn offsets_are_relative_to_the_current_base_and_bad_offsets_are_rejected() {
        let mut snap = Snapshot {
            curve: unsafe { zeroed() },
            table: unsafe { zeroed() },
            indices: (0..128).collect(),
        };
        for i in 0..128 {
            snap.curve.points[i].uv = 450000 + i as u32 * 6250;
            snap.curve.points[i].khz = 405000 + i as u32 * 15000;
            snap.table.points[i].offset = -30000;
        }
        let desired = snap.profile();
        assert!(plan(&desired, &snap).unwrap().iter().all(|&o| o == -30000));
        let mut bad = desired;
        bad.points[127].khz += 200000;
        assert!(plan(&bad, &snap).is_err());
    }

    #[test]
    fn undervolt_uses_zero_offset_base_even_when_a_curve_is_already_applied() {
        let mut snap = Snapshot {
            curve: unsafe { zeroed() },
            table: unsafe { zeroed() },
            indices: (0..128).collect(),
        };
        for i in 0..128 {
            let base = 405_000 + i as u32 * 15_000;
            let applied = (base + 60_000).min(1_350_000);
            snap.curve.points[i].uv = 450_000 + i as u32 * 6_250;
            snap.curve.points[i].khz = applied;
            snap.table.points[i].offset = applied as i32 - base as i32;
        }
        let (curve, delta) = snap.undervolt_profile(60, 1_395_000).unwrap();
        assert_eq!(delta, 90_000);
        assert_eq!(curve.points[0].khz, 495_000);
        assert_eq!(curve.points[60].khz, 1_395_000);
        assert_eq!(curve.points[127].khz, 1_395_000);
        assert!(plan(&curve, &snap).unwrap()[..60]
            .iter()
            .all(|&v| v == 90_000));
        assert!(snap.undervolt_profile(60, 1_470_000).is_err());
        assert!(snap.undervolt_profile(40, 1_095_000).is_err());
    }

    #[test]
    fn startup_only_lowers_targets_and_keeps_saved_curve_intact_when_driver_base_changes() {
        let mut snap = Snapshot {
            curve: unsafe { zeroed() },
            table: unsafe { zeroed() },
            indices: (0..128).collect(),
        };
        for i in 0..128 {
            snap.curve.points[i].uv = 450_000 + i as u32 * 6_250;
            snap.curve.points[i].khz = 405_000 + i as u32 * 15_000;
        }
        let saved = super::super::undervolt_curve(&snap.profile(), 60, 1_455_000)
            .unwrap()
            .0;
        // The saved curve is unchanged when it fits the current base.
        assert_eq!(snap.startup_profile(&saved).unwrap().1, 0);
        snap.curve.points[8].khz -= 15_000;
        snap.curve.points[9].khz -= 45_000;
        assert!(snap.validate_profile(&saved).is_err()); // Manual apply still rejects it.
        let (limited, count, maximum) = snap.startup_profile(&saved).unwrap();
        assert_eq!((count, maximum), (3, 45_000));
        assert!(limited.points.windows(2).all(|w| w[0].khz <= w[1].khz));
        assert!(limited
            .points
            .iter()
            .zip(&saved.points)
            .all(|(a, b)| a.khz <= b.khz && a.uv == b.uv));
        assert!(limited.points[60..].iter().all(|p| p.khz == 1_455_000));
        assert!(plan(&limited, &snap)
            .unwrap()
            .iter()
            .all(|&offset| offset <= 150_000));
        assert_eq!(saved.points[9].khz, 690_000);

        // Positive-offset limiting must not bypass the negative-offset envelope.
        let too_low = super::super::undervolt_curve(&snap.base_profile().unwrap(), 40, 1_095_000)
            .unwrap()
            .0;
        assert!(snap.startup_profile(&too_low).is_err());
    }
}
