# Chỉnh curve GPU NVIDIA

Mở **Chỉnh curve GPU NVIDIA...** trong menu Razer Tray. Trình chỉnh được viết bằng Rust, dùng NVAPI của driver trong System32; hiện giới hạn đúng RTX 2080 Super Max-Q trên PCI bus 1 và bảng 128 điểm đã kiểm tra trên máy RZ09-03305.

- Đồ thị có trục 0,3–1,0 V. Card hiện báo điểm thấp nhất 0,45 V; vùng thấp hơn được tô xám và không thể áp dụng.
- Chọn điện áp hoặc kéo điểm để chỉnh MHz. Xung nhập theo bước 15 MHz.
- **Đổi điểm** sửa bản nháp. **Làm phẳng từ điểm này** kéo các điểm phía sau về cùng MHz, bao gồm điểm trên 1,0 V; các điểm phía trước vượt trần cũng được hạ xuống.
- **Undervolt** lấy mức chênh giữa xung bạn chọn và xung gốc tại cùng điện áp, cộng mức chênh đó cho tất cả điểm bên trái, rồi làm phẳng từ điểm chọn đến hết curve. Ví dụ điểm gốc 1200 MHz được nâng lên 1290 MHz thì các điểm bên trái cũng tăng 90 MHz so với gốc. Gốc là curve driver với offset từng điểm bằng 0, được tính từ xung hiện tại trừ offset đã áp dụng, không cần đặt lại GPU. Bấm lại không cộng dồn; nút chỉ tạo bản nháp và kiểm tra giới hạn offset. Bấm **Áp dụng** để ghi lên GPU.
- **Lưu curve** lưu bản nháp. **Mở curve đã lưu** chỉ nạp vào trình chỉnh.
- **Tự áp dụng curve đã lưu khi đăng nhập Windows** là tùy chọn bật/tắt trong cửa sổ curve. Cần lưu một curve hợp lệ trước khi bật. Khi bật, Razer Tray đăng ký một mục khởi động duy nhất trong Task Scheduler, chạy bằng tài khoản hiện tại với quyền quản trị; mục Run cũ của tray được gỡ sau khi đăng ký thành công. Không có trình GPU riêng. Bỏ chọn để ngừng tự áp dụng; mục khởi động tray vẫn được quản lý bằng **Khởi động cùng Windows**. Khi tùy chọn bật, thao tác **Áp dụng** thành công cũng cập nhật bản lưu dùng cho lần đăng nhập tiếp theo.
- **Áp dụng** xin quyền quản trị, ghi và đọc lại từ driver để xác nhận. Nếu lỗi trong lúc ghi, chương trình cố khôi phục bảng offset trước đó và báo kết quả.
- **Khôi phục trước lần áp dụng** nạp lại bảng offset đã lưu trước lần ghi gần nhất. **Đưa offset về mặc định** đưa offset từng điểm về 0.

Curve phải không giảm khi điện áp tăng, có đúng các điểm điện áp của driver và nằm trong giới hạn offset −1000 đến +150 MHz so với cơ sở driver hiện tại. Không thay đổi power limit, xung bộ nhớ hay khóa P-state. Xác nhận ghi thành công không phải là kiểm tra độ ổn định của một cấu hình mới.

Khi tự nạp lúc đăng nhập, theo lựa chọn của người dùng, app hạ các điểm cần offset trên +150 MHz xuống trong giới hạn so với curve gốc driver tại thời điểm đó, và hạ các điểm phía trước nếu cần để curve không giảm. Không tăng bất kỳ điểm nào; không sửa tệp curve đã lưu. Nhật ký và `startup-result.toml` ghi số điểm đã giới hạn và mức hạ lớn nhất. Các trường hợp ngoài giới hạn khác vẫn bị từ chối. Áp dụng thủ công vẫn kiểm tra nguyên curve và báo lỗi nếu vượt giới hạn.

Các tệp curve, yêu cầu và bản khôi phục nằm tại `%LOCALAPPDATA%\razer-tray\gpu-curve`. Mặc định tự áp dụng tắt. Chỉ lần chạy có `--startup` từ mục đăng nhập và tùy chọn bật mới tự áp dụng; mở app hoặc trình chỉnh thủ công không tự ghi GPU. App đợi driver sẵn sàng rồi áp dụng một lần, đọc lại xác nhận và ghi kết quả vào `startup-result.toml` cùng nhật ký tray. Không liên tục áp lại curve. Tác vụ Python cũ `Khoa_GPU_Undervolt_675mV` đã được gỡ; bản XML sao lưu nằm trong Documents/Razer Tray Backups.

Giao tiếp bảng V/F dùng các interface NVAPI riêng, chuyển từ loader Python đã hoạt động trên máy và đối chiếu bố cục với https://github.com/buswedg/nvapi-cmd. Driver mới có thể thay đổi bố cục; phần kiểm tra GPU và kích thước bảng sẽ từ chối trường hợp không khớp.
